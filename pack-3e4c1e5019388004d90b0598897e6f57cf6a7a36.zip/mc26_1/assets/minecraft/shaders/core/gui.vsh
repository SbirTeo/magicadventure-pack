#version 330
#define MAGIX_TARGET 261
#define LOC(n)

// One source for 26.1, 26.2 and 26.3: MagixPack (pack/ShaderVariants) writes it at the pack root for 26.2
// (MAGIX_TARGET 262) and in the overlays mc26_3/ (263, LOC(n) = layout(location = n)) and mc26_1/ (261).
// 26.3 moved TextureMat and reordered Globals: the copied blocks below follow MAGIX_TARGET. 26.1 binds no
// Globals to the gui pipeline (checked in its client): there the sidebar keeps the player's GUI scale and is
// not moved (the text shader of 26.1 cannot move its lines), only recolored and bordered.

// MagixScoreboard: vanilla "gui" vertex shader (Minecraft 26.2, taken from the real client jar) plus
// the recognition of the two sidebar background quads, so that gui.fsh can recolor them and draw a
// border. Every other GUI fill goes through untouched.
//
// How the sidebar is drawn in 26.2 (read from the client bytecode, Hud.displayScoreboardSidebar):
// two GuiGraphicsExtractor.fill calls with pure black, alpha Options.getBackgroundColor(0.4f) for
// the title row and 0.3f for the body. Both quads end at x = guiWidth - 1. With L lines, H = 9L and
// half = guiHeight / 2 (integer division): the body spans y = half - 6L - 1 .. half + 3L (bottom =
// half + H/3, top = bottom - H - 1), the title the 9 pixels right above it, half - 6L - 10 .. half - 6L - 1.
//
// Which corner a vertex is comes from its POSITION only, never from gl_VertexID: the client packs the
// whole GUI in one shared vertex buffer and draws each batch with a base vertex that is not always a
// multiple of 4, so gl_VertexID % 4 was off depending on what else was on screen (chat, items,
// titles...) and the border showed up only sometimes. Right: x on guiWidth - 1. Body top/bottom: the
// screen middle splits them. Title top/bottom: half - y - 1 is 6L at its bottom and 6L + 9 at its
// top, so modulo 6 it is 0 or 3 and tells them apart without knowing L.

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
#if MAGIX_TARGET >= 263
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
#else
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
#endif
layout(std140) uniform Projection {
    mat4 ProjMat;
};
// Copy of globals.glsl (26.2): only ScreenSize is used, to get the player's GUI scale (sbScaleFactor).
// Verified in the 26.2 client: the gui pipeline inherits GLOBALS_SNIPPET, so the block is bound.
#if MAGIX_TARGET >= 263
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};
#elif MAGIX_TARGET >= 262
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    vec3 CameraOffset;
    vec2 ScreenSize;
    float GlintAlpha;
    float GameTime;
    int MenuBlurRadius;
    int UseRgss;
};
#endif

LOC(0) in vec3 Position;
LOC(1) in vec4 Color;

LOC(0) out vec4 vertexColor;
// 0 = not the sidebar, 1 = sidebar body, 2 = sidebar title (the same on all 4 corners of a quad).
LOC(1) flat out int sbKind;
// Position inside the quad, 0..1 (x: 0 left, 1 right; y: 0 top, 1 bottom).
LOC(2) out vec2 sbUV;
// Position in GUI pixels: with sbUV, gui.fsh derives the quad size (border thickness in pixels).
LOC(3) out vec2 sbGui;
// 1 when the corner recognition is trusted; anything less and gui.fsh draws no border (background only).
LOC(4) out float sbOk;
// 1 on the corners of the chat's "System" mark (see CHAT_TAG below), 0 elsewhere: gui.fsh drops the pixels where
// it is 1, which only a quad with ALL four corners marked has everywhere.
LOC(5) out float chatTag;

// The mark the client draws at the left of every system message of the chat (GuiMessageTag.SYSTEM, also
// CHAT_NOT_SECURE: indicator colour 0xD0D0D0, read from the 26.2 client): ChatComponent fills x -4..-2 of a line,
// under a pose scaled by the chat scale and moved 4 to the right, so on the GUI it is a quad between x 0 and
// 2 x chat scale (at most 2), in that grey with the chat's opacity as alpha. The server cannot colour it and a glyph
// cannot cover it (it is drawn over the text): it is dropped, and MagixEssentials' chat bar (MagixPack glyph
// chat_bar, in the writer's name colour) drawn there shows instead. Any other fill is untouched: one with a corner
// right of x 2.5 or of another colour is never dropped. MagixPack's fallback gui.vsh/gui.fsh (used where MagixScoreboard
// is missing, e.g. magicrealms) has the same block: change both together.
const vec3 CHAT_TAG = vec3(208.0 / 255.0);

// Sidebar size the same for everyone (config sidebar-scale): the client draws the sidebar at each
// player's GUI scale; here the distances from the point the sidebar hangs on (right edge, half height)
// are multiplied by wanted scale / player scale, which gives the sidebar vanilla would draw at the
// wanted scale. SB_SCALE_MODE: 0 = off (vanilla), 1 = proportional to the screen height, 2 = the
// nearest whole scale to that proportion. SB_SCALE_FACTOR = sidebar pixel size per screen pixel of
// height, worked out by the plugin (SidebarPack.scaleFactor): with mode "minimap" it is the pixel size
// of the text in the minimap info panel of MagixFactions, so the two texts match exactly.
// THIS FUNCTION IS COPIED UNCHANGED in text.vsh of MagixFactions (sidebar text): change both together.
const int SB_SCALE_MODE = 1;
const float SB_SCALE_FACTOR = 0.00187500;

float sbScaleFactor(float guiW, float guiH) {
#if MAGIX_TARGET < 262
    return 1.0;
#else
    if (SB_SCALE_MODE == 0 || ScreenSize.y < 1.0 || guiH < 1.0) return 1.0;
    // Player's GUI scale: the client sets guiW = ceil(pixels / scale), so pixels / guiW is the scale
    // (just below it when the division is not exact: hence round).
    float player = max(round(max(ScreenSize.x / guiW, ScreenSize.y / guiH)), 1.0);
    float wanted = ScreenSize.y * SB_SCALE_FACTOR;
    if (SB_SCALE_MODE == 2) wanted = max(round(wanted), 1.0);
    return wanted / player;
#endif
}

// HUD growth with the GUI scale (map.minimap.gui-scale of MagixFactions, read by SidebarPack): the sidebar grows with
// the minimap over it, round the screen's top right corner on the minimap's margin. THIS FUNCTION IS COPIED UNCHANGED
// from text.vsh of MagixFactions (hudGrow, which explains it): change both together.
const float HUD_GROW_WEIGHT = 0.5000;
const float HUD_GROW_MIN = 1.0000;
const float HUD_GROW_MAX = 1.2500;
const float HUD_GROW_BASE = 0.00187500;
const float HUD_GROW_TOP = 16.0 / 9.0 * 0.03 * 0.5;   // the minimap's margin as a share of the screen height

float hudGrow(float guiW, float guiH) {
#if MAGIX_TARGET < 262
    return 1.0;
#else
    if (HUD_GROW_WEIGHT <= 0.0 || HUD_GROW_BASE <= 0.0 || ScreenSize.y < 1.0 || guiH < 1.0) return 1.0;
    float player = max(round(max(ScreenSize.x / guiW, ScreenSize.y / guiH)), 1.0);
    float proportional = ScreenSize.y * HUD_GROW_BASE;
    return clamp(1.0 + HUD_GROW_WEIGHT * (player / proportional - 1.0), HUD_GROW_MIN, HUD_GROW_MAX);
#endif
}

// A point of the right column (GUI pixels) grown round the screen's top right corner on the minimap's margin.
vec2 hudGrowRight(vec2 at, float guiW, float guiH) {
    vec2 corner = vec2(guiW, HUD_GROW_TOP * guiH);
    return corner + (at - corner) * hudGrow(guiW, guiH);
}

// Vertical move of the sidebar (sidebar-position.offset-y); none on 26.1, see the note at the top.
#if MAGIX_TARGET >= 262
const float SB_SHIFT = 60.0000;
#else
const float SB_SHIFT = 0.0;
#endif
// Room over the title and under the last line (sidebar-background.padding-top|bottom, GUI pixels): the title's top
// edge goes up, the body's bottom edge goes down; the letters stay where they are.
const float SB_PAD_TOP = 4.0000;
const float SB_PAD_BOTTOM = 4.0000;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    sbKind = 0;
    sbUV = vec2(0.0);
    sbGui = vec2(0.0);
    sbOk = 0.0;
    chatTag = 0.0;
    if (all(lessThan(abs(Color.rgb - CHAT_TAG), vec3(0.6 / 255.0)))) {
        vec4 at = ModelViewMat * vec4(Position, 1.0);
        if (at.x < 2.5) chatTag = 1.0;
    }

    bool black = all(lessThan(Color.rgb, vec3(0.002)));
    bool body = black && abs(Color.a - 76.0 / 255.0) < 0.002;
    bool title = black && abs(Color.a - 102.0 / 255.0) < 0.002;
    if (body || title) {
        vec4 p = ModelViewMat * vec4(Position, 1.0);
        float gw = abs(2.0 / ProjMat[0][0]);
        float gh = abs(2.0 / ProjMat[1][1]);
        bool right = p.x > gw - 1.5;
        bool top;
        bool ok = true;
        if (body) {
            top = p.y < gh * 0.5;
            // Only the sidebar's own rows: top at half - 6L - 1, bottom at half + 3L (L = 1..15 lines). Any other black
            // fill at 30% (the advancements screen darkens its tab with exactly that on hover, 31/10) is left vanilla:
            // scaled on the corners inside the band only, it was drawn as a slanted lime parallelogram.
            float midY = floor(floor(gh + 0.5) * 0.5);
            float y = floor(p.y + 0.5);
            float d = top ? midY - y - 1.0 : y - midY;
            float step = top ? 6.0 : 3.0;
            if (d < step - 0.5 || d > 15.0 * step + 0.5 || abs(mod(d + 0.5, step) - 0.5) > 0.01) {
                body = false;
            }
        } else {
            float midY = floor(floor(gh + 0.5) * 0.5);
            float r = mod(midY - floor(p.y + 0.5) - 1.0, 6.0);
            top = abs(r - 3.0) < 0.5;
            // Neither 0 nor 3: not the layout described above (another client?). Keep the
            // recolored background, skip the border.
            ok = top || r < 0.5 || r > 5.5;
            float d = midY - floor(p.y + 0.5) - 1.0;   // 6L at the title's bottom, 6L + 9 at its top
            if (!ok || d < 5.5 || d > 99.5) title = false;
        }
        if (!body && !title) {
            return;
        }
        // Sidebar moved vertically (config sidebar-position.offset-y): the text shader (text.vsh of
        // MagixFactions) moves the lines by the same amount.
        // Then the size (sidebar-scale), around the same anchor and in the same order as text.vsh. Only
        // inside the band vanilla's sidebar occupies (half height - 101 .. + 46): another fill with the
        // same color (a chat background set to 30%) is never resized. text.vsh moves the marked lines at any
        // height (a client mod may draw the sidebar elsewhere, with a background of its own).
        bool inBand = p.y > gh * 0.5 - 101.0 && p.y < gh * 0.5 + 46.0;
        if (title && top) p.y -= SB_PAD_TOP;
        if (body && !top) p.y += SB_PAD_BOTTOM;
        vec2 anchor = vec2(gw, gh * 0.5);
        vec2 q = vec2(p.x, p.y + SB_SHIFT);
        if (inBand) {
            q = anchor + (q - anchor) * sbScaleFactor(gw, gh);
            q = hudGrowRight(q, gw, gh);   // then with the GUI scale, like text.vsh
        }
        gl_Position = ProjMat * vec4(q, p.z, p.w);
        sbKind = body ? 1 : 2;
        sbUV = vec2(right ? 1.0 : 0.0, top ? 0.0 : 1.0);
        sbGui = p.xy;
        sbOk = ok ? 1.0 : 0.0;
    }
}
