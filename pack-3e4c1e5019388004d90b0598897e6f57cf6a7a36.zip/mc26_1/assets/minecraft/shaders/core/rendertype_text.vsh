#version 330
#define MAGIX_TARGET 261
#define LOC(n)

// ONE SOURCE, THREE MINECRAFT VERSIONS (since 10/10/2026). MagixPack (pack/ShaderVariants) writes this file
// three times in the pack, each time with its own lines right after #version:
//   26.2 (pack format 88): the pack root, MAGIX_TARGET 262, LOC(n) empty;
//   26.3 (format 97): overlay mc26_3/, MAGIX_TARGET 263, GL_ARB_separate_shader_objects, LOC(n) =
//     layout(location = n) (26.3 wants it on every in/out), #moj_import -> #include;
//   26.1.x (format 84): overlay mc26_1/, MAGIX_TARGET 261, renamed rendertype_text.vsh (26.1 has no text.vsh
//     and no IS_GUI/IS_SEE_THROUGH: only the world branch below exists there, so no theft HUD and no sidebar
//     move/size on 26.1).
// Locations: vanilla 26.3 ones (Position 0, Color 1, UV0 2, UV2 3; out 0..3), ours from 4. They must match text.fsh.

// MagixFactions minimap HUD — porting a Paper/Minecraft 26.2 (2026-07-23): il vanilla "rendertype_text"
// e' stato ACCORPATO da Mojang in QUESTO singolo file "text.vsh/.fsh", condiviso da tre varianti (testo
// del mondo, testo GUI, testo "see-through") selezionate a compile-time dai define IS_GUI/IS_SEE_THROUGH.
// Verificato scaricando ed estraendo lo shader vanilla reale dal client jar 26.2 (piston-meta Mojang):
// su 26.1.2 esisteva un file dedicato "rendertype_text.vsh/.fsh" (mai IS_GUI/IS_SEE_THROUGH, era GIA'
// solo la variante "mondo") — la nostra logica andava quindi bene com'era, senza guardie. Ora la stessa
// variante e' il ramo "!IS_GUI && !IS_SEE_THROUGH" di questo file unico: la nostra aggiunta va percio'
// racchiusa nello stesso #if, altrimenti non compila piu' per le altre due varianti (che non hanno
// sphericalVertexDistance/cylindricalVertexDistance/UV2/Sampler2). Il CONTENUTO di una mappa in un item
// frame passa per la variante "mondo" (verificato su 26.1.2, ipotesi ragionevole che valga ancora qui
// dato che Mojang ha solo RINOMINATO/ACCORPATO i file, non cambiato il render-type concettuale) — DA
// CONFERMARE in-game dall'utente dopo il deploy.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#ifdef IS_GUI
// ScreenSize (pixel veri della finestra), per ricavare la Scala GUI del giocatore: vedi sbScaleFactor.
// Verificato nel client 26.2: la pipeline del testo GUI eredita GLOBALS_SNIPPET (blocco "Globals").
#moj_import <minecraft:globals.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

LOC(0) in vec3 Position;
LOC(1) in vec4 Color;
LOC(2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
LOC(3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
LOC(0) out float sphericalVertexDistance;
LOC(1) out float cylindricalVertexDistance;
#endif

LOC(2) out vec4 vertexColor;
LOC(3) out vec2 texCoord0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
// --- MagixFactions minimap HUD (solo variante "mondo", vedi nota sopra) --------------------------
// Frecce dei giocatori sulla minimap (una per giocatore visibile, come i cursori nativi della mappa-
// item). Ogni slot: .xy = posizione in pixel-mappa (0..127), .z = angolo di sguardo (radianti),
// .w = tipo (0 = tu / 1 = fazione / 2 = alleato / 3 = nemico), oppure .w < 0 = slot vuoto. Vengono
// DECODIFICATE qui dall'header (bit impacchettati nelle prime 2 righe della map texture) e DISEGNATE dal
// fragment shader a risoluzione SCHERMO: restano nitide e ruotano fluide a qualsiasi angolo, come i
// cursori nativi — che pero' non si agganciano alla minimap HUD (vedi MapContentBuilder), per questo le
// ridisegniamo noi. ARROW_MAX e il formato dei record DEVONO combaciare con MapService (ARROW_MAX/
// ARROW_BITS/ARROW_ANGLE_STEPS e computePlayerArrows).
uniform sampler2D Sampler0;
LOC(4) out vec2 uvCoord;
LOC(5) flat out int custom;
#define ARROW_MAX 6
LOC(6) flat out vec4 arrows[ARROW_MAX];   // locations 6..11

// MagixFactions minimap HUD (metodo NMinimap, riscritto). Il CONTENUTO di una mappa dentro un item
// frame e' renderizzato da questo shader (variante "mondo" di text), non da entity/item. La mappa della
// minimap ha un HEADER MAGICO nei primi pixel della riga 0 (byte palette 18/4/49 -> colori 0xFF0000/
// 0x597D27/0x3737DC, verificati): se lo shader lo riconosce, questo non e' testo/mappa nel mondo 3D ma
// la minimap HUD, e la sua posizione a schermo viene sovrascritta con coordinate fisse (angolo alto a
// destra o a sinistra, config map.minimap.position). L'header (prime 2 righe) viene poi nascosto nel fragment per non mostrarlo.
//
// texelFetch (coordinate intere) nel VERTEX shader FUNZIONA per la map texture in questo contesto,
// mentre texture()/textureLod() nell'entity shader restituivano nero (verificato empiricamente).

// Dimensione e margine dell'HUD in unita' "map" (riferite all'altezza dello schermo, vedi hudClip).
// La mappa e' 128x128 pixel FISSI (limite Minecraft): piu' e' grande a schermo, piu' ogni pixel viene
// ingrandito e appare "sgranato". Un riquadro piu' piccolo distribuisce i 128px su meno spazio -> piu'
// nitido. Il quad resta quadrato (bounding box): il ritaglio CIRCOLARE avviene nel fragment shader.
// 0.2700 e' sostituito a runtime dal plugin col valore di config map.minimap.screen-size
// (frazione di schermo). Se il pack viene usato cosi' com'e' (senza sostituzione), resta 0.22.
const vec2 MAP_SIZE = vec2(0.2700, 0.2700);
const vec2 MAP_OFFSET = vec2(0.03, 0.03);
// Lato dello schermo: 0.0 e' sostituito dal plugin (0.0 = alto a destra, 1.0 = alto a
// sinistra) da config map.minimap.position. Vale anche per il pannello info, che segue la minimap.
const float MAP_LEFT = 0.0;

// Unita' "map" riferite all'ALTEZZA dello schermo: un'unita' vale HUD_ASPECT in NDC verticale e
// HUD_ASPECT/aspect in NDC orizzontale, quindi pixel quadrati e la stessa quota di altezza su 16:9, 16:10
// o ultrawide. Prima l'unita' era riferita alla LARGHEZZA (su un ultrawide la minimap diventava piu'
// alta); con HUD_ASPECT = 16/9 su uno schermo 16:9 resta identica a prima. La Scala GUI non c'entra:
// questa variante disegna nel mondo, non nella GUI, quindi la minimap e' gia' uguale per tutti.
const float HUD_ASPECT = 16.0 / 9.0;

// Depth of the HUD quads in clip space: 26.2+ use ZERO_TO_ONE clip depth (0.0 is the near plane, see the
// minimap branch), 26.1 the classic -1..1 one (its near plane is just above -1).
#if MAGIX_TARGET >= 262
const float HUD_CLIP_Z = 0.0;
#else
const float HUD_CLIP_Z = -0.9999;
#endif

// Da coordinate HUD a clip space. m.x = distanza dal bordo SINISTRO del riquadro (0..s), m.y = distanza
// dal bordo ALTO dello schermo, entrambe in unita' "map". Il riquadro e' agganciato al lato scelto
// (MAP_LEFT) con margine MAP_OFFSET.x. z = HUD_CLIP_Z, the near plane of each version (see the minimap branch).
vec4 hudClip(vec2 m) {
    float ratio = ProjMat[1][1] / ProjMat[0][0];     // aspect (larghezza/altezza), col segno della matrice
    float ux = HUD_ASPECT / abs(ratio);
    float boxLeft = MAP_LEFT > 0.5 ? -1.0 + ux * MAP_OFFSET.x
                                   : 1.0 - ux * (MAP_OFFSET.x + MAP_SIZE.x);
    return vec4(boxLeft + ux * m.x, 1.0 - HUD_ASPECT * sign(ratio) * m.y, HUD_CLIP_Z, 1.0);
}

// --- Pannello info (orologio/coordinate/info) sotto la minimap -------------------------------------
// Una SECONDA mappa finta (firma magica diversa, vedi sotto) viene piazzata come striscia larga quanto
// la minimap, subito SOTTO di essa. 21.0 = quante righe (px) della texture del pannello sono
// usate dal testo (il resto della mappa 128x128 e' inutilizzato): l'altezza a schermo e proporzionale a
// queste righe, cosi' i pixel del testo restano quadrati come quelli della minimap. 0.0060 = spazio
// (frazione di schermo, NDC) tra il bordo basso della minimap e il bordo alto del pannello. Entrambi
// sostituiti dal plugin da config (map.minimap.info-panel), come 0.2700.
const float PANEL_ROWS = 21.0;
const float PANEL_GAP  = 0.0060;

// Colori magici dell'header (RGB impacchettati come 0xRRGGBB), come li legge la GPU dalla map texture.
const int MK0 = 0xFF0000;
const int MK1 = 0x597D27;
const int MK2 = 0x3737DC;

int packColor(vec4 c) {
    ivec3 i = ivec3(round(c.rgb * 255.0));
    return (i.r << 16) + (i.g << 8) + i.b;
}

int idAt(ivec2 uv) {
    return packColor(texelFetch(Sampler0, uv, 0));
}

// Un bit dell'header: pixel = MK0 (0xFF0000) -> 1, qualunque altro colore -> 0. idx e' l'indice LINEARE
// del pixel (riga*128 + colonna) a partire dall'angolo (0,0) della map texture; i record delle frecce
// stanno dopo i 3 pixel magici e possono sconfinare nella riga 1 (percio' idx/128 per la riga).
int bitAt(ivec2 base, int idx) {
    ivec2 off = ivec2(idx % 128, idx / 128);
    return (idAt(base + off) == MK0) ? 1 : 0;
}

// Legge n bit (LSB-first) a partire dall'indice lineare start.
int readBits(ivec2 base, int start, int n) {
    int v = 0;
    for (int b = 0; b < 7; b++) {   // 7 = larghezza massima di un campo (px/py)
        if (b >= n) break;
        v |= bitAt(base, start + b) << b;
    }
    return v;
}
#endif

#ifdef IS_GUI
// --- MagixFactions theft HUD (Season 1, step 9): a screen frame and an arrow around the crosshair -------
// The plugin sends a title made of glyphs of the font magicadventure:hud with an EXACT colour mark that no
// vanilla text uses: red 254 and blue 1 (frame) or 2 (arrow). The green channel carries the data: for the
// frame the colour index (0 = yellow, theft; 1 = red, siege; 2 = both: red above, yellow below), for the arrow the direction (0..255 = a full
// turn clockwise from straight ahead). The title is drawn centred on the screen, so every vertex of these
// glyphs is on its own side of the centre: that side picks the corner, whatever the title scale. The frame
// is stretched over the whole screen, the arrow becomes a square around the centre; both are drawn by the
// fragment shader (smooth at any resolution), the glyph texture is almost transparent (invisible without
// this shader). PetTheft.java sends them: marks and font must match.
// The distance under the arrow is the SUBTITLE of the same title, marked red 254 and blue 3 (its shadow, a
// shadow colour set by the plugin, blue 4). Vanilla draws the subtitle centred at scale 2, its line from y 5
// to 13 under the centre (Gui.renderTitle): here every vertex is brought back to scale 1 around the line's
// centre and moved just under the arrow square; the colour becomes the arrow's (the mark is not a colour).
// The SCREEN TRANSITION of MagixPack (teleports and server switches, transition/ScreenTransition.java) uses the
// same mark with blue 5 (closing) or 6 (opening), green = progress 0..255: stretched over the whole screen like
// the frame, drawn by hudTransition() in text.fsh. MagixPack's own text.vsh (the hub, where MagixFactions is not
// installed) does the same for blue 5 and 6 only: if the mark changes, change both.
// The SHIELD BAR of MagixPack (the few seconds of protection after a teleport): blue 7, green = what is left
// 0..255, becomes a thin timer bar just under the crosshair (shieldBar() in text.fsh); its words are the subtitle,
// blue 8 (their shadow blue 9), brought back to scale 1 and centred just over the bar. MagixPack's own text.vsh does
// the same: SHIELD_* and the two branches below are COPIED IDENTICAL there.
// The SPAWN PORTAL ARROW of MagixPack (guide/PortalGuide: always points at the spawn portal): blue 10, green = the
// direction like the theft arrow, sent in the ACTION BAR, not a title. The action bar is not centred on its glyph
// (the words come after it), so the side of the screen centre cannot say a vertex's corner, and gl_VertexID cannot
// either (the GUI batches quads, see the minimap below): guideCorner() reads it from the glyph's own texture.
// The arrow becomes a square of GUIDE_ARROW_HALF round the crosshair, drawn by guideArrow() in text.fsh.
// The PUMPKIN ARROW of MagixHolidays (halloween/HotColdIndicator: points at the nearest small pumpkin) is the same
// glyph marked blue 21 instead of 10: the same arrow in Halloween orange.
// The COMBO BAR of the Friday boss (MagixFactions boss/Combos): blue 18, green = how full 0..255 (the blows of the
// combo over combo.max-hits), a bar under the crosshair drawn by comboBar() in text.fsh, pulsing once full; its words
// are the subtitle, blue 19 (shadow blue 20), brought to COMBO_LABEL_SCALE and centred just over the bar. Only here:
// the boss is on the faction, MagixPack's own text.vsh does not need it.
const vec2 COMBO_BAR_HALF = vec2(52.0, 3.0);    // half size of the combo bar, GUI pixels
const float COMBO_BAR_Y = 40.0;                 // its centre under the screen centre, GUI pixels
const float COMBO_LABEL_SCALE = 1.5;
const vec4 COMBO_LABEL_FILL = vec4(1.0, 0.86, 0.2, 1.0);
const vec4 COMBO_LABEL_SHADOW = vec4(0.3, 0.16, 0.0, 1.0);
const float HUD_ARROW_HALF = 40.0;   // half side of the arrow square, GUI pixels
const float GUIDE_ARROW_HALF = 36.0; // half side of the spawn portal arrow's square, GUI pixels
// MagixQuests' LEVEL UP SHOW (quest/LevelUpShow): a level shield (MagixPack's glyph level_<n>) sent as a title, one title
// per tick, coloured red 254 + a blue mark, green = progress 0..255, no shadow (the picture has its own). Marks:
// LEVEL_SPIN_BLUE the old shield turning on itself faster and faster while it grows and turns white; LEVEL_SHARD_BLUE..+7
// the eight pieces it bursts into (the same glyph eight times one over the other, text.fsh keeps of each only its wedge,
// hudMode 8): they fly away turning, fall and fade; LEVEL_APPEAR_BLUE the new shield coming out of the burst, a pop with
// a spin that slows down to face the player; LEVEL_FLY_BLUE the new shield flying into the scoreboard's place.
// The vertex corner comes from the side of the place vanilla draws the glyph (LEVEL_TITLE_CENTRE: 68 x 80 GUI pixels at
// scale 4, its advance 18 leaves it 2 left of the centre), then the quad is built again round LEVEL_SHOW_CENTRE, so the
// shield sits exactly over the middle of the subtitle (vanilla put the subtitle over the shield's lower part).
// The shadows of those glyphs and of the show's subtitles (coloured red 254 + blue LEVEL_LABEL_BLUE) are never drawn:
// a shadow is the colour times 0.25, so red 63/64 + blue 5..8 (it also drops the shadow of any other text coloured
// about #FF..20-#FF..23, which is harmless). The shield's texture is 120 rows for a sharp title: text.fsh averages it
// where it is drawn smaller than its texels (the scoreboard), see SMOOTH_MARK there.
// LEVEL_FLY_TARGET = where the scoreboard's shield is: x = GUI pixels left of the screen's right edge, y = GUI pixels from
// the sidebar's middle (down positive), both before MagixScoreboard's sidebar-scale; change them here if the flight lands
// beside the shield. LEVEL_FLY_ARC = the arc's height.
const int LEVEL_SPIN_BLUE = 23;
const int LEVEL_SHARD_BLUE = 24;
const int LEVEL_APPEAR_BLUE = 32;
const int LEVEL_LABEL_BLUE = 33;
const int LEVEL_FLY_BLUE = 22;
const vec2 LEVEL_TITLE_CENTRE = vec2(-2.0, -4.0);
const vec2 LEVEL_SHOW_HALF = vec2(34.0, 40.0);
const vec2 LEVEL_SHOW_CENTRE = vec2(0.0, -36.0);
const float LEVEL_SPIN_TURNS = 3.0;
const float LEVEL_SPIN_GROW = 0.55;
const float LEVEL_SHARD_DISTANCE = 150.0;
const float LEVEL_SHARD_FALL = 70.0;
const float LEVEL_APPEAR_TURNS = 2.0;
const vec2 LEVEL_FLY_TARGET = vec2(118.0, -34.0);
const float LEVEL_FLY_ARC = 40.0;
const vec2 SHIELD_BAR_HALF = vec2(46.0, 2.5);   // half size of the shield bar, GUI pixels
const float SHIELD_BAR_Y = 24.0;                // its centre under the screen centre, GUI pixels
const vec4 SHIELD_LABEL_FILL = vec4(0.82, 1.0, 0.9, 1.0);
const vec4 SHIELD_LABEL_SHADOW = vec4(0.03, 0.2, 0.11, 1.0);
const vec4 HUD_LABEL_FILL = vec4(1.0, 0.78, 0.15, 1.0);
const vec4 HUD_LABEL_SHADOW = vec4(0.25, 0.08, 0.0, 1.0);
// The AFK SCREEN of MagixPack (afk/AfkScreen: a player MagixGuard marks as idle, «magix_afk»). Its title starts with
// the glyph of the font magixpack:portal_guide and the space that takes its advance back, marked blue 11: it is
// stretched over the whole screen (the corner read from its texture, guideCorner(): the words after it leave the
// glyph off the screen centre) and drawn by afkScreen() in text.fsh, a frozen, frosted veil with a light blue
// border. The words are three lines. The first is the rest of the title (blue 12, its shadow blue 13): vanilla
// draws it at scale 4 from y -10, here it goes to AFK_LINE1_SCALE from AFK_LINE1_TOP. The subtitle holds the second
// and the third line one after the other (blue 14/15, then 16/17): green = how far that line moves sideways (the
// OTHER line's half width, GUI pixels at scale 1), so each one is centred on its own; vanilla draws the subtitle at
// scale 2 from y 5, here the second goes to AFK_LINE2_SCALE from AFK_LINE2_TOP and the third to scale 1 from
// AFK_LINE3_TOP. All tops are GUI pixels from the screen centre. AFK_* and the branch are COPIED IDENTICAL in
// MagixFactions' and MagixPack's text.vsh: if they change, change both (and AfkScreen.java, which writes the marks).
const float AFK_LINE1_SCALE = 2.0;
const float AFK_LINE1_TOP = -34.0;
const float AFK_LINE2_SCALE = 1.5;
const float AFK_LINE2_TOP = -8.0;
const float AFK_LINE3_TOP = 10.0;
const vec4 AFK_LINE1_FILL = vec4(0.92, 0.98, 1.0, 1.0);
const vec4 AFK_LINE2_FILL = vec4(0.74, 0.92, 1.0, 1.0);
const vec4 AFK_LINE3_FILL = vec4(0.62, 0.82, 0.94, 1.0);
const vec4 AFK_SHADOW = vec4(0.03, 0.14, 0.24, 1.0);
LOC(4) out vec2 hudPos;                     // frame, transition: GUI pixels from the centre; arrow: -1..1 inside the square
LOC(5) flat out int hudMode;                // 0 = vanilla text, 1 = frame, 2 = arrow, 3 = transition, 4 = shield bar,
                                            // 5 = spawn portal arrow, 6 = AFK screen, 7 = combo bar,
                                            // 8 = level up shield (its texture, see LEVEL_SPIN_BLUE),
                                            // 9 = a piece of the minimap on the interface (see MINI_MARK_BLUE),
                                            // 10 = the film's bars, 11 = its black (see CINE_BARS_BLUE)
LOC(6) flat out vec4 hudData;               // frame: half screen size (xy) and colour index (z); arrow, spawn portal
                                            // arrow: angle (x);
                                            // transition: half screen size (xy), progress 0..255 (z), 1 = opening (w);
                                            // shield bar, combo bar: half size in GUI pixels (xy), how full 0..255 (z);
                                            // AFK screen: half screen size (xy), seconds (z, GameTime);
                                            // level up shield: wedge kept (x, -1 = all), how white (y)
uniform sampler2D Sampler0;

// The corner (-1 or 1 on each axis, GUI y down) of a vertex of the spawn portal arrow's glyph. Its texture
// (magixpack:font/portal_guide.png, tools/make_portal_guide.py) says in every texel which quarter it is in: red 0 =
// left half, 255 = right; green 0 = top half, 255 = bottom; blue 77 and alpha 16 mark it. The vertex sits on a corner
// of the glyph in the font atlas: of the four texels round it, the one inside the glyph is the one whose quarter is
// that corner, and the corner is the opposite of the way to it. None found: (0, 0), the quad shrinks to nothing.
vec2 guideCorner() {
    vec2 at = UV0 * vec2(textureSize(Sampler0, 0));
    for (int i = 0; i < 4; i++) {
        vec2 d = vec2((i & 1) == 0 ? -1.0 : 1.0, i < 2 ? -1.0 : 1.0);   // the way to the texel looked at
        ivec4 t = ivec4(round(texelFetch(Sampler0, ivec2(floor(at + 0.5 * d)), 0) * 255.0));
        if (t.b == 77 && t.a == 16 && t.r == (d.x > 0.0 ? 0 : 255) && t.g == (d.y > 0.0 ? 0 : 255)) return -d;
    }
    return vec2(0.0);
}
#endif

#ifdef IS_GUI
// --- MagixPack CINEMA: the newcomers' film (cinematic/CinematicTour) ---------------------------------------------
// The ACTION BAR carries the picture: the glyph of magixpack:portal_guide and its back-space marked red 254 + blue
// CINE_BARS_BLUE (green = how far the black bars are in, 0..255), the same glyph marked CINE_BLACK_BLUE (green = how
// black the whole screen is, 0..255), both stretched over the screen (corner read by guideCorner()) and drawn by
// cinemaScreen() of text.fsh; then the replay hint (blue CINE_REPLAY_BLUE, shadow +1), the scene's heading (blue
// CINE_HEAD_BLUE, shadow +1, in the middle of the top bar, or CINE_CARD_BLUE big over the middle of the picture: the
// opening card) and the skip hint (blue CINE_HINT_BLUE, shadow +1). The two hints go to the ends of the top bar (replay
// on the left, skip on the right: green = half the line's width); the heading's green = 128 + half (skip hint width -
// replay hint width), the way back to the middle. The SUBTITLE holds the two
// lines of the caption one after the other, blue CINE_LINE1_BLUE / CINE_LINE2_BLUE (shadows +1), green = how far that
// line moves sideways (the OTHER line's half width), both in the bottom bar. The titles fade by their own times; the
// action bar is sent again every few ticks. Text scales are whole numbers (sharp letters) that grow with the bars.
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both (and CinematicTour.java).
const int CINE_BARS_BLUE = 40;
const int CINE_BLACK_BLUE = 41;
const int CINE_HEAD_BLUE = 42;
const int CINE_CARD_BLUE = 44;
const int CINE_LINE1_BLUE = 46;
const int CINE_LINE2_BLUE = 48;
const int CINE_HINT_BLUE = 50;
const int CINE_REPLAY_BLUE = 52;
// the opening card in the TITLE, big in the middle of the screen with the MOTD's gradient (magenta to green): blue
// CINE_TITLE_BLUE (shadow +1), green = half its width in title pixels
const int CINE_TITLE_BLUE = 54;
const vec3 CINE_TITLE_FROM = vec3(0.753, 0.275, 0.910);   // #C046E8
const vec3 CINE_TITLE_TO = vec3(0.659, 0.863, 0.173);     // #A8DC2C
const int CINE_RAISED_BLUE = 56;   // the caption's two lines raised over the hotbar (+0/+1 line 1, +2/+3 line 2)
const float CINE_BAR_PART = 0.115;   // each bar, a part of the screen's height
const float CINE_BAR_MIN = 40.0;     // GUI pixels: the hints row + a heading at scale 2
const float CINE_EDGE = 10.0;        // the hints' distance from the left and right edges, GUI pixels
const float CINE_HINT_ROW = 14.0;    // the row of the two hints at the top of the top bar, GUI pixels
const vec4 CINE_HEAD_FILL = vec4(0.93, 0.80, 0.50, 1.0);
const vec4 CINE_CARD_FILL = vec4(1.0, 0.95, 0.84, 1.0);
const vec4 CINE_LINE_FILL = vec4(0.96, 0.96, 0.95, 1.0);
const vec4 CINE_HINT_FILL = vec4(0.58, 0.58, 0.62, 1.0);
const vec4 CINE_SHADOW = vec4(0.0, 0.0, 0.0, 1.0);

// The height of each black bar on a screen of half size h (GUI pixels), whole pixels.
float cinemaBar(vec2 h) {
    return floor(max(CINE_BAR_MIN, CINE_BAR_PART * 2.0 * h.y));
}

// The film's POINTER (a gold arrow bobbing towards what the narrator talks about):
//  - over a tile of a 6-row drawn menu: a glyph of magixpack:portal_guide in the MENU'S TITLE marked red 254 + blue
//    CINE_RECT_BLUE + (w - 1) * 3 + (h - 1) (w 1..9 columns, h 1..3 rows), green = its top left slot (0..89: 0-53 the
//    chest, 54-80 the player's inventory, 81-89 the hotbar), framed with a pulsing gold border, the arrow outside the window beside it;
//  - over a place of the HUD: the same glyph in the ACTION BAR marked CINE_ANCHOR_BLUE + 0 (the stats panel right of
//    the hotbar), 1 (the sidebar), 2 (the minimap), the arrow pointing at it.
// The film's CAPTION inside a drawn menu (the HUD under a menu is dimmed by the screen's backdrop): the two lines are
// written in the menu's title from the title's own start, in the default font, marked CINE_MENU_LINE_BLUE + line * 2
// (+1 the shadow), green = half the line's width; they go to the bottom bar like the subtitle's lines.
const int CINE_ANCHOR_BLUE = 90;
const int CINE_RECT_BLUE = 100;
const int CINE_MENU_LINE_BLUE = 160;
const float CINE_POINT_MARGIN = 12.0;   // room round a framed tile for its glow, GUI pixels
const float CINE_POINT_GAP = 3.0;      // the side arrow's tip from the window's edge, GUI pixels
const float CINE_POINT_ARROW = 42.0;   // room for the side arrow, GUI pixels

// The left and top of a 6-row chest window with the player's inventory (176 x 222), GUI pixels.
vec2 cinemaWindow(vec2 h) {
    return vec2(floor((ceil(2.0 * h.x - 0.01) - 176.0) * 0.5), floor((ceil(2.0 * h.y - 0.01) - 222.0) * 0.5));
}

// The top of a slot row of that window: 0-5 the chest, 6-8 the inventory, 9 the hotbar.
float cinemaSlotY(int row) {
    return row < 6 ? 18.0 + 18.0 * float(row) : row < 9 ? 139.0 + 18.0 * float(row - 6) : 197.0;
}

bool cinemaPointerVertex(ivec3 rgb, vec4 v, vec2 h, float bar, inout vec4 labelColor) {
    if (rgb.b >= CINE_RECT_BLUE && rgb.b < CINE_RECT_BLUE + 27 && rgb.g < 90) {
        int wh = rgb.b - CINE_RECT_BLUE;
        int col = rgb.g - (rgb.g / 9) * 9, row = rgb.g / 9;
        int w = wh / 3 + 1, hh = wh - (wh / 3) * 3 + 1;
        vec2 win = cinemaWindow(h);
        vec2 lo = win + vec2(7.0 + 18.0 * float(col), cinemaSlotY(row) - 1.0);
        vec2 hi = win + vec2(7.0 + 18.0 * float(min(col + w, 9)), cinemaSlotY(min(row + hh - 1, 9)) + 17.0);
        vec2 centre = (lo + hi) * 0.5, half_ = (hi - lo) * 0.5;
        // the arrow OUTSIDE the window, beside the tile's row, pointing at it from the nearer side: over the window it
        // went under the items the client draws after the title (the band, the title light)
        bool right = float(col) + float(w) * 0.5 > 4.5;
        float tip = right ? win.x + 176.0 + CINE_POINT_GAP - centre.x : win.x - CINE_POINT_GAP - centre.x;
        float bmin = min(-half_.x - CINE_POINT_MARGIN, tip - CINE_POINT_ARROW);
        float bmax = max(half_.x + CINE_POINT_MARGIN, tip + CINE_POINT_ARROW);
        vec2 qc = vec2((bmin + bmax) * 0.5, 0.0), qh = vec2((bmax - bmin) * 0.5, half_.y + CINE_POINT_MARGIN);
        vec2 corner = guideCorner();
        hudMode = 12;
        hudPos = qc + corner * qh;
        hudData = vec4(half_, GameTime * 1200.0, tip / 1000.0);   // |w| < 0.5: a framed tile, w * 1000 = the tip's x
        gl_Position = ProjMat * vec4(centre + hudPos, v.z, v.w);
        return true;
    }
    if (rgb.b >= CINE_ANCHOR_BLUE && rgb.b <= CINE_ANCHOR_BLUE + 2) {
        int kind = rgb.b - CINE_ANCHOR_BLUE;
        vec2 at, dir;
        if (kind == 0) {
            at = vec2(floor(h.x) + 91.0 + 6.0 + 34.0, 2.0 * h.y - 24.0);
            dir = vec2(0.0, 1.0);
        } else if (kind == 1) {
            at = vec2(2.0 * h.x - 132.0, h.y);
            dir = vec2(1.0, 0.0);
        } else {
            float unit = 16.0 / 9.0 * h.y;
            float side = 0.27 * unit, margin = 0.03 * unit;
            at = vec2(2.0 * h.x - margin - side - 4.0, margin + side + 4.0);
            dir = normalize(vec2(1.0, -1.0));
        }
        vec2 corner = guideCorner();
        hudMode = 12;
        hudPos = corner * 36.0 - dir * 20.0;    // the tip at hudPos 0, the arrow's body behind it
        hudData = vec4(dir, GameTime * 1200.0, 1.0);
        gl_Position = ProjMat * vec4(at - dir * 20.0 + corner * 36.0, v.z, v.w);
        return true;
    }
    if (rgb.b >= CINE_MENU_LINE_BLUE && rgb.b <= CINE_MENU_LINE_BLUE + 3) {
        int line = (rgb.b - CINE_MENU_LINE_BLUE) / 2;
        bool shadow = (rgb.b - CINE_MENU_LINE_BLUE) % 2 == 1;
        vec2 win = cinemaWindow(h);
        float s = max(1.0, floor(bar / 30.0));
        vec2 local = v.xy - (win + vec2(8.0, 6.0)) - vec2(float(rgb.g), 4.5);
        float gap = 5.5 * s + 1.0;
        vec2 at = local * s + vec2(0.0, h.y - bar * 0.5 + (line == 0 ? -gap : gap));
        gl_Position = ProjMat * vec4(h + at, v.z, v.w);
        labelColor = vec4((shadow ? CINE_SHADOW : CINE_LINE_FILL).rgb, Color.a);
        return true;
    }
    return false;
}

// A vertex of the film's picture or words: moved where it goes (gl_Position, hudMode, hudPos, hudData, labelColor);
// false for any other vertex.
bool cinemaVertex(ivec3 rgb, inout vec4 labelColor) {
    if (rgb.r != 254 || rgb.b < CINE_BARS_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    float bar = cinemaBar(h);
    if (rgb.b > CINE_TITLE_BLUE + 1 && (rgb.b < CINE_RAISED_BLUE || rgb.b > CINE_RAISED_BLUE + 3)) {
        return cinemaPointerVertex(rgb, v, h, bar, labelColor);
    }
    float s = max(1.0, floor(bar / 30.0));
    if (rgb.b == CINE_BARS_BLUE || rgb.b == CINE_BLACK_BLUE) {
        vec2 corner = guideCorner();
        hudMode = rgb.b == CINE_BARS_BLUE ? 10 : 11;
        hudPos = corner * h;
        hudData = vec4(h, float(rgb.g), bar);
        gl_Position = ProjMat * vec4(h + corner * h, v.z, v.w);
        return true;
    }
    int kind = (rgb.b - CINE_HEAD_BLUE) / 2;   // 0 heading, 1 card, 2 caption line 1, 3 caption line 2, 4 hint, 5 replay
    bool shadow = (rgb.b - CINE_HEAD_BLUE) % 2 == 1;
    // the caption RAISED over the hotbar (the scene that points at the HUD, without bars): CINE_RAISED_BLUE..+3
    bool raised = rgb.b >= CINE_RAISED_BLUE && rgb.b <= CINE_RAISED_BLUE + 3;
    if (raised) {
        kind = rgb.b < CINE_RAISED_BLUE + 2 ? 2 : 3;
        shadow = (rgb.b - CINE_RAISED_BLUE) % 2 == 1;
    } else if (rgb.b == CINE_TITLE_BLUE || rgb.b == CINE_TITLE_BLUE + 1) {
        // the title: vanilla draws it at scale 4 from y -10 round the middle; centred on the middle here
        vec2 local = (v.xy - h) / 4.0 + vec2(0.0, 5.5);
        float u = clamp(local.x / max(1.0, float(rgb.g)) * 0.5 + 0.5, 0.0, 1.0);
        vec3 grad = mix(CINE_TITLE_FROM, CINE_TITLE_TO, u);
        bool titleShadow = rgb.b == CINE_TITLE_BLUE + 1;
        gl_Position = ProjMat * vec4(h + local * max(2.0, floor(h.y / 40.0)), v.z, v.w);
        labelColor = vec4(titleShadow ? grad * 0.22 : grad, Color.a);
        return true;
    } else if (rgb.b > CINE_REPLAY_BLUE + 1) {
        return false;
    }
    vec2 at;
    vec4 fill;
    // the action bar: scale 1 from (width / 2, height - 68), the text from y -4
    vec2 bar1 = v.xy - vec2(h.x, 2.0 * h.y - 68.0) - vec2(0.0, 0.5);
    if (kind <= 1) {
        // the heading, in the action bar between the hints: back to the middle, then scaled
        vec2 local = bar1 + vec2(float(rgb.g) - 128.0, 0.0);
        if (kind == 0) {
            // big in the middle of the top bar, under the row of the two hints
            at = local * max(2.0, s) + vec2(0.0, -h.y + (bar + CINE_HINT_ROW) * 0.5);
            fill = CINE_HEAD_FILL;
        } else {
            at = local * max(2.0, floor(h.y / 40.0)) + vec2(0.0, -h.y * 0.12);
            fill = CINE_CARD_FILL;
        }
    } else if (kind <= 3) {
        // the subtitle: vanilla draws it at scale 2 from y 5
        vec2 local = (v.xy - h) / 2.0 - vec2(0.0, 9.5);
        local.x += kind == 2 ? float(rgb.g) : -float(rgb.g);
        float gap = 5.5 * s + 1.0;
        at = local * s + vec2(0.0, h.y - bar * 0.5 + (kind == 2 ? -gap : gap) - (raised ? bar * 0.5 + 30.0 : 0.0));
        fill = CINE_LINE_FILL;
    } else if (kind == 4) {
        at = vec2(h.x - CINE_EDGE - float(rgb.g) + bar1.x, -h.y + CINE_HINT_ROW * 0.5 + 2.0 + bar1.y);
        fill = CINE_HINT_FILL;
    } else {
        at = vec2(-h.x + CINE_EDGE + float(rgb.g) + bar1.x, -h.y + CINE_HINT_ROW * 0.5 + 2.0 + bar1.y);
        fill = CINE_HINT_FILL;
    }
    gl_Position = ProjMat * vec4(h + at, v.z, v.w);
    labelColor = vec4((shadow ? CINE_SHADOW : fill).rgb, Color.a);
    return true;
}
#endif

#ifdef IS_GUI
// --- MagixFactions MINIMAP ON THE INTERFACE (minimap/HudMinimap) --------------------------------------------------
// For the clients that never show the map minimap above (Lunar Client and the shader packs draw the fake frames' maps
// with their own renderer): the same minimap as a grid of cells, sent as the glyphs of the font
// magicadventure:placed_minimap in two see-through boss bars. A glyph of ours is known from its TEXTURE: every corner
// texel is a mark (blue MINI_MARK_BLUE, alpha MINI_TEXEL_ALPHA, red bit 7 = right column + the glyph's id in the low
// bits, green 255 = bottom row), read like guideCorner() so the vertex knows its corner. Every character gives two
// quads, the glyph (vertex alpha 255: its blue byte says the piece, the data in red and green) and its shadow (the
// shadow colour's alpha says the piece: see HudMinimap.java for the whole table; the client draws every shadow of a
// text before its glyphs, so the terrain is in the shadows and the borders, home and frame over it in the glyphs),
// and each quad is one PIECE of the minimap whose place and data are in its colour: here the
// quad is built again where the piece goes (in pixels of the 128-pixel minimap, k GUI pixels each, in the box the
// map minimap has: MAP_SIZE, MAP_OFFSET, MAP_LEFT of the world variant) and text.fsh (miniPiece) draws it. hudMode 9;
// hudPos = the fragment in map pixels; hudData and miniData = the piece (miniData.w = what it is: 0 a run of terrain
// cells, 1 a border run, 2 an arrow, 3 the home, 4 the compass and the frame, 5 the panel's background, 6 a letter of
// the panel). The run's quad is half a cell wider on every side: its EARS (miniData.x) are the triangles that smooth
// a diagonal, the same corner cut smartSample makes on the map minimap. A letter's picture is the map font's glyph
// with a frame of one texel (10 rows): its quad is placed in panel pixels, the panel starting MINI_PANEL_TOP map
// pixels under the box's top (the gap in map units, like hudClip), and the fragment samples its texture.
// The palette is the map's own (MapPalette, written by ResourcePackContent); MINI_CELLS = map.minimap.interface.cells.
const int MINI_MARK_BLUE = 91, MINI_TEXEL_ALPHA = 16;
const float MINI_CELLS = 64.0;
const float MINI_MAP_SIZE = 0.2700;
const float MINI_MAP_MARGIN = 0.03;      // = MAP_OFFSET of the world variant
const float MINI_MAP_LEFT = 0.0;
const float MINI_HUD_ASPECT = 16.0 / 9.0;
const float MINI_PANEL_ROWS = 21.0;
const float MINI_PANEL_TOP = 128.0 + 0.0060 / MINI_MAP_SIZE * 128.0;
const vec3 MINI_BORDER[3] = vec3[](vec3(0.3333, 1.0000, 0.3333), vec3(1.0000, 0.3333, 1.0000), vec3(1.0000, 0.3333, 0.3333));
const vec3 MINI_PALETTE[248] = vec3[](vec3(0.0000, 0.0000, 0.0000),vec3(0.0000, 0.0000, 0.0000),vec3(0.0000, 0.0000, 0.0000),vec3(0.0000, 0.0000, 0.0000),vec3(0.3490, 0.4902, 0.1529),vec3(0.4275, 0.6000, 0.1882),vec3(0.4980, 0.6980, 0.2196),vec3(0.2627, 0.3686, 0.1137),vec3(0.6824, 0.6431, 0.4510),vec3(0.8353, 0.7882, 0.5490),vec3(0.9686, 0.9137, 0.6392),vec3(0.5098, 0.4824, 0.3373),vec3(0.5490, 0.5490, 0.5490),vec3(0.6706, 0.6706, 0.6706),vec3(0.7804, 0.7804, 0.7804),vec3(0.4118, 0.4118, 0.4118),vec3(0.7059, 0.0000, 0.0000),vec3(0.8627, 0.0000, 0.0000),vec3(1.0000, 0.0000, 0.0000),vec3(0.5294, 0.0000, 0.0000),vec3(0.4392, 0.4392, 0.7059),vec3(0.5412, 0.5412, 0.8627),vec3(0.6275, 0.6275, 1.0000),vec3(0.3294, 0.3294, 0.5294),vec3(0.4588, 0.4588, 0.4588),vec3(0.5647, 0.5647, 0.5647),vec3(0.6549, 0.6549, 0.6549),vec3(0.3451, 0.3451, 0.3451),vec3(0.0000, 0.3412, 0.0000),vec3(0.0000, 0.4157, 0.0000),vec3(0.0000, 0.4863, 0.0000),vec3(0.0000, 0.2549, 0.0000),vec3(0.7059, 0.7059, 0.7059),vec3(0.8627, 0.8627, 0.8627),vec3(1.0000, 1.0000, 1.0000),vec3(0.5294, 0.5294, 0.5294),vec3(0.4510, 0.4627, 0.5059),vec3(0.5529, 0.5647, 0.6196),vec3(0.6431, 0.6588, 0.7216),vec3(0.3373, 0.3451, 0.3804),vec3(0.4157, 0.2980, 0.2118),vec3(0.5098, 0.3686, 0.2588),vec3(0.5922, 0.4275, 0.3020),vec3(0.3098, 0.2235, 0.1569),vec3(0.3098, 0.3098, 0.3098),vec3(0.3765, 0.3765, 0.3765),vec3(0.4392, 0.4392, 0.4392),vec3(0.2314, 0.2314, 0.2314),vec3(0.1765, 0.1765, 0.7059),vec3(0.2157, 0.2157, 0.8627),vec3(0.2510, 0.2510, 1.0000),vec3(0.1294, 0.1294, 0.5294),vec3(0.3922, 0.3294, 0.1961),vec3(0.4824, 0.4000, 0.2431),vec3(0.5608, 0.4667, 0.2824),vec3(0.2941, 0.2471, 0.1490),vec3(0.7059, 0.6941, 0.6745),vec3(0.8627, 0.8510, 0.8275),vec3(1.0000, 0.9882, 0.9608),vec3(0.5294, 0.5216, 0.5059),vec3(0.5961, 0.3490, 0.1412),vec3(0.7294, 0.4275, 0.1725),vec3(0.8471, 0.4980, 0.2000),vec3(0.4471, 0.2627, 0.1059),vec3(0.4902, 0.2078, 0.5961),vec3(0.6000, 0.2549, 0.7294),vec3(0.6980, 0.2980, 0.8471),vec3(0.3686, 0.1569, 0.4471),vec3(0.2824, 0.4235, 0.5961),vec3(0.3451, 0.5176, 0.7294),vec3(0.4000, 0.6000, 0.8471),vec3(0.2118, 0.3176, 0.4471),vec3(0.6314, 0.6314, 0.1412),vec3(0.7725, 0.7725, 0.1725),vec3(0.8980, 0.8980, 0.2000),vec3(0.4745, 0.4745, 0.1059),vec3(0.3490, 0.5647, 0.0667),vec3(0.4275, 0.6902, 0.0824),vec3(0.4980, 0.8000, 0.0980),vec3(0.2627, 0.4235, 0.0510),vec3(0.6667, 0.3490, 0.4549),vec3(0.8157, 0.4275, 0.5569),vec3(0.9490, 0.4980, 0.6471),vec3(0.5020, 0.2627, 0.3412),vec3(0.2078, 0.2078, 0.2078),vec3(0.2549, 0.2549, 0.2549),vec3(0.2980, 0.2980, 0.2980),vec3(0.1569, 0.1569, 0.1569),vec3(0.4235, 0.4235, 0.4235),vec3(0.5176, 0.5176, 0.5176),vec3(0.6000, 0.6000, 0.6000),vec3(0.3176, 0.3176, 0.3176),vec3(0.2078, 0.3490, 0.4235),vec3(0.2549, 0.4275, 0.5176),vec3(0.2980, 0.4980, 0.6000),vec3(0.1569, 0.2627, 0.3176),vec3(0.3490, 0.1725, 0.4902),vec3(0.4275, 0.2118, 0.6000),vec3(0.4980, 0.2471, 0.6980),vec3(0.2627, 0.1294, 0.3686),vec3(0.1412, 0.2078, 0.4902),vec3(0.1725, 0.2549, 0.6000),vec3(0.2000, 0.2980, 0.6980),vec3(0.1059, 0.1569, 0.3686),vec3(0.2824, 0.2078, 0.1412),vec3(0.3451, 0.2549, 0.1725),vec3(0.4000, 0.2980, 0.2000),vec3(0.2118, 0.1569, 0.1059),vec3(0.2824, 0.3490, 0.1412),vec3(0.3451, 0.4275, 0.1725),vec3(0.4000, 0.4980, 0.2000),vec3(0.2118, 0.2627, 0.1059),vec3(0.4235, 0.1412, 0.1412),vec3(0.5176, 0.1725, 0.1725),vec3(0.6000, 0.2000, 0.2000),vec3(0.3176, 0.1059, 0.1059),vec3(0.0667, 0.0667, 0.0667),vec3(0.0824, 0.0824, 0.0824),vec3(0.0980, 0.0980, 0.0980),vec3(0.0510, 0.0510, 0.0510),vec3(0.6902, 0.6588, 0.2118),vec3(0.8431, 0.8039, 0.2588),vec3(0.9804, 0.9333, 0.3020),vec3(0.5176, 0.4941, 0.1569),vec3(0.2510, 0.6039, 0.5882),vec3(0.3098, 0.7373, 0.7176),vec3(0.3608, 0.8588, 0.8353),vec3(0.1882, 0.4510, 0.4392),vec3(0.2039, 0.3529, 0.7059),vec3(0.2471, 0.4314, 0.8627),vec3(0.2902, 0.5020, 1.0000),vec3(0.1529, 0.2627, 0.5294),vec3(0.0000, 0.6000, 0.1569),vec3(0.0000, 0.7333, 0.1961),vec3(0.0000, 0.8510, 0.2275),vec3(0.0000, 0.4471, 0.1176),vec3(0.3569, 0.2353, 0.1333),vec3(0.4353, 0.2902, 0.1647),vec3(0.5059, 0.3373, 0.1922),vec3(0.2667, 0.1765, 0.0980),vec3(0.3098, 0.0039, 0.0000),vec3(0.3765, 0.0039, 0.0000),vec3(0.4392, 0.0078, 0.0000),vec3(0.2314, 0.0039, 0.0000),vec3(0.5765, 0.4863, 0.4431),vec3(0.7059, 0.5961, 0.5412),vec3(0.8196, 0.6941, 0.6314),vec3(0.4314, 0.3647, 0.3333),vec3(0.4392, 0.2235, 0.0980),vec3(0.5373, 0.2745, 0.1216),vec3(0.6235, 0.3216, 0.1412),vec3(0.3294, 0.1686, 0.0745),vec3(0.4118, 0.2392, 0.2980),vec3(0.5020, 0.2941, 0.3647),vec3(0.5843, 0.3412, 0.4235),vec3(0.3059, 0.1804, 0.2235),vec3(0.3098, 0.2980, 0.3804),vec3(0.3765, 0.3647, 0.4667),vec3(0.4392, 0.4235, 0.5412),vec3(0.2314, 0.2235, 0.2863),vec3(0.5137, 0.3647, 0.0980),vec3(0.6275, 0.4471, 0.1216),vec3(0.7294, 0.5216, 0.1412),vec3(0.3843, 0.2745, 0.0745),vec3(0.2824, 0.3216, 0.1451),vec3(0.3451, 0.3922, 0.1765),vec3(0.4039, 0.4588, 0.2078),vec3(0.2118, 0.2392, 0.1098),vec3(0.4392, 0.2118, 0.2157),vec3(0.5412, 0.2588, 0.2627),vec3(0.6275, 0.3020, 0.3059),vec3(0.3294, 0.1569, 0.1608),vec3(0.1569, 0.1098, 0.0941),vec3(0.1922, 0.1373, 0.1176),vec3(0.2235, 0.1608, 0.1373),vec3(0.1176, 0.0824, 0.0706),vec3(0.3725, 0.2941, 0.2706),vec3(0.4549, 0.3608, 0.3294),vec3(0.5294, 0.4196, 0.3843),vec3(0.2784, 0.2196, 0.2000),vec3(0.2392, 0.2510, 0.2510),vec3(0.2941, 0.3098, 0.3098),vec3(0.3412, 0.3608, 0.3608),vec3(0.1804, 0.1882, 0.1882),vec3(0.3373, 0.2000, 0.2431),vec3(0.4118, 0.2431, 0.2941),vec3(0.4784, 0.2863, 0.3451),vec3(0.2510, 0.1490, 0.1804),vec3(0.2078, 0.1686, 0.2510),vec3(0.2549, 0.2078, 0.3098),vec3(0.2980, 0.2431, 0.3608),vec3(0.1569, 0.1255, 0.1882),vec3(0.2078, 0.1373, 0.0941),vec3(0.2549, 0.1686, 0.1176),vec3(0.2980, 0.1961, 0.1373),vec3(0.1569, 0.1020, 0.0706),vec3(0.2078, 0.2235, 0.1137),vec3(0.2549, 0.2745, 0.1412),vec3(0.2980, 0.3216, 0.1647),vec3(0.1569, 0.1686, 0.0863),vec3(0.3922, 0.1647, 0.1255),vec3(0.4784, 0.2000, 0.1529),vec3(0.5569, 0.2353, 0.1804),vec3(0.2941, 0.1216, 0.0941),vec3(0.1020, 0.0588, 0.0431),vec3(0.1216, 0.0706, 0.0510),vec3(0.1451, 0.0863, 0.0627),vec3(0.0745, 0.0431, 0.0314),vec3(0.5216, 0.1294, 0.1333),vec3(0.6392, 0.1608, 0.1647),vec3(0.7412, 0.1882, 0.1922),vec3(0.3922, 0.0980, 0.0980),vec3(0.4078, 0.1725, 0.2667),vec3(0.4980, 0.2118, 0.3255),vec3(0.5804, 0.2471, 0.3804),vec3(0.3059, 0.1294, 0.2000),vec3(0.2510, 0.0667, 0.0784),vec3(0.3098, 0.0824, 0.0980),vec3(0.3608, 0.0980, 0.1137),vec3(0.1882, 0.0510, 0.0588),vec3(0.0588, 0.3451, 0.3686),vec3(0.0706, 0.4235, 0.4510),vec3(0.0863, 0.4941, 0.5255),vec3(0.0431, 0.2588, 0.2745),vec3(0.1569, 0.3922, 0.3843),vec3(0.1961, 0.4784, 0.4706),vec3(0.2275, 0.5569, 0.5490),vec3(0.1176, 0.2941, 0.2902),vec3(0.2353, 0.1216, 0.1686),vec3(0.2902, 0.1451, 0.2078),vec3(0.3373, 0.1725, 0.2431),vec3(0.1765, 0.0902, 0.1255),vec3(0.0549, 0.4980, 0.3647),vec3(0.0667, 0.6078, 0.4471),vec3(0.0784, 0.7059, 0.5216),vec3(0.0392, 0.3725, 0.2745),vec3(0.2745, 0.2745, 0.2745),vec3(0.3373, 0.3373, 0.3373),vec3(0.3922, 0.3922, 0.3922),vec3(0.2039, 0.2039, 0.2039),vec3(0.5961, 0.4824, 0.4039),vec3(0.7294, 0.5882, 0.4941),vec3(0.8471, 0.6863, 0.5765),vec3(0.4471, 0.3608, 0.3020),vec3(0.3490, 0.4588, 0.4118),vec3(0.4275, 0.5647, 0.5059),vec3(0.4980, 0.6549, 0.5882),vec3(0.2627, 0.3451, 0.3098));
LOC(7) flat out vec4 miniData;

// The corner of a vertex of a minimap glyph whose id is {@code id} (0 the cell, 1.. a letter, -1 any of ours): xy = -1
// or 1 on each axis (GUI y down), z = 0; z < 0 when none of the texels round the vertex is such a mark (not our glyph,
// or a mark of the glyph next to it in a packed atlas: the id tells them apart).
ivec3 miniCorner(int id) {
    vec2 at = UV0 * vec2(textureSize(Sampler0, 0));
    for (int i = 0; i < 4; i++) {
        vec2 d = vec2((i & 1) == 0 ? -1.0 : 1.0, i < 2 ? -1.0 : 1.0);   // the way to the texel looked at
        ivec4 t = ivec4(round(texelFetch(Sampler0, ivec2(floor(at + 0.5 * d)), 0) * 255.0));
        if (t.b == MINI_MARK_BLUE && t.a == MINI_TEXEL_ALPHA && (id < 0 || (t.r & 127) == id)
                && (t.r >= 128) == (d.x < 0.0) && (t.g >= 128) == (d.y < 0.0)) {
            return ivec3(ivec2(-d), 0);
        }
    }
    return ivec3(0, 0, -1);
}
#endif

#ifdef IS_GUI
// --- MagixScoreboard: grandezza della sidebar uguale per tutti (config sidebar-scale) ---------------
// Il client disegna la sidebar alla Scala GUI di ogni giocatore. Qui si sostituisce quella scala con una
// scelta dal server, solo per la sidebar. Le distanze dal punto a cui il client aggancia la sidebar (bordo
// destro, meta' altezza: vedi gui.vsh di MagixScoreboard) si moltiplicano per scala voluta / scala del
// giocatore: il risultato e' la sidebar che vanilla disegnerebbe alla scala voluta.
// SB_SCALE_MODE: 0 = off (vanilla), 1 = in proporzione all'altezza dello schermo, 2 = la scala intera
// piu' vicina a quella proporzione. SB_SCALE_FACTOR = grandezza di un pixel della sidebar per pixel di
// altezza dello schermo, calcolata dal plugin (ResourcePackContent, stessa regola di SidebarPack.scaleFactor
// di MagixScoreboard): col mode "minimap" e' il pixel del testo del pannello info (1 pixel del font mappa =
// 1 pixel della mappa = lato della minimap / 128), cosi' i due testi sono grandi uguali.
// QUESTA FUNZIONE E' COPIATA IDENTICA in gui.vsh di MagixScoreboard: se si cambia, si cambiano entrambe.
const int SB_SCALE_MODE = 1;
const float SB_SCALE_FACTOR = 0.00187500;

float sbScaleFactor(float guiW, float guiH) {
    if (SB_SCALE_MODE == 0 || ScreenSize.y < 1.0 || guiH < 1.0) return 1.0;
    // Scala GUI del giocatore: il client fa guiW = ceil(pixel / scala), quindi pixel / guiW e' la scala
    // (appena sotto quando la divisione non e' esatta: per questo round).
    float player = max(round(max(ScreenSize.x / guiW, ScreenSize.y / guiH)), 1.0);
    float wanted = ScreenSize.y * SB_SCALE_FACTOR;
    if (SB_SCALE_MODE == 2) wanted = max(round(wanted), 1.0);
    return wanted / player;
}
#endif

#ifdef IS_GUI
// --- HUD GROWTH WITH THE GUI SCALE (owner 25/10: on a laptop minimap and scoreboard were too small) -----------------
// Minimap, its info panel, the sidebar and the corner HUD are a share of the screen HEIGHT, whatever the GUI scale: on
// a small 1080p screen they are physically small, while the player's own GUI scale (hotbar, chat) is bigger. Here they
// grow TOGETHER with the GUI scale the player chose: hudGrow() = 1 + HUD_GROW_WEIGHT x (player scale / the scale the
// minimap's text has on that screen - 1), kept between HUD_GROW_MIN and HUD_GROW_MAX (map.minimap.gui-scale of
// MagixFactions, baked by ResourcePackContent; HUD_GROW_BASE = screen-size * 16 / 9 / 256, the minimap text's scale per
// pixel of height). The right column (minimap, panel, sidebar) grows round the screen's top right corner on the
// minimap's margin, so the gaps between them grow too and nothing overlaps; the corner HUD round its own corner.
// THIS FUNCTION IS COPIED UNCHANGED in gui.vsh of MagixScoreboard (the sidebar's background): change both together.
const float HUD_GROW_WEIGHT = 0.5000;
const float HUD_GROW_MIN = 1.0000;
const float HUD_GROW_MAX = 1.2500;
const float HUD_GROW_BASE = 0.00187500;
const float HUD_GROW_TOP = 16.0 / 9.0 * 0.03 * 0.5;   // the minimap's margin as a share of the screen height

float hudGrow(float guiW, float guiH) {
    if (HUD_GROW_WEIGHT <= 0.0 || HUD_GROW_BASE <= 0.0 || ScreenSize.y < 1.0 || guiH < 1.0) return 1.0;
    float player = max(round(max(ScreenSize.x / guiW, ScreenSize.y / guiH)), 1.0);
    float proportional = ScreenSize.y * HUD_GROW_BASE;
    return clamp(1.0 + HUD_GROW_WEIGHT * (player / proportional - 1.0), HUD_GROW_MIN, HUD_GROW_MAX);
}

// A point of the right column (GUI pixels) grown round the screen's top right corner on the minimap's margin.
vec2 hudGrowRight(vec2 at, float guiW, float guiH) {
    vec2 corner = vec2(guiW, HUD_GROW_TOP * guiH);
    return corner + (at - corner) * hudGrow(guiW, guiH);
}
#endif

#ifdef IS_GUI
// --- MagixFactions BOSS BAR IN TWO LINES (hud/BossBarHud.java) -------------------------------------------------
// The fight's boss bar sends the boss's name and an info line (health, faction players it was made for) as ONE
// title. Every character carries red 252 and blue = 64 + line * 32 + shadow * 16 + colour index (the legacy
// colours of BOSS_PALETTE), green = GUI pixels to move it sideways: the name (line 0) right, the info (line 1) left
// and BOSS_LINE_DY down, under the bar. The client centres the whole title, so each line ends up centred on its
// own. The colour becomes the palette's (the mark is not a colour), the shadow a quarter of it, as vanilla.
const float BOSS_LINE_DY = 16.0;   // from the title's line (y 3) to just under the bar (y 12..17)
const vec3 BOSS_PALETTE[16] = vec3[16](
    vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.667), vec3(0.0, 0.667, 0.0), vec3(0.0, 0.667, 0.667),
    vec3(0.667, 0.0, 0.0), vec3(0.667, 0.0, 0.667), vec3(1.0, 0.667, 0.0), vec3(0.667, 0.667, 0.667),
    vec3(0.333, 0.333, 0.333), vec3(0.333, 0.333, 1.0), vec3(0.333, 1.0, 0.333), vec3(0.333, 1.0, 1.0),
    vec3(1.0, 0.333, 0.333), vec3(1.0, 0.333, 1.0), vec3(1.0, 1.0, 0.333), vec3(1.0, 1.0, 1.0));
#endif

#ifdef IS_GUI
// --- CORNER HUD: a boss bar title drawn in the screen's TOP LEFT corner (MagixHolidays halloween/Leaderboard) --------
// The client centres a boss bar's title over its bar. A plugin that wants a panel in the top left corner sends a title
// exactly CORNER_HUD_WIDTH GUI pixels wide (padded with spaces) as a boss bar of the player: the client puts its left
// edge at floor(screen width / 2) - CORNER_HUD_WIDTH / 2 and its line at 3 + 19 * (bars shown before it). Here every
// marked character is moved so that the panel's body (CORNER_HUD_GLOW in from the title's top left corner) sits as far
// from the screen's top and left sides as the minimap from its top and right ones (MAP_OFFSET), WHATEVER boss bar line
// it is on: every vertex says itself where it goes in the panel, so the line is only found and thrown away. Two marks:
//  - TEXT (the game's letters, any bitmap font no taller than its own): red CORNER_TEXT_RED, green = GUI pixels from the
//    panel's top to the line's top + 1, blue = the index of its colour in CORNER_PALETTE + 16 for its shadow (the
//    plugin sets that shadow colour itself: the client's own shadow, a quarter of the mark, would stay in the middle).
//    Fill = the palette colour, shadow = a quarter of it, as vanilla. Its vertices are 3 over to 10 under the line.
//  - PICTURES: glyphs exactly CORNER_IMAGE_HEIGHT GUI pixels tall whose top is 3 over the line (ascent 10), so a
//    vertex is a top one or a bottom one. Red = one of CORNER_IMAGE_REDS (the two high bits of 18), green and blue the
//    16 others: GUI pixels from the panel's top to the picture's top + 1 (7 bits), then the tint in RGB 4-4-3 (white =
//    the picture as it is; the faces' pixels too). Their shadow is turned off by the plugin.
// So every marked vertex is 0 to 16 GUI pixels under 19 * its bar's index: floor(y / 19) is that index.
// The panel is then scaled round its body's top left corner by sbScaleFactor() (MagixScoreboard's sidebar-scale, the
// same for everyone) times CORNER_HUD_SCALE (owner 21/10: the board's letters looked bigger than the scoreboard's).
// Only characters inside the band where such a title can be are moved (x within the title's width, y over the screen's
// top 200 pixels): a chat line with that very red elsewhere stays where it is. Not on 26.1 clients (no GUI text shader;
// the plugin does not send it to them).
const int CORNER_TEXT_RED = 247;
const ivec4 CORNER_IMAGE_REDS = ivec4(240, 241, 242, 244);   // never 243: 243/251 green/blue would be the sidebar's mark
const float CORNER_IMAGE_HEIGHT = 16.0;
const float CORNER_HUD_WIDTH = 164.0;
const float CORNER_HUD_GLOW = 3.0;
const float CORNER_HUD_SCALE = 0.8;
const float CORNER_HUD_BAND = 200.0;
// the minimap's margin as a share of the screen height: HUD_ASPECT * MAP_OFFSET.y / 2 of the minimap's branch (those
// constants live in the world variant only): keep it equal if they change
const float CORNER_HUD_MARGIN = 16.0 / 9.0 * 0.03 * 0.5;
// --- HOTBAR HUD: the same marks, another place: right of the hotbar (MagixQuests upgrade/StatsHud, owner 25/10) ------
// A TEXT mark whose blue is 32 + the colour index (+ 16 for its shadow) belongs to a second panel: a boss bar title
// exactly HOTBAR_HUD_WIDTH GUI pixels wide, moved so that its left edge is HOTBAR_HUD_GAP right of the hotbar and its
// top on the hotbar's top (HOTBAR_HUD_UP over the screen's bottom: the hotbar is 182 x 22 in the bottom middle), at the
// GUI's own scale like the hotbar. Its pictures are glyphs of a bitmap font marked like text (white = the picture as it
// is), each inside its boss bar line (at most 11 tall with ascent 10). Pictures marked like the corner's (CORNER_IMAGE_REDS) always go to the corner.
const float HOTBAR_HUD_WIDTH = 256.0;
const float HOTBAR_HUD_GAP = 6.0;
const float HOTBAR_HUD_UP = 22.0;
const vec3 CORNER_PALETTE[16] = vec3[16](
    vec3(1.0, 1.0, 1.0),          // 0 white
    vec3(0.604, 0.549, 0.659),    // 1 grey violet #9A8CA8
    vec3(1.0, 0.761, 0.239),      // 2 gold #FFC23D
    vec3(1.0, 0.541, 0.110),      // 3 orange #FF8A1C
    vec3(0.753, 0.275, 0.910),    // 4 violet #C046E8
    vec3(1.0, 0.925, 0.784),      // 5 cream #FFECC8
    vec3(0.769, 0.549, 0.078),    // 6 dark gold #C48C14
    vec3(0.549, 0.588, 0.651),    // 7 dark silver #8C96A6
    vec3(0.588, 0.329, 0.141),    // 8 dark bronze #965424
    vec3(0.902, 0.882, 0.941),    // 9 lavender #E6E1F0
    vec3(1.0, 0.839, 0.251),      // 10 medal gold #FFD640
    vec3(0.839, 0.871, 0.910),    // 11 silver #D6DEE8
    vec3(0.498, 0.839, 1.0),      // 12 sky #7FD6FF (the stats panel's speed; was bronze #DE8C48, unused)
    vec3(0.353, 0.314, 0.408),    // 13 dark grey violet #5A5068
    vec3(0.486, 0.878, 0.439),    // 14 green #7CE070
    vec3(1.0, 0.314, 0.314));     // 15 red #FF5050
#endif

#ifdef IS_GUI
// --- MagixPack menu MARQUEE: a menu label too wide for its box scrolls from right to left -------------------
// MagixPack (menu/MenuPanel.marquee, a label wider than its max) writes every character of the label in a colour
// of its own: red 253 (the mark), green = the character's distance from the label's start, blue = the label's whole
// width rounded up to 8 (GUI pixels) + the index of its box in MARQUEE_BOXES (= MenuPanel.MARQUEE_BOXES). Here every
// character moves left with time and comes back on the right after the end (one copy of the text, then
// MARQUEE_GAP), fading in and out at the edges of the box, from the label's start. After each turn the text rests
// MARQUEE_HOLD seconds at its start. The words are drawn white (the mark is not a colour).
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both.
const float MARQUEE_BOXES[8] = float[8](36.0, 48.0, 64.0, 80.0, 96.0, 112.0, 144.0, 192.0); // GUI pixels (the fades reach MARQUEE_FADE past each edge: a tile's 36 + 8 inside its 3 slots)
const float MARQUEE_GAP = 18.0;     // between the end of the text and its start coming back
const float MARQUEE_SPEED = 16.0;   // GUI pixels per second
const float MARQUEE_HOLD = 1.5;     // seconds at the start of each turn
const float MARQUEE_FADE = 4.0;     // GUI pixels of fading at each edge
const float MARQUEE_CHAR = 5.0;     // the width of a character, for the right edge

// --- MagixPack panel CREDITS: a side panel of a drawn menu with more lines than fit scrolls up like end credits ------
// MagixPack (menu/MenuPanel.panel, a panel with more lines than menu-panel.lines) writes every character of the panel
// on the panel's FIRST text row, in a colour of its own: red 250 (the mark), green = the line's number (0-31) + 32 * its
// colour (an index of CREDITS_PALETTE), blue = how many lines the panel has. Here every character goes down to its line
// minus the distance scrolled with time: the lines leave at the top of the window (CREDITS_LINES lines of CREDITS_LINE
// GUI pixels) and come back from its bottom, fading at both edges; each turn starts with CREDITS_HOLD seconds still.
// Never 251: 251 % 8 == 3, the mark of MagixFactions' sidebar lines (every channel % 8 == 3), whose reddest colours have
// red 251: on 17/10 the scoreboard scrolled up like the panel. Only blue 2..32 with the line under it counts.
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both (and MenuPanel.CREDITS_*).
const float CREDITS_LINE = 10.0;    // = menu-panel.line-height
const float CREDITS_LINES = 15.0;   // = menu-panel.lines: the window's height in lines
const float CREDITS_GAP = 3.0;      // empty lines between the last line and the first coming back
const float CREDITS_SPEED = 9.0;    // GUI pixels per second
const float CREDITS_HOLD = 3.0;     // seconds still at the start of each turn
const float CREDITS_FADE = 8.0;     // GUI pixels of fading at the top and the bottom
const float CREDITS_TOP_FADE = 3.0; // GUI pixels over the window's top in which a line leaving fades out: never more,
                                    // the panel's glyph (the avatar) sits right over it (owner 4/11: lines crossed it)
const vec3 CREDITS_PALETTE[8] = vec3[](vec3(1.0), vec3(0.6667), vec3(1.0, 0.761, 0.239), vec3(1.0, 0.541, 0.541),
        vec3(0.498, 0.839, 1.0), vec3(0.333, 0.902, 0.510), vec3(0.788, 0.733, 0.847), vec3(0.604, 0.549, 0.659));
#endif

#ifdef IS_GUI
// --- MagixPack COMPACT MENUS: a drawn menu fits a screen too short or too narrow for it --------------------------
// The client centres a chest's window and never moves its slots (clicks land where the client thinks the slots are),
// but everything MagixPack draws AROUND the window is ours to move. With a big GUI scale on a small screen (scale 4 on
// 1920x1080: 480 x 270 GUI pixels, 253 in a window) the page under a drawn menu (518 wide, up to 328 tall with the
// boss banner) went off the screen. Three marks, all written by MagixPack (menu/MenuPanel):
//  - a PIECE OF THE PAGE (menu-page/<id>.png): red FIT_PAGE_RED, green 128 + zone + 4 * (rows - 1), blue = how far the
//    page reaches above its window (GUI pixels). The page is cut on the window's top and bottom lines and on the edges
//    of its side margins, so every piece is in one zone: 0 beside or behind the window (never moved), 1 above it
//    (squeezed towards the window's top until it fits between it and the screen's top), 2 under it (its bottom
//    stops at the screen's bottom). Every piece is also kept inside the screen's width (only the side margins,
//    pure landscape, reach past the banner's width). rows = the chest's rows: the window's top is where the client
//    puts it, (screen height - (114 + 18 * rows)) / 2 rounded down.
//  - a piece of the BANNER above the window (its picture or board): red FIT_BANNER_RED, green 160 + rows, blue = how
//    far the banner's top is above the window. When the window's top is nearer to the screen's top than that, the
//    banner cannot fit: it goes away (with its labels, and the sharp copy drawn by items: MagixPack's
//    position_tex_color.vsh, same rule).
//  - a LETTER above the window (the fonts of the label rows above the title's line, any colour): a see-through texel
//    in each corner of its texture, red = the banner's height above the window as above, green = 64 + 1 (right
//    column) + 2 (bottom row), blue = 128 + the window's top minus that corner's y. Found like guideCorner().
// Everything keeps FIT_MARGIN GUI pixels from the screen's edges (owner, 17/10: the menu must never touch them).
// Marked pieces are drawn white (the marks are not colours). Nothing changes while the menu fits. A vertex sent out
// of the screen with its three companions is not drawn. A LETTER is never moved: its vertex only turns see-through
// (alpha 0, fitLetterHidden), and only when its mark agrees with where a window's top is (fitLetterOnWindow); a real
// letter has its four vertices marked, so all of it goes, while a vertex misread on another glyph only fades a piece of
// it (23/10, Lunar Client: the tablist's names still drew red streaks to the bottom left with FIT_GONE).
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both (and MenuPanel.FIT_*,
// and menu-panel/position_tex_color.vsh of MagixPack).
const int FIT_PAGE_RED = 249;
const int FIT_BANNER_RED = 248;
const float FIT_MARGIN = 6.0;   // GUI pixels kept free between the menu and the screen's edges (= position_tex_color.vsh)
const vec4 FIT_GONE = vec4(-4.0, -4.0, 0.0, 1.0);

// The window's top (GUI y) of a chest of that many rows on a screen guiH GUI pixels tall. The projection may say a
// height that is not whole (the window's pixels divided by the GUI scale, e.g. 344.25), while the client lays the screen
// out on that height rounded UP (Window.guiScaledHeight): rounding it any other way put the window's top one pixel off,
// and a line of the world showed between the squeezed page and the window (17/10).
float fitWindowTop(float guiH, int rows) {
    return floor((ceil(guiH - 0.01) - float(114 + 18 * rows)) * 0.5);
}

// The mark of a letter above the window (see FIT_PAGE_RED): x = the window's top minus this vertex's y, y = the
// banner's height above the window; y < 0: no mark (any other letter).
vec2 fitLetterMark() {
    vec2 at = UV0 * vec2(textureSize(Sampler0, 0));
    for (int i = 0; i < 4; i++) {
        vec2 d = vec2((i & 1) == 0 ? -1.0 : 1.0, i < 2 ? -1.0 : 1.0);   // the way to the texel looked at
        ivec4 t = ivec4(round(texelFetch(Sampler0, ivec2(floor(at + 0.5 * d)), 0) * 255.0));
        int corner = (d.x < 0.0 ? 1 : 0) + (d.y < 0.0 ? 2 : 0);          // the texel is inside, the vertex on this corner
        if (t.a == 0 && t.g == 64 + corner && t.r > 0) return vec2(float(t.b - 128), float(t.r));
    }
    return vec2(0.0, -1.0);
}

// A letter's mark says where the window's top is (its y + the mark). A mark read from ANOTHER glyph next to this one in
// the font atlas (Lunar Client packs its glyphs with no gap between them: the corner texel of a marked letter is then
// also round a corner of its neighbour) says a window's top that is nowhere: such a vertex is left alone. Before this
// (19/10) single vertices of the boss bar and of Lunar's HUD text went out of the screen and drew long streaks of
// light from the bottom left corner, and letters lost a piece («Boss» read «Loss»). Since 23/10 a hidden letter is not
// moved at all (fitLetterHidden): a misread vertex can no longer draw a streak, whatever coincidence lets it through.
bool fitLetterOnWindow(float windowTop, float guiH) {
    for (int rows = 1; rows <= 6; rows++) {
        if (abs(windowTop - fitWindowTop(guiH, rows)) <= 1.5) return true;
    }
    return false;
}
#endif

void main() {
    // Default: comportamento vanilla identico allo stock, per ognuna delle tre varianti.
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#ifdef IS_GUI
    // MagixFactions minimap on the interface (see MINI_MARK_BLUE): a piece of it leaves here, placed and coloured.
    miniData = vec4(0.0);
    {
        int miniA = int(round(Color.a * 255.0));
        ivec3 miniRgb = ivec3(round(Color.rgb * 255.0));
        int miniD = (miniRgb.r << 16) | (miniRgb.g << 8) | miniRgb.b;
        // 0 run, 1 border, 2 arrow, 3 home, 4 compass + frame, 5 panel background, 6 letter, 7 nothing, -1 no family
        int miniKind = -1, miniEars = 0, miniId = 0;
        if (miniA == 255) {
            miniKind = miniRgb.b >= 248 && miniRgb.b <= 250 ? 1 : miniRgb.b == 251 ? 3 : miniRgb.b == 252 ? 4 : 7;
        }
        else if (miniA >= 64 && miniA < 80) { miniKind = 0; miniEars = miniA - 64; }
        else if (miniA >= 97 && miniA <= 100) miniKind = 2;
        else if (miniA == 103) miniKind = 5;
        else if (miniA >= 128 && miniA < 160) { miniKind = 6; miniId = (miniD >> 8) & 127; }
        else if (miniA == 32) miniKind = 7;
        // "nothing" hides any glyph of ours (the white glyph of a letter character too): its id does not matter
        ivec3 miniC = miniKind < 0 ? ivec3(0, 0, -1) : miniCorner(miniKind == 7 ? -1 : miniId);
        if (miniC.z >= 0) {
            vec4 miniVert = ModelViewMat * vec4(Position, 1.0);
            texCoord0 = UV0;
            vertexColor = vec4(0.0);
            hudMode = 0;
            hudPos = vec2(0.0);
            hudData = vec4(0.0);
            if (miniKind != 7) {
                float miniW = abs(2.0 / ProjMat[0][0]), miniH = abs(2.0 / ProjMat[1][1]);
                float miniUnit = MINI_HUD_ASPECT * miniH * 0.5;                 // GUI pixels per map unit (hudClip)
                // the side grows with the GUI scale (hudGrow), round the box's top right or top left corner
                float miniSide = MINI_MAP_SIZE * miniUnit * hudGrow(miniW, miniH), miniMargin = MINI_MAP_MARGIN * miniUnit;
                vec2 miniBox = vec2(MINI_MAP_LEFT > 0.5 ? miniMargin : miniW - miniMargin - miniSide, miniMargin);
                float miniK = miniSide / 128.0;                                 // GUI pixels per map pixel
                float miniCell = 128.0 / MINI_CELLS;
                bool miniBig = MINI_CELLS > 64.5;
                vec2 miniLo, miniHi;                                            // the quad, map pixels
                hudMode = 9;
                if (miniKind == 0) {
                    float row = float(miniBig ? (miniD >> 8) & 127 : (miniD >> 8) & 63);
                    float col = float(miniBig ? (miniD >> 15) & 127 : (miniD >> 14) & 63);
                    float len = float(miniBig ? (miniD >> 22) & 3 : (miniD >> 20) & 15) + 1.0;
                    vec4 rect = vec4(col, row, col + len, row + 1.0) * miniCell;
                    miniLo = rect.xy - 0.5 * miniCell;
                    miniHi = rect.zw + 0.5 * miniCell;
                    hudData = rect;
                    miniData = vec4(float(miniEars), miniCell, 0.0, 0.0);
                    vertexColor = vec4(MINI_PALETTE[miniD & 255], 1.0);
                } else if (miniKind == 1) {
                    // a cell of territory border (a glyph: blue 248 + relation, the cell and its sides in red and green)
                    int d16 = (miniD >> 8) & 0xFFFF;
                    float row = float(miniBig ? d16 & 127 : d16 & 63);
                    float col = float(miniBig ? (d16 >> 7) & 127 : (d16 >> 6) & 63);
                    int sides = miniBig ? 1 << ((d16 >> 14) & 3) : (d16 >> 12) & 15;
                    vec4 rect = vec4(col, row, col + 1.0, row + 1.0) * miniCell;
                    miniLo = rect.xy;
                    miniHi = rect.zw;
                    hudData = rect;
                    miniData = vec4(float(sides), miniCell, 0.0, 1.0);
                    vertexColor = vec4(MINI_BORDER[miniRgb.b - 248], 1.0);
                } else if (miniKind == 2) {
                    vec2 at = vec2(float(miniD & 127), float((miniD >> 7) & 127));
                    miniLo = at - 4.0;
                    miniHi = at + 4.0;
                    hudData = vec4(at, float((miniD >> 14) & 31) / 32.0 * 6.28318530718, float(miniA - 97));
                    miniData = vec4(0.0, 0.0, 0.0, 2.0);
                    vertexColor = vec4(1.0);
                } else if (miniKind == 3) {
                    int d16 = (miniD >> 8) & 0xFFFF;   // the home: a glyph, blue 251 (bit 14: the raid's target)
                    vec2 at = vec2(float(d16 & 127), float((d16 >> 7) & 127));
                    miniLo = at - 3.0;
                    miniHi = at + 4.0;
                    hudData = vec4(miniLo, float((d16 >> 14) & 1), 0.0);
                    miniData = vec4(0.0, 0.0, 0.0, 3.0);
                    vertexColor = vec4(1.0);
                } else if (miniKind == 4) {
                    miniLo = vec2(0.0);
                    miniHi = vec2(128.0);
                    miniData = vec4(0.0, 0.0, 0.0, 4.0);
                    vertexColor = vec4(1.0);
                } else if (miniKind == 5) {
                    miniLo = vec2(0.0, MINI_PANEL_TOP);
                    miniHi = vec2(128.0, MINI_PANEL_TOP + MINI_PANEL_ROWS);
                    miniData = vec4(0.0, 0.0, 0.0, 5.0);
                    vertexColor = vec4(MINI_PALETTE[miniD & 255], 1.0);
                } else {
                    float x = float((miniD >> 15) & 127), line = float((miniD >> 22) & 3), w = float(miniA - 128);
                    miniLo = vec2(x - 1.0, MINI_PANEL_TOP + 2.0 + line * 9.0 - 1.0);
                    miniHi = miniLo + vec2(w + 2.0, 10.0);
                    hudData = vec4(miniLo + 1.0, w, 0.0);                       // the ink's top left, its width
                    miniData = vec4(0.0, 0.0, 0.0, 6.0);
                    vertexColor = vec4(MINI_PALETTE[miniD & 255], 1.0);
                }
                vec2 miniAt = vec2(miniC.x < 0 ? miniLo.x : miniHi.x, miniC.y < 0 ? miniLo.y : miniHi.y);
                hudPos = miniAt;
                gl_Position = ProjMat * vec4(miniBox + miniAt * miniK, miniVert.z, miniVert.w);
            }
            return;
        }
    }

    // MagixScoreboard: sidebar spostata in verticale (config sidebar-position di MagixScoreboard, letto
    // da MagixFactions perche' questo file e' suo nel pacchetto unico). Il client la centra sempre un po'
    // sopra la meta' dello schermo; qui si spostano le scritte (e le icone, che sono glifi di testo) della
    // sidebar. Le si riconosce dal MARCHIO nel colore che mette MagixScoreboard (SidebarMark): rosso,
    // verde e blu tutti = 3 modulo 8, cosa che nessun colore vanilla fa. Senza marchio si spostavano
    // anche i tooltip degli oggetti (sfondo fermo, lore fuori dal riquadro). In piu' devono cadere nella
    // fascia in cui la sidebar puo' stare: a destra, larga 200.0 pixel (in verticale ovunque, vedi
    // sotto). Lo sfondo lo sposta lo shader gui di MagixScoreboard della stessa quantita'.
    // Poi la GRANDEZZA (config sidebar-scale di MagixScoreboard): vedi sbScaleFactor. Stessa formula, stesso
    // punto fisso e stesso ordine (prima lo spostamento, poi la scala) dello shader gui, cosi' scritte e
    // sfondo restano sovrapposti.
    if (60.0 != 0.0 || SB_SCALE_MODE != 0) {
        vec4 sbPos = ModelViewMat * vec4(Position, 1.0);
        float sbW = abs(2.0 / ProjMat[0][0]);
        float sbH = abs(2.0 / ProjMat[1][1]);
        ivec3 sbRgb = ivec3(round(Color.rgb * 255.0));
        bool sbMarked = all(equal(sbRgb % 8, ivec3(3)));
        // Every marked line, at any height (since 19/10): Lunar Client's Scoreboard mod draws the sidebar where the player
        // put it, often lower than vanilla's band; the lines inside the band were moved and resized, the others not, and
        // the sidebar came apart. Moved together, the sidebar stays whole wherever it is.
        if (sbMarked && sbPos.x > sbW - 200.0) {
            vec2 sbAnchor = vec2(sbW, sbH * 0.5);
            vec2 sbQ = vec2(sbPos.x, sbPos.y + 60.0);
            sbQ = sbAnchor + (sbQ - sbAnchor) * sbScaleFactor(sbW, sbH);
            sbQ = hudGrowRight(sbQ, sbW, sbH);   // then with the GUI scale, like the minimap over it
            gl_Position = ProjMat * vec4(sbQ, sbPos.z, sbPos.w);
        }
    }

    // MagixFactions theft HUD (see the note above HUD_ARROW_HALF).
    hudMode = 0;
    hudPos = vec2(0.0);
    hudData = vec4(0.0);
    vec4 hudLabelColor = vec4(-1.0);
    ivec3 hudRgb = ivec3(round(Color.rgb * 255.0));
    if ((hudRgb.r == 63 || hudRgb.r == 64) && hudRgb.b >= 5 && hudRgb.b <= 8) {
        // the shadow of a level up shield or subtitle (see LEVEL_LABEL_BLUE): not drawn, the picture has its own
        gl_Position = vec4(-4.0, -4.0, 0.0, 1.0);
    } else if (hudRgb.r == 254 && hudRgb.b >= LEVEL_FLY_BLUE && hudRgb.b <= LEVEL_APPEAR_BLUE) {
        // MagixQuests' level up show (see LEVEL_SPIN_BLUE): the quad of the shield built again round its new centre.
        vec4 lvVert = ModelViewMat * vec4(Position, 1.0);
        vec2 lvHalf = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
        vec2 lvCorner = vec2(lvVert.x - lvHalf.x > LEVEL_TITLE_CENTRE.x ? 1.0 : -1.0,
                lvVert.y - lvHalf.y > LEVEL_TITLE_CENTRE.y ? 1.0 : -1.0);
        vec2 lvLocal = lvCorner * LEVEL_SHOW_HALF;
        vec2 lvCentre = lvHalf + LEVEL_SHOW_CENTRE;
        float lvT = float(hudRgb.g) / 255.0;
        float lvWhite = 0.0;
        float lvAlpha = 1.0;
        float lvSector = -1.0;
        if (hudRgb.b == LEVEL_SPIN_BLUE) {
            // turning on itself, faster and faster (a fake perspective: the side coming forward is taller), growing,
            // white at the end
            float a = 6.28318530718 * LEVEL_SPIN_TURNS * lvT * lvT;
            float grow = 1.0 + LEVEL_SPIN_GROW * lvT * lvT;
            lvLocal = vec2(lvLocal.x * cos(a), lvLocal.y * (1.0 + 0.18 * lvCorner.x * sin(a))) * grow;
            lvWhite = smoothstep(0.6, 1.0, lvT);
        } else if (hudRgb.b == LEVEL_APPEAR_BLUE) {
            // the new shield: out of nothing to a bit too big and back (back-out), two turns slowing down, white at first
            float u = lvT - 1.0;
            float pop = max(0.0, 1.0 + 2.70158 * u * u * u + 1.70158 * u * u);
            float a = 6.28318530718 * LEVEL_APPEAR_TURNS * (1.0 - (1.0 - lvT) * (1.0 - lvT) * (1.0 - lvT));
            lvLocal = vec2(lvLocal.x * cos(a), lvLocal.y * (1.0 + 0.18 * lvCorner.x * sin(a))) * pop;
            lvWhite = 1.0 - smoothstep(0.0, 0.55, lvT);
        } else if (hudRgb.b == LEVEL_FLY_BLUE) {
            // into the scoreboard: a little arc upwards, shrinking from the title's scale 4 to the sidebar's, fading there
            vec2 flyScreen = lvHalf * 2.0;
            float flyE = lvT * lvT * (3.0 - 2.0 * lvT);
            float flySb = sbScaleFactor(flyScreen.x, flyScreen.y);
            vec2 flyAnchor = vec2(flyScreen.x, lvHalf.y);
            vec2 flyTarget = vec2(flyScreen.x - LEVEL_FLY_TARGET.x, lvHalf.y + LEVEL_FLY_TARGET.y + 60.0);
            flyTarget = flyAnchor + (flyTarget - flyAnchor) * flySb;
            flyTarget = hudGrowRight(flyTarget, flyScreen.x, flyScreen.y);
            flySb *= hudGrow(flyScreen.x, flyScreen.y);
            lvCentre = mix(lvCentre, flyTarget, flyE);
            lvCentre.y -= sin(flyE * 3.14159265) * LEVEL_FLY_ARC;
            lvLocal *= mix(1.0, flySb / 4.0, flyE);
            lvAlpha = 1.0 - smoothstep(0.82, 1.0, lvT);
        } else {
            // a piece of the burst: out along its wedge, turning round its own middle, falling, fading
            float k = float(hudRgb.b - LEVEL_SHARD_BLUE);
            float dirA = (k + 0.5) / 8.0 * 6.28318530718;
            vec2 dir = vec2(cos(dirA), sin(dirA));
            float grow = 1.0 + LEVEL_SPIN_GROW;
            vec2 mid = dir * LEVEL_SHOW_HALF * 0.55 * grow;
            float out1 = 1.0 - (1.0 - lvT) * (1.0 - lvT);
            vec2 offset = dir * LEVEL_SHARD_DISTANCE * (0.8 + 0.06 * k) * out1 + vec2(0.0, LEVEL_SHARD_FALL * lvT * lvT);
            float turn = (mod(k, 2.0) < 0.5 ? 1.0 : -1.0) * (2.0 + 0.4 * k) * lvT;
            vec2 rel = lvLocal * grow * (1.0 - 0.35 * lvT) - mid;
            rel = vec2(rel.x * cos(turn) - rel.y * sin(turn), rel.x * sin(turn) + rel.y * cos(turn));
            lvLocal = mid + rel + offset;
            lvWhite = 1.0 - smoothstep(0.0, 0.35, lvT);
            lvAlpha = 1.0 - smoothstep(0.45, 1.0, lvT);
            lvSector = k;
        }
        gl_Position = ProjMat * vec4(lvCentre + lvLocal, lvVert.z, lvVert.w);
        hudMode = 8;
        hudPos = lvCorner;
        hudData = vec4(lvSector, lvWhite, 0.0, 0.0);
        hudLabelColor = vec4(1.0, 1.0, 1.0, Color.a * lvAlpha);
    } else if (hudRgb.r == 254 && hudRgb.b >= 1 && hudRgb.b <= 21) {
        vec4 hudVert = ModelViewMat * vec4(Position, 1.0);
        vec2 hudHalf = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
        vec2 hudCorner = vec2(hudVert.x > hudHalf.x ? 1.0 : -1.0, hudVert.y > hudHalf.y ? 1.0 : -1.0);
        if (hudRgb.b == 18) {
            // the boss's combo bar (see COMBO_BAR_HALF): hudPos -1..1 across it
            hudMode = 7;
            hudPos = hudCorner;
            hudData = vec4(COMBO_BAR_HALF, float(hudRgb.g), 0.0);
            gl_Position = ProjMat * vec4(hudHalf + vec2(0.0, COMBO_BAR_Y) + hudCorner * COMBO_BAR_HALF, hudVert.z, hudVert.w);
        } else if (hudRgb.b == 19 || hudRgb.b == 20) {
            // its words (the subtitle, drawn at scale 2 from y 5 to 13): COMBO_LABEL_SCALE, centred just over the bar
            vec2 hudLocal = ((hudVert.xy - hudHalf) * 0.5 - vec2(0.0, 9.0)) * COMBO_LABEL_SCALE;
            vec2 hudAt = hudHalf + hudLocal + vec2(0.0, COMBO_BAR_Y - COMBO_BAR_HALF.y - 4.0 * COMBO_LABEL_SCALE - 2.0);
            gl_Position = ProjMat * vec4(hudAt, hudVert.z, hudVert.w);
            hudLabelColor = vec4((hudRgb.b == 19 ? COMBO_LABEL_FILL : COMBO_LABEL_SHADOW).rgb, Color.a);
        } else if (hudRgb.b >= 11) {
            // MagixPack AFK screen (see AFK_LINE1_SCALE).
            if (hudRgb.b == 11) {
                vec2 afkCorner = guideCorner();
                hudMode = 6;
                hudPos = afkCorner * hudHalf;
                hudData = vec4(hudHalf, GameTime * 1200.0, 0.0);
                gl_Position = ProjMat * vec4(hudHalf + afkCorner * hudHalf, hudVert.z, hudVert.w);
            } else {
                int afkLine = (hudRgb.b - 12) / 2;
                bool afkShadow = (hudRgb.b - 12) % 2 == 1;
                vec2 afkLocal = hudVert.xy - hudHalf;
                vec2 afkAt;
                if (afkLine == 0) {
                    afkAt = (afkLocal / 4.0 + vec2(0.0, 10.0)) * AFK_LINE1_SCALE + vec2(0.0, AFK_LINE1_TOP);
                } else {
                    vec2 afkU = afkLocal / 2.0 - vec2(0.0, 5.0);
                    afkU.x += afkLine == 1 ? float(hudRgb.g) : -float(hudRgb.g);
                    afkAt = afkLine == 1 ? afkU * AFK_LINE2_SCALE + vec2(0.0, AFK_LINE2_TOP)
                            : afkU + vec2(0.0, AFK_LINE3_TOP);
                }
                gl_Position = ProjMat * vec4(hudHalf + afkAt, hudVert.z, hudVert.w);
                vec4 afkFill = afkLine == 0 ? AFK_LINE1_FILL : afkLine == 1 ? AFK_LINE2_FILL : AFK_LINE3_FILL;
                hudLabelColor = vec4((afkShadow ? AFK_SHADOW : afkFill).rgb, Color.a);
            }
        } else if (hudRgb.b == 10 || hudRgb.b == 21) {
            // MagixPack spawn portal arrow (blue 10, green) or MagixHolidays' pumpkin arrow (blue 21, orange): a square
            // round the crosshair, hudPos -1..1 inside it, hudData.y = which colours.
            vec2 guide = guideCorner();
            hudMode = 5;
            hudPos = guide;
            hudData = vec4(float(hudRgb.g) / 256.0 * 6.28318530718, hudRgb.b == 21 ? 1.0 : 0.0, 0.0, 0.0);
            gl_Position = ProjMat * vec4(hudHalf + guide * GUIDE_ARROW_HALF, hudVert.z, hudVert.w);
        } else if (hudRgb.b == 7) {
            // MagixPack shield bar: a thin bar under the crosshair, hudPos -1..1 across it.
            hudMode = 4;
            hudPos = hudCorner;
            hudData = vec4(SHIELD_BAR_HALF, float(hudRgb.g), 0.0);
            gl_Position = ProjMat * vec4(hudHalf + vec2(0.0, SHIELD_BAR_Y) + hudCorner * SHIELD_BAR_HALF, hudVert.z, hudVert.w);
        } else if (hudRgb.b >= 8) {
            // its words (the subtitle, drawn at scale 2 from y 5 to 13): scale 1, centred just over the bar
            vec2 hudLocal = (hudVert.xy - hudHalf) * 0.5 - vec2(0.0, 9.0);
            vec2 hudAt = hudHalf + hudLocal + vec2(0.0, SHIELD_BAR_Y - SHIELD_BAR_HALF.y - 6.5);
            gl_Position = ProjMat * vec4(hudAt, hudVert.z, hudVert.w);
            hudLabelColor = vec4((hudRgb.b == 8 ? SHIELD_LABEL_FILL : SHIELD_LABEL_SHADOW).rgb, Color.a);
        } else if (hudRgb.b >= 5) {
            // MagixPack screen transition: the whole screen, like the frame.
            hudMode = 3;
            hudPos = hudCorner * hudHalf;
            hudData = vec4(hudHalf, float(hudRgb.g), hudRgb.b == 6 ? 1.0 : 0.0);
            gl_Position = ProjMat * vec4(hudHalf + hudCorner * hudHalf, hudVert.z, hudVert.w);
        } else if (hudRgb.b >= 3) {
            vec2 hudLocal = (hudVert.xy - hudHalf) * 0.5 - vec2(0.0, 9.0);
            vec2 hudAt = hudHalf + hudLocal + vec2(0.0, HUD_ARROW_HALF + 9.0);
            gl_Position = ProjMat * vec4(hudAt, hudVert.z, hudVert.w);
            hudLabelColor = vec4((hudRgb.b == 3 ? HUD_LABEL_FILL : HUD_LABEL_SHADOW).rgb, Color.a);
        } else if (hudRgb.b == 1) {
            hudMode = 1;
            hudPos = hudCorner * hudHalf;
            hudData = vec4(hudHalf, float(hudRgb.g), 0.0);
            gl_Position = ProjMat * vec4(hudHalf + hudCorner * hudHalf, hudVert.z, hudVert.w);
        } else {
            hudMode = 2;
            hudPos = hudCorner;
            hudData = vec4(float(hudRgb.g) / 256.0 * 6.28318530718, 0.0, 0.0, 0.0);
            gl_Position = ProjMat * vec4(hudHalf + hudCorner * HUD_ARROW_HALF, hudVert.z, hudVert.w);
        }
    }
    // MagixPack cinema, the newcomers' film (see CINE_BARS_BLUE).
    cinemaVertex(hudRgb, hudLabelColor);
#endif

#ifdef IS_GUI
    // MagixFactions boss bar in two lines (see BOSS_LINE_DY).
    vec4 bossColor = vec4(-1.0);
    ivec3 bossRgb = ivec3(round(Color.rgb * 255.0));
    if (bossRgb.r == 252 && bossRgb.b >= 64 && bossRgb.b < 128) {
        int bossCode = bossRgb.b - 64;
        int bossLine = bossCode / 32;
        vec4 bossVert = ModelViewMat * vec4(Position, 1.0);
        float bossShift = bossLine == 0 ? float(bossRgb.g) : -float(bossRgb.g);
        gl_Position = ProjMat * vec4(bossVert.x + bossShift, bossVert.y + (bossLine == 0 ? 0.0 : BOSS_LINE_DY), bossVert.zw);
        vec3 bossFill = BOSS_PALETTE[bossCode % 16];
        bossColor = vec4((bossCode % 32) >= 16 ? bossFill * 0.25 : bossFill, Color.a);
    }
#endif

#ifdef IS_GUI
    // Corner HUD (see CORNER_HUD_WIDTH).
    vec4 cornerColor = vec4(-1.0);
    {
        ivec3 cornerRgb = ivec3(round(Color.rgb * 255.0));
        bool cornerText = cornerRgb.r == CORNER_TEXT_RED && cornerRgb.b < 64;
        bool cornerHotbar = cornerText && cornerRgb.b >= 32;     // the panel right of the hotbar (HOTBAR_HUD_WIDTH)
        int cornerHigh = cornerRgb.r == CORNER_IMAGE_REDS.x ? 0 : cornerRgb.r == CORNER_IMAGE_REDS.y ? 1
                : cornerRgb.r == CORNER_IMAGE_REDS.z ? 2 : cornerRgb.r == CORNER_IMAGE_REDS.w ? 3 : -1;
        if (cornerText || cornerHigh >= 0) {
            vec4 cornerVert = ModelViewMat * vec4(Position, 1.0);
            float cornerScreenW = round(abs(2.0 / ProjMat[0][0]));
            float cornerScreenH = abs(2.0 / ProjMat[1][1]);
            float cornerWidth = cornerHotbar ? HOTBAR_HUD_WIDTH : CORNER_HUD_WIDTH;
            float cornerLeft = floor(cornerScreenW * 0.5) - cornerWidth * 0.5;
            if (cornerVert.x >= cornerLeft - 2.0 && cornerVert.x <= cornerLeft + cornerWidth + 2.0
                    && cornerVert.y < CORNER_HUD_BAND) {
                float cornerLine = floor(cornerVert.y / 19.0) * 19.0;   // 3 over the boss bar line's text
                vec2 cornerRel = vec2(cornerVert.x - cornerLeft, 0.0);  // GUI pixels in the panel, y + 1
                if (cornerText) {
                    cornerRel.y = cornerVert.y - cornerLine - 3.0 + float(cornerRgb.g);
                    vec3 cornerFill = CORNER_PALETTE[cornerRgb.b % 16];
                    cornerColor = vec4(cornerRgb.b % 32 >= 16 ? cornerFill * 0.25 : cornerFill, Color.a);
                } else {
                    int cornerBits = (cornerHigh << 16) | (cornerRgb.g << 8) | cornerRgb.b;
                    bool cornerBottom = cornerVert.y - cornerLine > CORNER_IMAGE_HEIGHT * 0.5;
                    cornerRel.y = float(cornerBits >> 11) + (cornerBottom ? CORNER_IMAGE_HEIGHT : 0.0);
                    cornerColor = vec4(float((cornerBits >> 7) & 15) / 15.0, float((cornerBits >> 3) & 15) / 15.0,
                            float(cornerBits & 7) / 7.0, Color.a);
                }
                if (cornerHotbar) {
                    // right of the hotbar, at the GUI's scale: the panel's row 0 HOTBAR_HUD_UP over the bottom
                    cornerVert.xy = vec2(floor(cornerScreenW * 0.5) + 91.0 + HOTBAR_HUD_GAP,
                            cornerScreenH - HOTBAR_HUD_UP) + cornerRel - vec2(0.0, 1.0);
                } else {
                    // the body's top left corner on the minimap's margin, the rest scaled round it
                    float cornerMargin = CORNER_HUD_MARGIN * cornerScreenH;
                    float cornerScale = sbScaleFactor(cornerScreenW, cornerScreenH) * CORNER_HUD_SCALE
                            * hudGrow(cornerScreenW, cornerScreenH);
                    cornerVert.xy = vec2(cornerMargin) + (cornerRel - vec2(CORNER_HUD_GLOW, CORNER_HUD_GLOW + 1.0)) * cornerScale;
                }
                gl_Position = ProjMat * cornerVert;
            }
        }
    }
#endif

#ifdef IS_GUI
    // MagixPack menu marquee (see MARQUEE_BOXES).
    float marqueeAlpha = -1.0;
    ivec3 marqueeRgb = ivec3(round(Color.rgb * 255.0));
    if (marqueeRgb.r == 253) {
        float marqueeOffset = float(marqueeRgb.g);
        int marqueeBoxIndex = marqueeRgb.b - (marqueeRgb.b / 8) * 8;
        float marqueeBox = MARQUEE_BOXES[marqueeBoxIndex];
        float marqueePeriod = float(marqueeRgb.b - marqueeBoxIndex) + MARQUEE_GAP;
        float marqueeTurn = marqueePeriod / MARQUEE_SPEED + MARQUEE_HOLD;
        float marqueeShift = max(0.0, mod(GameTime * 1200.0, marqueeTurn) - MARQUEE_HOLD) * MARQUEE_SPEED;
        // where the character is now, from the label's start: -FADE .. period - FADE (out on the left = back on the right)
        float marqueeAt = mod(marqueeOffset - marqueeShift + MARQUEE_FADE, marqueePeriod) - MARQUEE_FADE;
        vec4 marqueeVert = ModelViewMat * vec4(Position, 1.0);
        gl_Position = ProjMat * vec4(marqueeVert.x + marqueeAt - marqueeOffset, marqueeVert.yzw);
        marqueeAlpha = clamp((marqueeAt + MARQUEE_FADE) / MARQUEE_FADE, 0.0, 1.0)
                * clamp((marqueeBox - MARQUEE_CHAR - marqueeAt) / MARQUEE_FADE + 1.0, 0.0, 1.0);
    }
    // MagixPack panel credits (see CREDITS_LINE).
    float creditsAlpha = -1.0;
    vec3 creditsColour = vec3(1.0);
    if (marqueeRgb.r == 250 && marqueeRgb.b >= 2 && marqueeRgb.b <= 32 && marqueeRgb.g % 32 < marqueeRgb.b) {
        float creditsLine = float(marqueeRgb.g % 32);
        creditsColour = CREDITS_PALETTE[marqueeRgb.g / 32];
        float creditsPeriod = (float(marqueeRgb.b) + CREDITS_GAP) * CREDITS_LINE;
        float creditsTurn = creditsPeriod / CREDITS_SPEED + CREDITS_HOLD;
        float creditsShift = max(0.0, mod(GameTime * 1200.0, creditsTurn) - CREDITS_HOLD) * CREDITS_SPEED;
        // where the line is now, from the window's top: -FADE .. period - FADE (out at the top = back at the bottom)
        float creditsAt = mod(creditsLine * CREDITS_LINE - creditsShift + CREDITS_FADE, creditsPeriod) - CREDITS_FADE;
        vec4 creditsVert = ModelViewMat * vec4(Position, 1.0);
        gl_Position = ProjMat * vec4(creditsVert.x, creditsVert.y + creditsAt, creditsVert.zw);
        creditsAlpha = clamp((creditsAt + CREDITS_TOP_FADE) / CREDITS_TOP_FADE, 0.0, 1.0)
                * clamp((CREDITS_LINES * CREDITS_LINE - CREDITS_LINE - creditsAt) / CREDITS_FADE + 1.0, 0.0, 1.0);
    }
#endif

#ifdef IS_GUI
    // MagixPack compact menus (see FIT_PAGE_RED).
    bool fitWhite = false;
    bool fitLetterHidden = false;
    {
        ivec3 fitRgb = ivec3(round(Color.rgb * 255.0));
        vec2 fitScreen = vec2(abs(2.0 / ProjMat[0][0]), abs(2.0 / ProjMat[1][1]));
        vec4 fitVert = ModelViewMat * vec4(Position, 1.0);
        if (fitRgb.r == FIT_PAGE_RED && fitRgb.g >= 128 && fitRgb.g < 152 && (fitRgb.g - 128) % 4 < 3) {
            int fitZone = (fitRgb.g - 128) % 4;
            int fitRows = (fitRgb.g - 128) / 4 + 1;
            float fitTop = fitWindowTop(fitScreen.y, fitRows);
            if (fitZone == 1 && fitRgb.b > 0) {
                fitVert.y = fitTop + (fitVert.y - fitTop) * clamp((fitTop - FIT_MARGIN) / float(fitRgb.b), 0.0, 1.0);
            }
            if (fitZone == 2) fitVert.y = max(min(fitVert.y, fitScreen.y - FIT_MARGIN), fitTop + float(114 + 18 * fitRows));
            fitVert.x = clamp(fitVert.x, FIT_MARGIN, fitScreen.x - FIT_MARGIN);
            gl_Position = ProjMat * fitVert;
            fitWhite = true;
        } else if (fitRgb.r == FIT_BANNER_RED && fitRgb.g > 160 && fitRgb.g <= 166) {
            if (fitWindowTop(fitScreen.y, fitRgb.g - 160) < float(fitRgb.b) + FIT_MARGIN) gl_Position = FIT_GONE;
            fitWhite = true;
        } else {
            vec2 fitMark = fitLetterMark();
            if (fitMark.y > 0.0 && fitLetterOnWindow(fitVert.y + fitMark.x, fitScreen.y)
                    && fitVert.y + fitMark.x < fitMark.y + FIT_MARGIN) fitLetterHidden = true;
        }
    }
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
#ifdef IS_GUI
    if (hudLabelColor.r >= 0.0) vertexColor = hudLabelColor;
#endif
#ifdef IS_GUI
    if (bossColor.r >= 0.0) vertexColor = bossColor;
#endif
#ifdef IS_GUI
    if (cornerColor.r >= 0.0) vertexColor = cornerColor;
#endif
#ifdef IS_GUI
    if (marqueeAlpha >= 0.0) vertexColor = vec4(1.0, 1.0, 1.0, Color.a * marqueeAlpha);
    if (creditsAlpha >= 0.0) vertexColor = vec4(creditsColour, Color.a * creditsAlpha);
#endif
#ifdef IS_GUI
    if (fitWhite) vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    if (fitLetterHidden) vertexColor.a = 0.0;
#endif
    texCoord0 = UV0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    uvCoord = vec2(0.0);
    custom = 0;
    for (int i = 0; i < ARROW_MAX; i++) arrows[i] = vec4(0.0, 0.0, 0.0, -1.0); // nessuna freccia

    // Riconoscimento minimap: normalizza al pixel (0,0) della mappa e controlla i 3 pixel header.
    vec2 texSize = vec2(textureSize(Sampler0, 0));
    if (texSize == vec2(128.0)) {
        // ANGOLO del quad ricavato da UV0 (round -> 0/1 su ciascun asse), NON piu' da gl_VertexID.
        // FIX 26.2 (2026-07-23, causa VERA del bug "18 minimappe fluttuanti che flashano"): da MC 26.2 la
        // geometria della mappa passa per il "SubmitNodeCollector" BATCHATO (verificato decompilando
        // MapRenderer/RenderPipelines del client 26.2) -> gl_VertexID non e' piu' 0..3 per singolo quad-
        // mappa, ma un indice progressivo nell'INTERO batch. La vecchia formula corners[(gl_VertexID+1)%4]
        // leggeva quindi l'angolo SBAGLIATO: l'header magico non veniva mai riconosciuto, custom restava 0
        // e ogni quadro veniva disegnato NEL MONDO (le 18 ancore della corona = 18 mappe fluttuanti, con il
        // flash del frustum culling). L'angolo in UV e' invece SEMPRE corretto per-vertice: i 4 vertici
        // della mappa hanno UV0 = (0,0)/(0,1)/(1,1)/(1,0). round(clamp(...)) li riporta a 0/1 esatti.
        vec2 cornerUV = round(clamp(UV0, 0.0, 1.0));
        ivec2 uv = ivec2(UV0 * texSize);
        ivec2 mapUV = uv - ivec2(cornerUV * 128.0);
        if (idAt(mapUV + ivec2(0, 0)) == MK0 && idAt(mapUV + ivec2(1, 0)) == MK1 && idAt(mapUV + ivec2(2, 0)) == MK2) {
            // Riquadro in alto (a destra o a sinistra, vedi hudClip), quadrato (nessuna rotazione).
            // z = 0.0 (piano vicino), NON piu' -0.9999. FIX 26.2 (2026-07-23, causa CONFERMATA del "non si
            // vede piu' NIENTE" dopo che il riconoscimento header ha ripreso a funzionare): da MC 26.2 il
            // client usa glClipControl ZERO_TO_ONE (verificato nel client jar: Projection.isZZeroToOne,
            // GlDevice.glClipControl) -> il clip-space z valido e' [0, w], non piu' [-w, w]. Il vecchio
            // -0.9999 (piano vicino sotto il range [-1,1] di prima) ora CADE FUORI dal range -> l'intero
            // quad HUD viene scartato dal clipping (invisibile). 0.0 e' il piano vicino sotto ZERO_TO_ONE
            // ed e' comunque valido anche sotto il vecchio range; il gl_FragDepth=0.0 nel fragment tiene
            // l'HUD davanti a tutto (nearest in window-space [0,1], indipendente dalla convenzione).
            gl_Position = hudClip(vec2(cornerUV.x * MAP_SIZE.x, MAP_OFFSET.y + cornerUV.y * MAP_SIZE.y));
            vertexColor = vec4(1.0);
            uvCoord = cornerUV * 128.0;
            custom = 1;
            sphericalVertexDistance = 0.0;
            cylindricalVertexDistance = 0.0;
            // Frecce: ARROW_MAX record da 22 bit, a partire dal pixel 3 (dopo i 3 magici). Formato di un
            // record (LSB-first): 1 bit valido, 7 px, 7 py, 5 angolo (bucket 0..31 -> bucket/32*2pi), 2
            // tipo. Combacia con MapService.packArrow/renderPaletteWithHeader.
            for (int i = 0; i < ARROW_MAX; i++) {
                int b = 3 + i * 22;
                if (bitAt(mapUV, b) == 0) continue;                 // slot vuoto -> resta .w = -1
                int px  = readBits(mapUV, b + 1, 7);
                int py  = readBits(mapUV, b + 8, 7);
                int ang = readBits(mapUV, b + 15, 5);
                int typ = readBits(mapUV, b + 20, 2);
                arrows[i] = vec4(float(px), float(py), (float(ang) / 32.0) * 6.28318530718, float(typ));
            }
        } else if (idAt(mapUV + ivec2(0, 0)) == MK2 && idAt(mapUV + ivec2(1, 0)) == MK1 && idAt(mapUV + ivec2(2, 0)) == MK0) {
            // Firma INVERSA (49/4/18) = MAPPA-ITEM Fazioni (in mano o in cornice): resta al suo posto nel
            // mondo (nessun riposizionamento HUD), ma il fragment la rende FULLBRIGHT (leggibile di notte)
            // e con l'upscaling smart, identica alla minimap. Scritta da FactionMapRenderer.
            custom = 2;
            uvCoord = cornerUV * 128.0;
        } else if (idAt(mapUV + ivec2(0, 0)) == MK0 && idAt(mapUV + ivec2(1, 0)) == MK2 && idAt(mapUV + ivec2(2, 0)) == MK1) {
            // Firma (18/49/4 = MK0/MK2/MK1) = PANNELLO INFO: striscia sotto la minimap, stessi bordi
            // e stessa larghezza. Scritto da InfoPanelRenderer. La minimap occupa (unita' "map" di hudClip):
            //   x in [0, s] dal bordo sinistro del riquadro,  y in [MAP_OFFSET.y, MAP_OFFSET.y + s]
            // (vedi il ramo minimap sopra). Il pannello parte quindi a y = MAP_OFFSET.y + s + PANEL_GAP e
            // alto s*(PANEL_ROWS/128) -> pixel quadrati come la minimap. La texture e' campionata solo sulle
            // prime PANEL_ROWS righe (uvCoord.y in [0, PANEL_ROWS]); il resto della mappa 128x128 non si usa.
            float s = MAP_SIZE.x;
            float panelH = s * (PANEL_ROWS / 128.0);
            gl_Position = hudClip(vec2(cornerUV.x * s, MAP_OFFSET.y + s + PANEL_GAP + cornerUV.y * panelH));
            vertexColor = vec4(1.0);
            uvCoord = cornerUV * vec2(128.0, PANEL_ROWS);
            custom = 3;
            sphericalVertexDistance = 0.0;
            cylindricalVertexDistance = 0.0;
        }
    }
#endif
}
