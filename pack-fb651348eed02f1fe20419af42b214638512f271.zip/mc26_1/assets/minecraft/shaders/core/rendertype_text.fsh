#version 330
#define MAGIX_TARGET 261
#define LOC(n)

// MagixPack's own text shader, fragment half: see the note at the top of text.vsh (used only when no plugin
// registers a text shader: the hub). Vanilla for every variant and version (the 26.3 tail, with its
// order-independent transparency, is the one of vanilla 26.3), plus the screen transition in the GUI.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

// 26.1 and 1.21.x have no GUI text variant: their one rendertype_text compiles the GUI code too, driven by hudMode,
// which text.vsh sets to 0 for the world's text (see MAGIX_GUI_CODE there).
#if defined(IS_GUI) || MAGIX_TARGET == 261
#define MAGIX_GUI_CODE
#endif

#moj_import <minecraft:dynamictransforms.glsl>
// 26.3 only: ShaderVariants turns this comment into the include in the mc26_3 overlay (oit.glsl does not exist before).

// The Store box's running light (storeGlow) needs GameTime: 26.2 and 26.3 only (26.1 has no GUI text variant).



uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
LOC(0) in float sphericalVertexDistance;
LOC(1) in float cylindricalVertexDistance;
#endif

LOC(2) in vec4 vertexColor;
LOC(3) in vec2 texCoord0;

#if MAGIX_TARGET < 263 || !defined(OIT_ALPHA_ONLY)
LOC(0) out vec4 fragColor;
#endif

#ifdef MAGIX_GUI_CODE
LOC(4) in vec2 hudPos;
LOC(5) flat in int hudMode;
LOC(6) flat in vec4 hudData;
LOC(7) flat in vec4 hudBox;

// --- MagixPack screen transition (teleports and server switches) ---------------------------------------
// A diamond wipe. The diamonds sit on two square grids, the second shifted by half a cell, TRANSITION_ROWS of
// them per screen height whatever the resolution or GUI scale. Closing, each grows from nothing to a size that
// covers its cell, the ones on the vertical centre line first, the ones at the sides TRANSITION_SPREAD later;
// opening, they shrink back in the same order. hudData: half screen size in GUI pixels (xy), progress 0..255
// (z), 1 = opening (w). THIS BLOCK IS COPIED IDENTICAL in MagixFactions' text.fsh (the theft HUD's shader,
// used on the faction instead of this one): if it changes, change both.
const float TRANSITION_ROWS = 12.0;
const float TRANSITION_SPREAD = 1.2;

// Radius (in cells, 0.5 = the cell covered) of the diamond centred at `cell` (in cells from the screen centre).
float transitionRadius(vec2 cell, float cellSize, float t, bool opening) {
    float side = clamp(abs(cell.x) * cellSize / max(hudData.x, 1.0), 0.0, 1.0);
    float grown = clamp(t * (1.0 + TRANSITION_SPREAD) - TRANSITION_SPREAD * side, 0.0, 1.0);
    return (opening ? 1.0 - grown : grown) * 0.52;
}

float transitionCover(float dist, float radius, float aa) {
    return radius > 0.0 ? 1.0 - smoothstep(-aa, aa, dist - radius) : 0.0;
}

vec4 hudTransition() {
    float t = hudData.z / 255.0;
    bool opening = hudData.w > 0.5;
    if (!opening && t >= 1.0) return vec4(0.0, 0.0, 0.0, 1.0);
    float cellSize = max(hudData.y * 2.0 / TRANSITION_ROWS, 4.0);
    vec2 q = hudPos / cellSize;
    vec2 a = round(q);                 // grid through the screen centre
    vec2 b = floor(q) + 0.5;           // grid shifted by half a cell
    float aa = fwidth(q.x) + 0.0001;
    float cover = max(
            transitionCover(abs(q.x - a.x) + abs(q.y - a.y), transitionRadius(a, cellSize, t, opening), aa),
            transitionCover(abs(q.x - b.x) + abs(q.y - b.y), transitionRadius(b, cellSize, t, opening), aa));
    return vec4(0.0, 0.0, 0.0, cover);
}

// --- MagixPack shield bar (the few seconds of protection after a teleport) -------------------------------------
// A thin timer bar under the crosshair: a dark track with a soft edge and, from the left, a green fill as long as
// what is left (hudData.z 0..255), lighter at its head. hudPos: -1..1 across the bar; hudData.xy: its half size in
// GUI pixels. THIS BLOCK IS COPIED IDENTICAL in the other text.fsh (MagixFactions' on the faction, MagixPack's on
// the hub): if it changes, change both.
const vec3 SHIELD_FILL_FROM = vec3(0.12, 0.72, 0.4);
const vec3 SHIELD_FILL_TO = vec3(0.55, 1.0, 0.74);

vec4 shieldBar() {
    vec2 bh = hudData.xy;
    vec2 p = hudPos * bh;
    float r = bh.y;
    vec2 q = abs(p) - (bh - vec2(r));
    float dist = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;   // < 0 inside the rounded bar
    float aa = fwidth(p.x) + 0.0001;
    float body = 1.0 - smoothstep(-aa, aa, dist);
    if (body <= 0.0) return vec4(0.0);
    float left = clamp(hudData.z / 255.0, 0.0, 1.0);
    float head = -bh.x + 2.0 * bh.x * left;                        // where the fill ends
    float fill = (1.0 - smoothstep(-aa, aa, p.x - head)) * (1.0 - smoothstep(-aa, aa, dist + 1.0));
    float along = clamp((p.x + bh.x) / max(2.0 * bh.x, 1.0), 0.0, 1.0);
    vec3 rgb = mix(SHIELD_FILL_FROM, SHIELD_FILL_TO, along);
    rgb += vec3(0.35) * exp(-abs(p.x - head) * 0.6) * step(0.001, left);   // a light at the head
    rgb += vec3(0.12) * (1.0 - smoothstep(-r, 0.0, p.y + r * 0.2));       // a highlight on the upper half
    vec4 track = vec4(0.02, 0.07, 0.05, 0.55);
    return vec4(mix(track.rgb, rgb, fill), mix(track.a, 0.95, fill) * body);
}

// --- MagixPack AFK screen (afk/AfkScreen: a player MagixGuard marks as idle) -------------------------------------
// The screen looks frozen: a cold veil over everything, thicker towards the edges, frost growing in from the four
// sides with a few glints that come and go, a light blue border just inside the edge that breathes slowly, and a
// darker band where the three lines of words are (text.vsh puts them there, AFK_LINE*_TOP). hudPos: GUI pixels from
// the screen centre; hudData: half screen size in GUI pixels (xy), seconds (z). THIS BLOCK IS COPIED IDENTICAL in
// MagixFactions' and MagixPack's text.fsh: if it changes, change both.
const vec3 AFK_VEIL = vec3(0.60, 0.82, 0.95);
const vec3 AFK_FROST = vec3(0.88, 0.96, 1.0);
const vec3 AFK_BORDER = vec3(0.40, 0.86, 1.0);
const vec3 AFK_BAND = vec3(0.02, 0.08, 0.15);
const float AFK_BORDER_INSET = 5.0;    // GUI pixels from the screen's edge to the border's middle
const float AFK_FROST_DEPTH = 30.0;    // how far the frost reaches in from the edges, GUI pixels

float afkHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float afkNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(afkHash(i), afkHash(i + vec2(1.0, 0.0)), f.x),
            mix(afkHash(i + vec2(0.0, 1.0)), afkHash(i + vec2(1.0, 1.0)), f.x), f.y);
}

float afkFbm(vec2 p) {
    float n = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        n += a * afkNoise(p);
        p = p * 2.07 + vec2(17.3, 9.1);
        a *= 0.5;
    }
    return n;
}

// `rgb` with alpha `a` laid over `under` (straight alpha).
vec4 afkOver(vec4 under, vec3 rgb, float a) {
    float out_a = a + under.a * (1.0 - a);
    vec3 out_rgb = (rgb * a + under.rgb * under.a * (1.0 - a)) / max(out_a, 0.0001);
    return vec4(out_rgb, out_a);
}

vec4 afkScreen() {
    vec2 half_ = max(hudData.xy, vec2(1.0));
    vec2 p = hudPos;
    float t = hudData.z;
    float edge = min(half_.x - abs(p.x), half_.y - abs(p.y));   // GUI pixels to the nearest edge
    float aa = max(fwidth(p.x), 0.0001);
    // the cold veil, thicker towards the corners
    float vignette = smoothstep(0.3, 1.3, length(p / half_));
    vec4 c = vec4(AFK_VEIL, 0.16 + 0.30 * vignette);
    // the darker band under the words
    float band = 1.0 - smoothstep(34.0, 58.0, abs(p.y + 6.0));
    c = afkOver(c, AFK_BAND, band * 0.42);
    // frost growing in from the edges: ragged, in streaks
    float grain = afkFbm(p / 9.0) * 0.65 + afkFbm(vec2(p.x + p.y, p.x - p.y) / 3.5) * 0.35;
    float reach = AFK_FROST_DEPTH * (0.45 + 0.9 * grain);
    float frost = 1.0 - smoothstep(reach * 0.55, reach, edge);
    c = afkOver(c, AFK_FROST, frost * (0.35 + 0.4 * grain));
    // glints in the frost, each one on and off on its own
    vec2 cell = floor(p / 3.0);
    float seed = afkHash(cell);
    float twinkle = pow(max(0.0, sin(t * (0.6 + seed * 1.4) + seed * 40.0)), 24.0);
    float dot_ = 1.0 - smoothstep(0.15, 0.9, length(fract(p / 3.0) - 0.5) * 2.0);   // a soft round point
    c = afkOver(c, vec3(1.0), frost * step(0.95, seed) * twinkle * dot_);
    // the light blue border, with its glow on both sides, breathing every 4 seconds
    float d = abs(edge - AFK_BORDER_INSET);
    float breath = 0.75 + 0.25 * sin(t * 1.5707963);
    float line = 1.0 - smoothstep(0.9 - aa, 0.9 + aa, d);
    float glow = exp(-d * 0.28) * 0.55 * breath;
    c = afkOver(c, AFK_BORDER, max(line, glow));
    c = afkOver(c, vec3(1.0), line * 0.35 * breath);
    return c;
}
#endif

#if defined(IS_GUI) && MAGIX_TARGET >= 262 && !defined(IS_GRAYSCALE)
// --- MagixPack Store box of the pause screen: a light running clockwise round its border --------------------
// A glyph's texture cannot be animated, so the light is drawn here. menu/PauseScreen marks the box's border:
// alpha 253 = the violet ring, 252 = the pixels just outside and inside it, and the 3 low bits of red, green and
// blue hold the pixel's place along the border (0..511 = one lap, clockwise from the top-left corner). Soft edges
// of other pictures (menu frame, logos, glyphs) are full of 252 next to 253, so a pixel counts only when it is
// really the box's: a ring pixel (253) has the ring's own violet in its 5 high bits (STORE_GLOW_RING, BORDER of
// PauseScreen) and a 252 neighbour whose place is at most STORE_GLOW_NEAR steps away; a 252 pixel has such a ring
// pixel next to it. Until MagixPack 0.32.5 a 252 next to any 253 was enough: whole pictures shimmered.
// GameTime (globals.glsl) is 1/24000 a tick, partial tick included: 1200 seconds a cycle, a whole number of laps
// in it, so no jump when it wraps.
// THIS BLOCK IS COPIED IDENTICAL in MagixPack's and MagixFactions' text.fsh: if it changes, change both.
const float STORE_GLOW_LAPS = 400.0;     // laps a GameTime cycle: one lap every 3 seconds
const float STORE_GLOW_TAIL = 0.24;      // the trail behind the light, a part of the lap
const float STORE_GLOW_FRONT = 0.012;    // the soft front of the light
const vec3 STORE_GLOW_HEAD = vec3(1.0, 0.96, 0.82);
const vec3 STORE_GLOW_TRAIL = vec3(1.0, 0.45, 0.92);

const ivec3 STORE_GLOW_RING = ivec3(0x98, 0x58, 0xD0);  // the ring's violet, 5 high bits (PauseScreen BORDER)
const int STORE_GLOW_NEAR = 4;           // most steps between a marked pixel and its neighbour on the other side

bool storeGlowRing(ivec4 c) {
    return c.a == 253 && (c.rgb & ivec3(0xF8)) == STORE_GLOW_RING;
}

int storeGlowPlace(ivec4 c) {
    return (c.r & 7) | ((c.g & 7) << 3) | ((c.b & 7) << 6);
}

vec4 storeGlow(vec4 tex) {
    ivec4 c = ivec4(round(tex * 255.0));
    if (c.a != 253 && c.a != 252) return tex;
    if (c.a == 253 && !storeGlowRing(c)) return tex;
    int other = c.a == 253 ? 252 : 253;
    int place = storeGlowPlace(c);
    ivec2 texel = ivec2(texCoord0 * vec2(textureSize(Sampler0, 0)));
    bool marked = false;
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            ivec4 n = ivec4(round(texelFetch(Sampler0, texel + ivec2(dx, dy), 0) * 255.0));
            if (n.a != other || (other == 253 && !storeGlowRing(n))) continue;
            int apart = abs(storeGlowPlace(n) - place);
            if (min(apart, 512 - apart) <= STORE_GLOW_NEAR) marked = true;
        }
    }
    if (!marked) return tex;
    float at = (float(place) + 0.5) / 512.0;
    float head = fract(GameTime * STORE_GLOW_LAPS);
    float behind = fract(head - at);
    float ahead = fract(at - head);
    float trail = behind < STORE_GLOW_TAIL ? pow(1.0 - behind / STORE_GLOW_TAIL, 2.0) : 0.0;
    float front = ahead < STORE_GLOW_FRONT ? 1.0 - ahead / STORE_GLOW_FRONT : 0.0;
    float k = max(trail, front * front);
    vec3 light = mix(STORE_GLOW_TRAIL, STORE_GLOW_HEAD, max(trail * trail * trail, front));
    return vec4(mix(tex.rgb, light, k * (c.a == 253 ? 1.0 : 0.6)), 1.0);
}
#endif


#ifdef MAGIX_GUI_CODE
// --- MagixPack CINEMA: the newcomers' film (cinematic/CinematicTour, CINE_BARS_BLUE of text.vsh) -----------------
// hudMode 10: the black bars at the top and the bottom coming in with hudData.z (0..255, eased), their full height
// hudData.w, a thin warm line on their inner edge and a soft vignette over the picture; hudMode 11: the whole screen
// black by hudData.z (the cuts between the scenes). hudPos: GUI pixels from the screen centre, hudData.xy its half.
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.fsh: if it changes, change both.
const vec3 CINE_EDGE_LINE = vec3(0.80, 0.64, 0.34);

vec4 cinemaScreen(bool black) {
    float k = clamp(hudData.z / 255.0, 0.0, 1.0);
    if (black) return vec4(0.0, 0.0, 0.0, k);
    float eased = k * k * (3.0 - 2.0 * k);
    vec2 h = max(hudData.xy, vec2(1.0));
    float bar = hudData.w * eased;
    float edge = h.y - abs(hudPos.y);                 // GUI pixels to the nearest top or bottom edge
    float aa = max(fwidth(hudPos.y), 0.0001);
    float inBar = bar > 0.0 ? 1.0 - smoothstep(bar - aa, bar + aa, edge) : 0.0;
    float vignette = smoothstep(0.6, 1.5, length(hudPos / h * vec2(1.0, 0.8))) * 0.42 * eased;
    float a = max(inBar, vignette);
    float line = (1.0 - smoothstep(0.0, aa + 0.5, abs(edge - bar))) * 0.4 * eased;
    float outA = line + a * (1.0 - line);
    return vec4(CINE_EDGE_LINE * line / max(outA, 0.0001), outA);
}

// hudMode 12: the film's pointer (CINE_RECT_BLUE / CINE_ANCHOR_BLUE of text.vsh). hudPos: GUI pixels from the framed
// tile's centre (hudData.w 0, hudData.xy its half size) or from the arrow's tip (hudData.w 1, hudData.xy the way it
// points); hudData.z seconds. A gold arrow with a dark rim and a soft light, bobbing towards its target; a framed tile
// gets a pulsing gold border with its glow.
const vec3 CINE_POINT_GOLD = vec3(1.0, 0.80, 0.30);
const vec3 CINE_POINT_LIGHT = vec3(1.0, 0.97, 0.84);
const vec3 CINE_POINT_RIM = vec3(0.16, 0.08, 0.0);

// Signed distance (about, GUI pixels) to an arrow whose tip is at the origin, pointing along +x.
float cinemaArrow(vec2 p) {
    float head = max(max(p.x, -p.x - 11.0), (abs(p.y) + p.x * 0.75) * 0.8);
    float shaft = max(max(-p.x - 22.0, p.x + 10.0), abs(p.y) - 2.6);
    return min(head, shaft);
}

vec4 cinemaPointerColor(vec2 p, vec2 dir, float t) {
    float bob = 2.5 + 2.5 * sin(t * 6.2831853 * 0.9);
    vec2 q = p + dir * bob;
    vec2 a = vec2(dot(q, dir), dot(q, vec2(-dir.y, dir.x)));
    float d = cinemaArrow(a / 1.4) * 1.4;
    float aa = max(fwidth(d), 0.001);
    float fill = 1.0 - smoothstep(-aa, aa, d);
    float rim = 1.0 - smoothstep(-aa, aa, d - 1.0);
    vec3 rgb = mix(CINE_POINT_LIGHT, CINE_POINT_GOLD, clamp(-a.x / 22.0, 0.0, 1.0));
    float glow = exp(-max(d, 0.0) / 3.0) * 0.45 * (0.75 + 0.25 * sin(t * 6.2831853));
    vec4 c = vec4(CINE_POINT_GOLD, glow * (1.0 - rim));
    c = vec4(mix(c.rgb, CINE_POINT_RIM, rim), max(c.a, rim));
    return vec4(mix(c.rgb, rgb, fill), max(c.a, fill));
}

vec4 cinemaPointer() {
    float t = hudData.z;
    if (hudData.w > 0.5) return cinemaPointerColor(hudPos, normalize(hudData.xy), t);
    vec2 half_ = hudData.xy;
    vec2 q = abs(hudPos) - half_ + 2.0;
    float box = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - 2.0;   // < 0 inside the rounded frame
    float aa = max(fwidth(box), 0.001);
    float pulse = 0.65 + 0.35 * sin(t * 6.2831853 * 0.8);
    float line = 1.0 - smoothstep(0.6 - aa, 0.6 + aa, abs(box));
    float glow = box > 0.0 ? exp(-box / 4.0) * 0.55 * pulse : 0.0;
    float inside = box < 0.0 ? 0.10 * pulse : 0.0;
    vec4 c = vec4(CINE_POINT_GOLD, max(max(glow, inside), line));
    c.rgb = mix(c.rgb, CINE_POINT_LIGHT, line * pulse);
    // the arrow beside the window, pointing at the tile's row (its tip hudData.w * 1000 from the tile's centre)
    float tip = hudData.w * 1000.0;
    vec4 arrow = cinemaPointerColor(hudPos - vec2(tip, 0.0), vec2(tip > 0.0 ? -1.0 : 1.0, 0.0), t);
    return vec4(mix(c.rgb, arrow.rgb, arrow.a), arrow.a + c.a * (1.0 - arrow.a));
}

// --- MagixPack SKILL RING (owner 10/11, MagixPrison's fx/MiningCombo; see SKILL_RING_BLUE of text.vsh) -----------------
// A ring round the crosshair that fills CLOCKWISE from the top with the SKILL charge, in the colours of the rune engraved
// on the pickaxe (0 = the base skill, the Mana's magenta to gold). Thin notches at 25, 50 and 75% so the percentage reads
// at a glance, a bright spark at the filling's head; READY, the whole ring breathes with a glow round it and a light
// running round it. hudPos: GUI pixels from the crosshair; hudData: the rune (x), the charge 0..250 / 255 ready (y),
// seconds (z).
const float SKILL_RING_R = 12.0;      // the ring's middle, GUI pixels from the crosshair
const float SKILL_RING_W = 2.4;       // its thickness
const vec3 SKILL_RING_FROM[7] = vec3[7](vec3(0.66, 0.20, 0.95), vec3(0.95, 0.30, 0.08), vec3(0.15, 0.45, 1.0),
        vec3(0.35, 0.62, 0.20), vec3(0.55, 0.30, 1.0), vec3(1.0, 0.62, 0.10), vec3(0.32, 0.10, 0.55));
const vec3 SKILL_RING_TO[7] = vec3[7](vec3(1.0, 0.83, 0.36), vec3(1.0, 0.86, 0.30), vec3(0.45, 0.95, 1.0),
        vec3(0.80, 0.95, 0.40), vec3(0.85, 0.80, 1.0), vec3(1.0, 0.97, 0.62), vec3(0.20, 0.95, 0.80));

// --- the FOREST SCREEN (see FOREST_SCREEN_BLUE of text.vsh): hudPos = GUI pixels from the screen's middle, hudData.xy =
// half the screen, z = seconds, w = strength 0..1.
float forestHash(vec2 c) {
    return fract(sin(dot(c, vec2(127.1, 311.7))) * 43758.5453);
}

vec4 forestScreen() {
    vec2 p = hudPos;
    vec2 h = hudData.xy;
    float t = hudData.z;
    float k = hudData.w;
    // the violet vignette, breathing
    float d = length(p / h);
    float vig = smoothstep(0.55, 1.4, d) * (0.31 + 0.04 * sin(t * 0.9)) * k;  // halved, owner 16/11
    vec3 vigCol = vec3(0.36, 0.08, 0.62);
    // the aurora: a soft band waving over the top quarter, its colour shifting from cyan to magenta along it
    float y0 = -h.y * 0.78 + sin(p.x * 0.012 + t * 0.35) * h.y * 0.07 + sin(p.x * 0.031 - t * 0.6) * h.y * 0.025;
    float band = exp(-pow((p.y - y0) / (h.y * 0.09), 2.0));
    float curtain = 0.55 + 0.45 * sin(p.x * 0.045 - t * 1.4) * sin(p.x * 0.017 + t * 0.5);
    float aur = band * curtain * 0.5 * k;
    vec3 aurCol = mix(vec3(0.35, 0.95, 1.0), vec3(0.95, 0.4, 1.0), 0.5 + 0.5 * sin(p.x * 0.006 + t * 0.25));
    // motes of light drifting up, mostly round the edges
    float cell = 46.0;
    vec2 q = p + vec2(0.0, t * 14.0);
    vec2 id = floor(q / cell);
    float mote = 0.0;
    for (int dx = -1; dx <= 1; dx++) {
        for (int dy = -1; dy <= 1; dy++) {
            vec2 c = id + vec2(float(dx), float(dy));
            float r = forestHash(c);
            if (r < 0.55) continue;
            vec2 at = (c + vec2(forestHash(c + 3.1), forestHash(c + 7.7))) * cell;
            at.x += sin(t * 0.8 + r * 20.0) * 6.0;
            float dist = length(q - at);
            float twinkle = 0.5 + 0.5 * sin(t * (1.5 + r * 2.0) + r * 40.0);
            mote += (smoothstep(2.2, 0.0, dist) + 0.35 * smoothstep(9.0, 0.0, dist)) * twinkle;
        }
    }
    mote *= smoothstep(0.25, 0.9, d) * 0.7 * k;
    vec3 moteCol = vec3(0.85, 0.75, 1.0);
    float a = clamp(vig + aur + mote, 0.0, 0.85);
    if (a < 0.004) return vec4(0.0);
    vec3 col = (vigCol * vig + aurCol * aur + moteCol * mote) / max(vig + aur + mote, 0.0001);
    return vec4(col, a);
}

// --- the MINE TREMOR (see TREMOR_SCREEN_BLUE of text.vsh): hudPos = GUI pixels from the screen's middle, hudData.xy =
// half the screen, z = seconds, w = strength 0..1. The whole pattern JOLTS (a few pixels, many times a second) so the
// screen itself seems to shake, without moving the player's view.
vec4 tremorScreen() {
    float t = hudData.z;
    float k = hudData.w;
    vec2 h = hudData.xy;
    // the jolt: a fast, uneven shake of everything drawn here
    vec2 jolt = vec2(sin(t * 61.0) + 0.6 * sin(t * 97.0 + 1.3), cos(t * 53.0) + 0.6 * sin(t * 89.0 + 0.7)) * 2.2 * k;
    vec2 p = hudPos + jolt;
    float d = length(p / h);
    // the edges darken at every jolt of the rumble
    float beat = 0.55 + 0.45 * abs(sin(t * 7.0)) * (0.6 + 0.4 * sin(t * 2.3));
    float vig = smoothstep(0.4, 1.3, d) * 0.7 * beat * k;
    // a veil of dust, thicker at the top, drifting
    float veil = (0.5 + 0.5 * sin(p.x * 0.021 + t * 1.7) * sin(p.y * 0.017 - t * 1.1)) * 0.16
            * smoothstep(0.2, -1.0, p.y / h.y + 0.2) * 1.4 * k;
    // grit falling from the top: small dark streaks in columns, fast
    float cell = 15.0;
    vec2 q = p + vec2(0.0, -t * 170.0);
    vec2 id = floor(q / cell);
    float grit = 0.0;
    for (int dx = -1; dx <= 1; dx++) {
        vec2 c = id + vec2(float(dx), 0.0);
        float r = forestHash(c);
        if (r < 0.45) continue;
        vec2 at = (c + vec2(forestHash(c + 1.7), forestHash(c + 5.3))) * cell;
        vec2 dlt = q - at;
        grit += smoothstep(1.9, 0.3, abs(dlt.x)) * smoothstep(7.0, 0.0, abs(dlt.y)) * (0.7 + 0.3 * r);
    }
    grit *= smoothstep(0.1, 0.7, d) * k;
    float a = clamp(vig + veil + grit, 0.0, 0.8);
    if (a < 0.004) return vec4(0.0);
    vec3 dust = vec3(0.42, 0.34, 0.25);
    vec3 col = (vec3(0.06, 0.04, 0.03) * vig + dust * veil + vec3(0.16, 0.12, 0.09) * grit) / max(vig + veil + grit, 0.0001);
    return vec4(col, a);
}

// --- MagixPack ROPE GAUGE (owner 14/11, MagixPrison's mine/MineGuide; see ROPE_GAUGE_BLUE of text.vsh) ---------------
// An upright column right of the crosshair while the player climbs the grappling hook's rope: dark rock at the bottom,
// earth, a strip of grass and a bright sky line at the top (the SURFACE, where he is set down), notches every eighth. The
// part he has climbed fills with the rope's warm gold, chevrons drift up inside it, and a golden ARROW on its left points
// at his height, with a glow. hudPos: GUI pixels from the column's middle (y down); hudData: progress 0..1 (x), seconds (y).
const float ROPE_COL_HALF_W = 2.5;   // the column's half width
const float ROPE_COL_HALF_H = 48.0;  // its half height
vec4 ropeGauge() {
    vec2 p = hudPos;
    float prog = clamp(hudData.x, 0.0, 1.0);
    float t = hudData.y;
    float aa = max(fwidth(p.y), 0.05) * 0.75;
    // 0 at the bottom, 1 at the top of the column
    float u = clamp((ROPE_COL_HALF_H - p.y) / (2.0 * ROPE_COL_HALF_H), 0.0, 1.0);
    vec2 q = abs(p) - vec2(ROPE_COL_HALF_W, ROPE_COL_HALF_H);
    float box = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - 1.0;   // rounded column
    float body = 1.0 - smoothstep(-aa, aa, box);
    float rim = (1.0 - smoothstep(-aa, aa, box - 1.0)) - body;
    // the column: rock -> earth -> grass, darkened where not climbed yet
    vec3 rock = vec3(0.22, 0.21, 0.24), earth = vec3(0.42, 0.28, 0.16), grass = vec3(0.36, 0.72, 0.28);
    vec3 strata = u < 0.86 ? mix(rock, earth, smoothstep(0.25, 0.86, u)) : mix(earth, grass, smoothstep(0.86, 0.93, u));
    vec4 c = vec4(strata * 0.45, 0.72 * body);
    // the climbed part, the rope's gold, chevrons drifting up in it
    float filled = 1.0 - smoothstep(-aa, aa, (u - prog) * 2.0 * ROPE_COL_HALF_H);
    vec3 gold = mix(vec3(0.62, 0.36, 0.14), vec3(1.0, 0.80, 0.32), u);
    float chev = fract((p.y - abs(p.x) * 1.2) / 7.0 + t * 1.6);   // chevrons pointing up, drifting up
    gold *= 0.85 + 0.25 * smoothstep(0.55, 0.75, chev) * (1.0 - smoothstep(0.75, 0.95, chev));
    c.rgb = mix(c.rgb, mix(strata, gold, 0.75), filled * body);
    c.a = max(c.a, filled * body);
    // notches every eighth
    float n = abs(fract(u * 8.0 + 0.5) - 0.5) / 8.0 * 2.0 * ROPE_COL_HALF_H;
    c.rgb *= 1.0 - 0.45 * (1.0 - smoothstep(0.3, 0.3 + aa * 2.0, n)) * body;
    c = mix(c, vec4(0.03, 0.02, 0.02, 0.8), rim * (1.0 - c.a));
    // the SURFACE: a bright line across the top that breathes, wider than the column
    float topY = -ROPE_COL_HALF_H;
    float line = (1.0 - smoothstep(0.6, 0.6 + aa * 2.0, abs(p.y - topY))) * (1.0 - smoothstep(7.0, 7.0 + aa * 2.0, abs(p.x)));
    float breathe = 0.6 + 0.4 * sin(t * 4.0);
    float sky = exp(-pow((p.y - topY) / 2.5, 2.0)) * exp(-pow(p.x / 9.0, 2.0)) * 0.5 * breathe;
    c.rgb = mix(c.rgb, vec3(0.75, 0.95, 1.0), max(line, sky / max(c.a + sky, 0.001)));
    c.a = max(c.a, max(line, sky));
    // the ARROW on the column's left, pointing at his height (tip 1.5 px off the column), with a glow
    float ay = ROPE_COL_HALF_H - prog * 2.0 * ROPE_COL_HALF_H;
    vec2 a = vec2(p.x + ROPE_COL_HALF_W + 2.5, p.y - ay);   // the tip at a = 0, the arrow to the left (x < 0)
    float tri = max(-a.x - 7.0, max(a.x, abs(a.y) - (-a.x) * 0.6));   // a triangle 7 px long pointing right
    float shaft = max(max(-a.x - 12.0, a.x + 5.0), abs(a.y) - 1.1);   // its tail
    float arrow = min(tri, shaft);
    float arrowA = 1.0 - smoothstep(-aa, aa, arrow);
    float arrowRim = (1.0 - smoothstep(-aa, aa, arrow - 0.9)) - arrowA;
    float glow = exp(-max(arrow, 0.0) / 1.8) * (0.30 + 0.15 * sin(t * 6.0)) * (1.0 - arrowA);
    vec3 arrowCol = mix(vec3(1.0, 0.78, 0.25), vec3(1.0, 0.97, 0.80), 0.5 + 0.5 * sin(t * 5.0));
    c.rgb = mix(c.rgb, vec3(1.0, 0.75, 0.25), glow / max(c.a + glow, 0.001));
    c.a = max(c.a, glow);
    c = mix(c, vec4(0.05, 0.03, 0.01, 0.85), arrowRim * (1.0 - arrowA));
    c = mix(c, vec4(arrowCol, 1.0), arrowA);
    return c;
}

// --- MagixPack CANVAS GLOW (see CANVAS_GLOW_RED of text.vsh): the lit edge of the card under the mouse ----------------
// hudPos = GUI pixels from the card's middle, hudData = its half size (xy), tint (z: 0 gold, 1 magenta, 2 green,
// 3 light blue), seconds (w). A bright line on the card's edge, a soft halo outside and a little light inside, all
// breathing, and a spark running round the edge.
const vec3 CANVAS_GLOW_TINT[4] = vec3[4](vec3(1.0, 0.80, 0.30), vec3(1.0, 0.38, 0.92), vec3(0.62, 0.95, 0.32), vec3(0.42, 0.80, 1.0));
// every box's corner, = tools/prison_canvas.py RADIUS (owner 22/11: one radius everywhere, SQUARED)
const float CANVAS_RADIUS = 1.0;
// the SHAPED light's corner (= tools/prison_glass.py DOOR_R: the glass carousel's doors and tiles)
const float CANVAS_SHAPED_R = 7.0;

vec4 canvasGlow() {
    if (all(greaterThan(hudPos, hudBox.xy)) && all(lessThan(hudPos, hudBox.zw))) return vec4(0.0);   // under the tooltip
    vec2 ext = hudData.xy;
    float t = hudData.w;
    // the card's own corner (prison_canvas card(): radius 6 at size 0, scaled with the screen, owner 20/11)
    int zc = int(hudData.z + 0.5);
    if (zc >= 256) {
        // THE SHAPED LIGHT (owner 23/11, the Prison's glass carousel; = tools/prison_glass.py shaped_light): no line; a light
        // from BEHIND that starts at the card's own round edge (corner CANVAS_SHAPED_R, scaled with the size) and fades
        // outwards, the face a little lighter, breathing softly
        zc -= 256;
        vec3 st = CANVAS_GLOW_TINT[zc % 4];
        float sk = ((zc % 16) / 4) == 1 ? 1.5 : 1.0;
        float sr = min(CANVAS_SHAPED_R * sk, min(ext.x, ext.y) - 0.5);
        vec2 sq = abs(hudPos) - (ext - sr);
        float sd = length(max(sq, 0.0)) + min(max(sq.x, sq.y), 0.0) - sr;
        float sbreathe = 0.88 + 0.12 * sin(t * 4.0);
        float sglow = sd > 0.0 ? exp(-sd / (3.2 * sk)) * 0.95 * sbreathe : 0.0;
        // gone BEFORE the quad's edge (owner 23/11, his screenshot: «la luce fa così... è tagliata»): the quad is the card
        // + CANVAS_GLOW_PAD 9 GUI pixels (text.vsh) at every size, where exp() still left 6% (15% at Grande): a straight cut
        // faded along the card's OWN round distance (owner 23/11: «la luce è troppo quadrata»: a fade on the box's square
        // distance cut the light in a rectangle): sd <= 8.5 keeps it inside the quad (the box's distance is never more)
        sglow *= 1.0 - smoothstep(2.5, 8.5, sd);
        float sface = sd < -1.2 * sk ? 0.10 : 0.0;
        return vec4(sd > 0.0 ? st * 0.85 + 0.15 : vec3(1.0), clamp(sglow + sface, 0.0, 1.0));
    }
    if (zc >= 128) {
        // AN AURA (owner 22/11: «togli il contorno illuminato all'isola, fai che esce una luce da dietro e basta»): no
        // line; a soft light widest at the cells' middle and gone at their edge, held back over the round picture
        // (a disc as tall as the cells) so it reads as coming from BEHIND it
        vec3 at = CANVAS_GLOW_TINT[zc % 4];
        // one row tall (a hook of the bench's rope): a round light close round the ring, not the cell's wide ellipse
        float fall = 1.0 - smoothstep(0.25, 1.0, ext.y < 12.0 ? length(hudPos) / (ext.y + 6.0) : length(hudPos / (ext + 8.0)));
        float breathe = 0.86 + 0.14 * sin(t * 4.0);
        if (ext.x < ext.y) {
            // A FACE in one column (owner 22/11: «la luce deve seguire la forma dell'avatar, da dietro deve partire»):
            // the light starts at the face's own edge (a square of 24 with round corners, 2 over the cells' middle:
            // tools/prison_canvas.py avatar) and fades outwards; nothing over the face
            float ak = ((zc % 16) / 4) == 1 ? 1.5 : 1.0;
            vec2 fq = abs(hudPos + vec2(0.0, 2.0 * ak)) - (12.0 - 4.5) * ak;
            float fd = length(max(fq, 0.0)) + min(max(fq.x, fq.y), 0.0) - 4.5 * ak;
            float light = fd > 0.0 ? exp(-fd / (4.0 * ak)) : 0.0;
            return vec4(mix(at, vec3(1.0), 0.35), clamp(light * 0.90 * breathe * smoothstep(0.0, 0.25, fall), 0.0, 1.0));
        }
        // a disc as tall as the cells (the island): the light starts at its rim
        float rad = ext.y - 1.0;
        float outside = smoothstep(rad - 0.14 * rad, rad + 0.04 * rad, length(hudPos));
        return vec4(mix(at, vec3(1.0), 0.30), clamp(fall * mix(0.10, 0.80, outside) * breathe, 0.0, 1.0));
    }
    zc = zc % 128;
    if (zc >= 64) {
        // A FILLED BUTTON (owner 21/11: «solo il bordo illuminato e uno sfondo leggermente più chiaro»): one bright line
        // on its round edge, a short soft light just outside, its face a little lighter; nothing moves
        vec3 bt = CANVAS_GLOW_TINT[zc % 4];
        float bk = ((zc - 64) % 16) / 4 == 1 ? 1.5 : 1.0;
        float br = min(CANVAS_RADIUS * bk, min(ext.x, ext.y) - 0.5);
        vec2 bq = abs(hudPos) - (ext - br);
        float bd = length(max(bq, 0.0)) + min(max(bq.x, bq.y), 0.0) - br;
        float bline = 1.0 - smoothstep(0.4 * bk, 1.1 * bk, abs(bd + 0.7 * bk));
        float bhalo = bd > 0.0 ? exp(-bd / (1.2 * bk)) * 0.30 : 0.0;
        float bface = bd < 0.0 ? 0.16 : 0.0;
        vec3 bc = mix(vec3(1.0), mix(bt, vec3(1.0), 0.45), clamp(bline + bhalo, 0.0, 1.0));
        return vec4(bc, clamp(bline * 0.95 + bhalo + bface, 0.0, 1.0));
    }
    if (zc >= 32) {
        // A ROW OF A PANEL (owner 21/11: «quel tasto con i bordi arrotondati non mi piace, mettici uno sfondo»): no
        // outline; its colour fills it from the left edge and fades to the right, a bright bar on the left edge with a
        // soft glow, a fine light line on its top and bottom edges fading the same way (= prison_canvas row_light)
        vec3 rowTint = CANVAS_GLOW_TINT[zc % 4];
        int rowSize = ((zc - 32) % 16) / 4;
        float rk = rowSize == 1 ? 1.5 : 1.0;
        vec2 p = hudPos + ext;                       // GUI pixels from the row's top left corner
        vec2 full = 2.0 * ext;
        bool inside = p.x >= 0.0 && p.y >= 0.0 && p.x <= full.x && p.y <= full.y;
        float u = clamp(p.x / max(full.x, 1.0), 0.0, 1.0);
        // NO VEIL (owner 22/11: «togli questi veli, dappertutto, su tutti i menu»: the fill covered the row's words and
        // the face): only the bright bar on the row's left edge and a short glow beside it
        float fill = 0.0;
        float edge = 0.0;
        float bar = p.x >= 0.0 && p.x < 2.0 * rk && p.y >= rk && p.y <= full.y - rk ? 1.0 : 0.0;
        float halo = p.y >= 0.0 && p.y <= full.y ? exp(-abs(p.x - rk) / (1.2 * rk)) * 0.40 : 0.0;
        float ra = clamp(max(max(fill, edge), max(bar, halo)), 0.0, 1.0);
        vec3 rc = mix(rowTint, vec3(1.0), bar * 0.5);
        return vec4(rc, ra);
    }
    bool thin = zc >= 16;                        // a button inside a card: a thin lit edge (owner 20/11)
    int size = (zc % 16) / 4;
    float k = size == 3 ? 3.0 : size == 2 ? 2.0 : size == 1 ? 1.5 : 1.0;
    float r = min(CANVAS_RADIUS * k, min(ext.x, ext.y) - 0.5);
    vec2 q = abs(hudPos) - (ext - r);
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;   // GUI pixels from the card's edge, inside < 0
    vec3 tint = CANVAS_GLOW_TINT[int(hudData.z + 0.5) % 4];
    float breath = 0.8 + 0.2 * sin(t * 5.0);
    // ONE bright line on the card's own border and a short faint glow (owner 20/11: a wide halo read as a second frame)
    float line = thin ? 1.0 - smoothstep(0.25, 0.75, abs(d + 0.45)) : 1.0 - smoothstep(0.5, 1.3, abs(d + 0.8));
    float halo = thin ? (d > 0.0 ? exp(-d / 0.7) * 0.18 : 0.0) : (d > 0.0 ? exp(-d / 1.4) * 0.35 : exp(d / 5.0) * 0.12);
    // the spark: a bright stretch travelling clockwise round the edge
    float turn = atan(hudPos.y / max(ext.y, 1.0), hudPos.x / max(ext.x, 1.0)) / 6.2831853;
    float spark = pow(max(0.0, 1.0 - abs(fract(turn - t * 0.35) - 0.5) * 2.0 / 0.22), 2.0) * line;   // the spark runs ON the line, never wider than it (owner 20/11: it read as the edge moved out)
    float a = clamp(line * 0.95 + halo * breath + spark * 0.9, 0.0, 1.0);
    vec3 c = mix(tint, vec3(1.0), clamp(line * 0.55 + spark * 0.8, 0.0, 1.0));
    return vec4(c, a);
}

// The twin pickaxe's crosshair (TWIN_CROSS_* of text.vsh): four short arms round a gap, light mint with a dark rim
// readable on any block. No ring (owner 20/11: «il secondo mirino non deve avere la ricarica della runa ... non ha la
// runa il piccone»).
const float TWIN_CROSS_ARM_IN = 1.5;    // GUI pixels from the middle where an arm starts
const float TWIN_CROSS_ARM_OUT = 5.0;   // and ends
vec4 twinCross() {
    vec2 p = hudPos;
    float aa = max(fwidth(p.x), 0.05) * 0.75;
    vec2 a = abs(p);
    // the arms: a box 1 pixel wide along each axis, from ARM_IN to ARM_OUT
    float along = max(a.x, a.y);
    float across = min(a.x, a.y);
    float arm = (1.0 - smoothstep(0.5 - aa, 0.5 + aa, across))
            * smoothstep(TWIN_CROSS_ARM_IN - aa, TWIN_CROSS_ARM_IN + aa, along)
            * (1.0 - smoothstep(TWIN_CROSS_ARM_OUT - aa, TWIN_CROSS_ARM_OUT + aa, along));
    float rimArm = (1.0 - smoothstep(1.3 - aa, 1.3 + aa, across))
            * smoothstep(TWIN_CROSS_ARM_IN - 0.8 - aa, TWIN_CROSS_ARM_IN - 0.8 + aa, along)
            * (1.0 - smoothstep(TWIN_CROSS_ARM_OUT + 0.8 - aa, TWIN_CROSS_ARM_OUT + 0.8 + aa, along));
    vec4 c = vec4(0.02, 0.03, 0.03, 0.55 * rimArm);
    return mix(c, vec4(0.80, 1.0, 0.90, 1.0), arm);
}

// THE LIVE LEVEL RING (text.vsh, shine mark blue 79): the ring of the main screen's level card drawn here at the player's
// percent (hudData.x 0..1), in a box of 40 size-0 GUI pixels (hudPos -1..1): the dark track, the filled part violet to
// magenta from the top clockwise with a soft wave flowing to its tip and a warm light on the tip, and a twinkling star on
// the tip (= the 101 pictures of tools/make_prison_lobby.py ring_image/spark_image it replaces, coloured like SHINE_ORBIT).
vec4 canvasRing() {
    vec2 p = hudPos * 20.0;
    float t = hudData.y;
    float prog = clamp(hudData.x, 0.0, 1.0);
    float r = length(p);
    float aa = max(fwidth(r), 0.02);
    float rOut = 14.0, rIn = 9.4;                       // = RING_D / 2 - 1, RING_D / 2 - 5.6 of the lobby's maker
    float mid = (rOut + rIn) * 0.5, bandHalf = (rOut - rIn) * 0.5;
    float band = clamp((bandHalf - abs(r - mid)) / aa + 0.5, 0.0, 1.0);
    float ang = atan(p.x, -p.y) / 6.2831853;
    if (ang < 0.0) ang += 1.0;
    float filled = prog > 0.999 ? 1.0 : clamp((prog - ang) * r * 6.2831853 / aa + 0.5, 0.0, 1.0) * step(0.0005, prog);
    float along = clamp(ang / max(prog, 0.001), 0.0, 1.0);
    vec3 col = mix(vec3(0.55, 0.30, 0.92), vec3(1.0, 0.40, 0.90), along) * (0.85 + 0.15 * along);
    float wave = fract(t * 0.35);
    col += vec3(1.0, 0.85, 1.0) * exp(-(along - wave) * (along - wave) * 90.0) * 0.16 * along;
    float near = clamp((along - 0.9) / 0.1, 0.0, 1.0) * step(prog, 0.999);
    col = mix(col, vec3(1.0, 0.86, 0.95), near * near * (0.45 + 0.1 * sin(t * 5.0)));
    vec3 c = mix(vec3(0.16, 0.09, 0.23), col, filled);
    float alpha = band;
    if (prog > 0.001 && prog < 0.999) {
        vec2 d = p - vec2(sin(prog * 6.2831853), -cos(prog * 6.2831853)) * mid;
        float core = exp(-pow(length(d) / 1.3, 2.0));
        float plusA = exp(-pow(d.y / 0.45, 2.0)) * pow(clamp(1.0 - abs(d.x) / 5.5, 0.0, 1.0), 1.6);
        float plusB = exp(-pow(d.x / 0.45, 2.0)) * pow(clamp(1.0 - abs(d.y) / 5.5, 0.0, 1.0), 1.6);
        vec2 e = vec2(d.x + d.y, d.x - d.y) * 0.7071068;
        float crossA = exp(-pow(e.y / 0.4, 2.0)) * pow(clamp(1.0 - abs(e.x) / 3.8, 0.0, 1.0), 1.6);
        float crossB = exp(-pow(e.x / 0.4, 2.0)) * pow(clamp(1.0 - abs(e.y) / 3.8, 0.0, 1.0), 1.6);
        float star = clamp(max(max(core, max(plusA, plusB)), max(crossA, crossB) * 0.7), 0.0, 1.0);
        float thr = 0.22 + 0.16 * sin(t * 4.2);
        float flick = 0.82 + 0.18 * sin(t * 13.0) * sin(t * 7.7);
        float sa = smoothstep(thr, thr + 0.3, star) * flick;
        c = mix(c, mix(vec3(1.0, 0.55, 0.92), vec3(1.0, 0.98, 0.9), clamp(star * 1.3, 0.0, 1.0)), sa);
        alpha = max(alpha, sa);
    }
    return vec4(c, alpha);
}

// The underline of clickable canvas words (text.vsh canvasLineVertex): a THIN line (0.6 of a GUI pixel, owner 22/11),
// white, a faint glow round it and a light running along it left to right.
vec4 canvasLine() {
    if (all(greaterThan(hudPos, hudBox.xy)) && all(lessThan(hudPos, hudBox.zw))) return vec4(0.0);   // under the tooltip
    vec2 ext = hudData.xy;
    vec2 p = hudPos;
    float t = hudData.w;
    vec2 q = abs(p) - ext;
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0);   // GUI pixels from the line, inside < 0
    float core = 1.0 - smoothstep(-0.05, 0.3, d);
    float glow = d > 0.0 ? exp(-d / 0.6) * 0.18 : 0.0;
    float run = fract(t * 0.45) * 2.6 - 1.3;                  // -1.3 .. 1.3 along the line
    float spark = exp(-pow(p.x / max(ext.x, 1.0) - run, 2.0) * 18.0) * core;
    vec3 c = mix(vec3(1.0, 0.97, 0.9), vec3(1.0), spark);
    return vec4(c, clamp(core * (0.82 + 0.18 * spark) + glow + spark * 0.15, 0.0, 1.0));
}

vec4 skillRing() {
    vec2 p = hudPos;
    float r = length(p);
    float aa = max(fwidth(r), 0.05) * 0.75;
    int k = clamp(int(hudData.x + 0.5), 0, 6);
    bool ready = hudData.y > 252.5;
    float prog = ready ? 1.0 : clamp(hudData.y / 250.0, 0.0, 1.0);
    float t = hudData.z;
    // clockwise from the top: 0 at 12 o'clock, 0.25 at 3 (GUI y grows downwards)
    float ang = atan(p.x, -p.y);
    if (ang < 0.0) ang += 6.2831853;
    float f = ang / 6.2831853;
    float edge = abs(r - SKILL_RING_R) - SKILL_RING_W * 0.5;
    float band = 1.0 - smoothstep(-aa, aa, edge);
    float rim = (1.0 - smoothstep(-aa, aa, edge - 0.8)) - band;   // a dark line round the band, readable on any block
    // notches at the quarters (and the top, where it starts)
    float arcPx = SKILL_RING_R * 6.2831853;
    float q = abs(fract(f * 4.0 + 0.5) - 0.5) / 4.0 * arcPx;     // GUI pixels along the ring to the nearest quarter
    float notch = 1.0 - smoothstep(0.35, 0.35 + aa * 2.0, q);
    // the filling, anti-aliased along the ring
    float fillEdge = (f - prog) * arcPx;
    float filled = prog <= 0.0 ? 0.0 : 1.0 - smoothstep(-aa, aa, fillEdge);
    vec3 from = SKILL_RING_FROM[k];
    vec3 to = SKILL_RING_TO[k];
    vec3 fill = mix(from, to, ready ? 0.5 + 0.5 * sin(f * 6.2831853 * 2.0 - t * 4.0) : f);
    // a soft sheen across the band's thickness
    fill *= 0.85 + 0.3 * (1.0 - clamp(abs(r - SKILL_RING_R) / (SKILL_RING_W * 0.5), 0.0, 1.0));
    vec4 c = vec4(0.0);
    vec4 track = vec4(0.06, 0.04, 0.09, 0.55);
    vec4 band4 = mix(track, vec4(fill, 1.0), filled);
    band4.rgb *= 1.0 - 0.55 * notch;
    c = vec4(band4.rgb, band4.a * band);
    c = mix(c, vec4(0.02, 0.01, 0.03, 0.75), rim * (1.0 - c.a));
    if (!ready && prog > 0.0) {
        // the spark at the head of the filling
        float ha = prog * 6.2831853;
        vec2 head = vec2(sin(ha), -cos(ha)) * SKILL_RING_R;
        float d = length(p - head);
        float spark = exp(-d * d / 3.0);
        c.rgb = mix(c.rgb, vec3(1.0, 1.0, 0.92), spark * 0.9);
        c.a = max(c.a, spark * 0.95);
    }
    if (ready) {
        float pulse = 0.5 + 0.5 * sin(t * 6.0);
        // a light running round the ring
        float run = pow(max(0.0, cos(ang - t * 5.0)), 16.0);
        c.rgb = mix(c.rgb, vec3(1.0), run * band * 0.8);
        // the glow round it, in the rune's colour
        float out_ = max(edge, 0.0);
        float glow = exp(-out_ / (1.6 + 1.2 * pulse)) * (0.35 + 0.35 * pulse) * (1.0 - band);
        c.rgb = mix(c.rgb, to, glow / max(c.a + glow, 0.001));
        c.a = max(c.a, glow);
    }
    return c;
}
#endif

void main() {
#ifdef MAGIX_GUI_CODE
    if (hudMode == 19) {
        vec4 cross = twinCross();
        cross.a *= vertexColor.a;
        if (cross.a < 0.004) discard;
        fragColor = cross * ColorModulator;
        return;
    }
    // The transition, the shield bar, the AFK screen and the film's picture are drawn here: the glyph texture is not used.
    if (hudMode == 21) {   // the live level ring (text.vsh)
        vec4 ring = canvasRing() * vertexColor * ColorModulator;
        if (ring.a < 0.01) discard;
        fragColor = ring;
        return;
    }
    if (hudMode == 23) {   // the chat halo and its star (text.vsh, THE CHAT HALO); the pictures are DATA, read like hudMode 7's
        vec2 tc = texCoord0 * vec2(textureSize(Sampler0, 0));
        vec2 ex = dFdx(tc) * 0.25, ey = dFdy(tc) * 0.25;
        vec4 mid = texelFetch(Sampler0, ivec2(floor(tc)), 0);
        vec4 s0 = texelFetch(Sampler0, ivec2(floor(tc - ex - ey)), 0), s1 = texelFetch(Sampler0, ivec2(floor(tc + ex - ey)), 0);
        vec4 s2 = texelFetch(Sampler0, ivec2(floor(tc - ex + ey)), 0), s3 = texelFetch(Sampler0, ivec2(floor(tc + ex + ey)), 0);
        float cover = (s0.a + s1.a + s2.a + s3.a) * 0.25;
        float t = hudPos.x;
        vec3 c;
        float alpha;
        if (hudData.w > 1.5) {
            // the star: a short twinkle every 7 s, at the writer's own moment (hudPos.y), the rays growing out of its heart
            float lightV = (s0.r * s0.a + s1.r * s1.a + s2.r * s2.a + s3.r * s3.a) / max(s0.a + s1.a + s2.a + s3.a, 0.0001);
            float k = fract(t / 7.0 + hudPos.y);
            float tw = k < 0.1 ? sin(k / 0.1 * 3.14159) : 0.0;
            float thr = 1.0 - 0.9 * tw;
            c = mix(vec3(1.0, 0.94, 0.78), vec3(1.0), lightV);
            alpha = tw * smoothstep(thr - 0.25, thr, lightV) * step(0.004, cover);
        } else {
            // THE SAME RING AS THE REAL ONE (owner 23/11: «deve coincidere con quello reale»): haloColor() of item.vsh, its
            // numbers copied (HALO_LAP_SECONDS 2.4, HALO_TAIL 6, HALO_BASE 0.7, HALO_WHITE 0.7, prism lap 6 s, saturation
            // 0.8): the tint, a light with a fading tail going round, the prism's hue turning round the ring. Change both.
            float place = mid.r;
            vec3 tint = hudData.rgb;
            if (dot(tint, tint) < 0.0001) {
                vec3 rainbow = clamp(abs(fract(place + t / 6.0 + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
                tint = mix(vec3(1.0), rainbow, 0.8);
            }
            float light = 0.0;
            if (hudData.w < 0.5) {
                float behind = fract(fract(t / 2.4) - place);
                light = exp(-behind * 6.0) * (1.0 - smoothstep(0.96, 1.0, behind));
            }
            // in the chat the ring away from the light is the full tint (0.7 of item.vsh was too dim on a face, owner 23/11);
            // the dark rim under the front half (value 0) is the tint's shade
            c = mix(tint * mix(1.0, 1.0, light), vec3(1.0), 0.7 * light * light);
            if (mid.r < 0.002) c = tint * 0.22;
            alpha = cover;
        }
        vec4 chatHalo = vec4(c, alpha) * vec4(1.0, 1.0, 1.0, vertexColor.a) * ColorModulator;
        if (chatHalo.a < 0.01) discard;
        fragColor = chatHalo;
        return;
    }
    if (hudMode == 7) {   // a canvas picture that shines (text.vsh, THE SHINE MARK)
        // The picture is DATA (prison_canvas.shine_encode): ONE value per texel, the same in red, green and blue (a
        // 26.3 client read green as red, 20/11), read with texelFetch (26.3 blends a font texture's texels); this
        // shader gives the colours. Four exact texels inside the pixel's footprint: never single texels at any scale.
        vec2 tc = texCoord0 * vec2(textureSize(Sampler0, 0));
        vec2 ex = dFdx(tc) * 0.25, ey = dFdy(tc) * 0.25;
        vec4 mid = texelFetch(Sampler0, ivec2(floor(tc)), 0);
        vec4 s0 = texelFetch(Sampler0, ivec2(floor(tc - ex - ey)), 0), s1 = texelFetch(Sampler0, ivec2(floor(tc + ex - ey)), 0);
        vec4 s2 = texelFetch(Sampler0, ivec2(floor(tc - ex + ey)), 0), s3 = texelFetch(Sampler0, ivec2(floor(tc + ex + ey)), 0);
        float cover = (s0.a + s1.a + s2.a + s3.a) * 0.25;
        float t = hudData.y;
        vec3 c;
        float alpha = cover;
        if (hudData.x < 0.5) {
            // the level ring: 0.25 = the track, 0.5..1 = the filled part from its start to its tip. Violet to magenta,
            // brighter the nearer the tip, a soft wave flowing to the tip, a warm glow on the tip itself
            float wsum = max(s0.a + s1.a + s2.a + s3.a, 0.0001);
            float fill = (step(0.4, s0.r) * s0.a + step(0.4, s1.r) * s1.a + step(0.4, s2.r) * s2.a + step(0.4, s3.r) * s3.a) / wsum;
            float prog = clamp((mid.r - 0.5) * 2.0, 0.0, 1.0);
            vec3 col = mix(vec3(0.55, 0.30, 0.92), vec3(1.0, 0.40, 0.90), prog) * (0.85 + 0.15 * prog);
            float wave = fract(t * 0.35);
            col += vec3(1.0, 0.85, 1.0) * exp(-(prog - wave) * (prog - wave) * 90.0) * 0.16 * prog;
            float near = clamp((prog - 0.9) / 0.1, 0.0, 1.0);
            col = mix(col, vec3(1.0, 0.86, 0.95), near * near * (0.45 + 0.1 * sin(t * 5.0)));
            c = mix(vec3(0.16, 0.09, 0.23), col, fill);
        } else if (hudData.x < 1.5) {
            // a light sweeping across a button, every 3 s; the picture is only its shape
            float sweep = fract(t / 3.0) * 4.0 - 1.5;
            float dd = (mid.r - 0.5) - sweep * 0.5;
            float band = exp(-dd * dd * 60.0);
            c = vec3(1.0);
            alpha = cover * band * 0.5;   // only the band: the card keeps its own colour (owner 20/11: VIP and vote came out white)
        } else if (hudData.x > 3.5) {
            // a HALO over a player's face (owner 20/11: «l'aureola non è animato il luccichio»): the ring in its rank's
            // colour (4 VIP gold, 5 Plus aqua, 6 Prime magenta) breathing, and a light running round it like the site's
            // dot; the picture is its shape and each texel's place round the ring (0..1)
            int rank = int(hudData.x + 0.5);
            vec3 base = rank == 4 ? vec3(1.0, 0.69, 0.13) : rank == 5 ? vec3(0.24, 0.84, 0.88) : vec3(1.0, 0.33, 0.90);
            float da = abs(fract(mid.r - fract(t * 0.45) + 0.5) - 0.5);
            float spot = exp(-da * da * 500.0);
            float breath = 0.82 + 0.18 * sin(t * 3.0);
            c = mix(mix(base, vec3(1.0), 0.3) * breath, vec3(1.0), spot * 0.9);
            alpha = cover * clamp(breath + spot * 0.5, 0.0, 1.0);
        } else if (hudData.x > 2.5) {
            // an EPIC button (owner 20/11: «un gradiente epico che varia tipo multicolor»): a rainbow flowing along it,
            // a soft light crossing it now and then; the picture is only its shape and the place along it
            // the server's own colours round and round: gold, magenta, violet, sky
            float hue = fract(mid.r * 0.6 - t * 0.1) * 4.0;
            vec3 p0 = vec3(1.0, 0.78, 0.24), p1 = vec3(1.0, 0.33, 0.9), p2 = vec3(0.55, 0.36, 0.96), p3 = vec3(0.24, 0.84, 1.0);
            float f = smoothstep(0.0, 1.0, fract(hue));
            int seg = int(hue);
            vec3 rgb = seg == 0 ? mix(p0, p1, f) : seg == 1 ? mix(p1, p2, f) : seg == 2 ? mix(p2, p3, f) : mix(p3, p0, f);
            rgb *= 0.95;
            float sweep = fract(t / 4.0) * 4.0 - 1.5;
            float dd = (mid.r - 0.5) - sweep * 0.5;
            rgb = mix(rgb, vec3(1.0), exp(-dd * dd * 60.0) * 0.35);
            c = rgb;
            alpha = cover * 0.92;
        } else {
            // the spark: its light value; the rays grow and shrink and the whole star twinkles
            float lightV = (s0.r * s0.a + s1.r * s1.a + s2.r * s2.a + s3.r * s3.a) / max(s0.a + s1.a + s2.a + s3.a, 0.0001);
            float thr = 0.22 + 0.16 * sin(t * 4.2);
            float flick = 0.82 + 0.18 * sin(t * 13.0) * sin(t * 7.7);
            c = mix(vec3(1.0, 0.55, 0.92), vec3(1.0, 0.98, 0.9), clamp(lightV * 1.3, 0.0, 1.0));
            alpha = smoothstep(thr, thr + 0.3, lightV) * flick * step(0.004, cover);
        }
        vec4 shine = vec4(c, alpha) * vertexColor * ColorModulator;
        if (shine.a < 0.01) discard;
        fragColor = shine;
        return;
    }
    if (hudMode == 24) {
        // THE SHAPED PICTURE LIGHT (text.vsh canvasPictureVertex): the land's own light, breathing, never over the tooltip
        if (all(greaterThan(hudPos, hudBox.xy)) && all(lessThan(hudPos, hudBox.zw))) discard;
        vec4 pic = texture(Sampler0, texCoord0);
        if (pic.a <= 0.07) discard;     // nothing there (and the corners' guide texels, alpha 16)
        pic.a *= 0.86 + 0.14 * sin(hudData.w * 4.0);
        fragColor = pic * ColorModulator;
        return;
    }
    if (hudMode == 3 || hudMode == 4 || hudMode == 6 || hudMode >= 10) {
        vec4 hud = hudMode == 20 ? canvasLine() : hudMode == 18 ? canvasGlow() : hudMode == 17 ? tremorScreen() : hudMode == 16 ? ropeGauge() : hudMode == 15 ? forestScreen() : hudMode == 14 ? skillRing() : hudMode == 4 ? shieldBar() : hudMode == 6 ? afkScreen() : hudMode == 12 ? cinemaPointer()
                : hudMode >= 10 ? cinemaScreen(hudMode == 11) : hudTransition();
        hud.a *= vertexColor.a;
        if (hud.a < 0.004) discard;
        fragColor = hud * ColorModulator;
        return;
    }
#endif

#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif
#if defined(IS_GUI) && MAGIX_TARGET >= 262 && !defined(IS_GRAYSCALE)
    texColor = storeGlow(texColor);
#endif

#if MAGIX_TARGET >= 263
    // Vanilla 26.3: the same colour for the three variants, fog only in the world one (scaled by alpha
    // while accumulating OIT).
    vec4 color = texColor * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
#ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
#endif
#if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)
#ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
    vec4 fogColor = FogColor;
#endif
    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
#endif
    fragColor = color;
#endif
#else
#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
#endif
}
