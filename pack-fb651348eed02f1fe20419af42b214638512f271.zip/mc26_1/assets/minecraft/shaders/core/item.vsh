#version 330
#define MAGIX_TARGET 261
#define LOC(n)

// MagixPack's item vertex shader: vanilla, plus the running light of the VIP halo. One source for 26.1, 26.2 and 26.3
// (pack/ShaderVariants writes it three times, MAGIX_TARGET and LOC(n)): 26.3's own lines are under GLINT /
// GLINT_SPECIAL / OIT_* (never defined before 26.3), 26.1's are under MAGIX_TARGET == 261 (no lightMapColor /
// overlayColor there, the light map goes in vertexColor). Until MagixPack 0.33.9 it also hid the sharp copy of a drawn
// menu's banner on small screens; that is done by position_tex_color.vsh now (menu-panel/ template of MenuPanel).
//
// HALO: the VIP halo of MagixCosmetics (item model magixpack:halo, tools/make_halo.py), a ring of HALO_STEPS sides
// tinted in the player's colour, with a light running round it. Its vertices are recognised by the texel under
// them: red HALO_MARK_RED, green and blue = the step round the ring (255 - step / 8, 255 - step % 8), and the
// signature HALO_SIGNATURE HALO_SIGNATURE_ROWS rows under it (no other texture has both). A halo vertex is drawn
// in the tint's colour, always lit and without the side shading, and the light (a bright head with a fading tail)
// goes round in HALO_LAP_SECONDS from the game time (Globals: 26.2 and 26.3; on 26.1 the ring stays still).
// A halo vertex closer to the camera than HALO_HIDE_NEAR blocks is not drawn: in first person the camera is inside
// the player's own head and his ring would sit at the top of the screen; in third person (F5) the camera is ~4
// blocks away and he sees it (owner, 17/10). Other players' rings are never that close.
// Numbers shared with tools/make_halo.py: change both.
// PRISM: a ring tinted exactly HALO_PRISM_TINT (MagixCosmetics' colour "prism", the Magic Key's rare halo, owner 22/11)
// is drawn in every colour at once: the hue goes round the ring and turns in HALO_PRISM_LAP_SECONDS (on 26.1 it stays
// still, a rainbow ring).
//
// TWIN: Prison's twin pickaxe (MagixPrison pickaxe/TwinPickaxe, item definition magixprison:pickaxe_twin of
// tools/make_prison_pickaxe.py write_twin) strikes together with the main pickaxe (owner 20/11: «spaccano insieme»,
// «poco fluido», «deve completarsi comunque l'animazione, tutta»). An item model's properties change once a tick, the
// main arm every frame, so the motion is done here from the game's clock: in first person, while the twin's strike runs
// (the server starts it at every swing of the main hand), its vertices come with the constant tint (TWIN_MARK_R,
// TWIN_MARK_G, TWIN_TICK_BLUE + the tick of the strike). Such a vertex gets its white back and swings round the left
// hand exactly as the game swings an item in first person, mirrored, over TWIN_SWING ticks, TWIN_LEAD ticks ahead for the
// packet's way; a strike always ends, a new swing restarts it. Without Globals (26.1, the OIT passes) it moves at the
// tick. Numbers shared with that tool: change both.

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#if MAGIX_TARGET >= 262 && !defined(OIT_ALPHA_ONLY) && !defined(OIT_ACCUMULATE)
// GameTime: the item pipelines have the Globals block (ITEM_SNIPPET, checked in the 26.2 and 26.3 clients);
// the OIT ones of 26.3 do not
#define MAGIX_GLOBALS
#moj_import <minecraft:globals.glsl>
#endif
#if !defined(OIT_ALPHA_ONLY) && !defined(OIT_ACCUMULATE)
// the halo is opaque (cutout pipeline): never drawn by the translucent passes of 26.3
#define MAGIX_HALO
#endif

LOC(0) in vec3 Position;
LOC(1) in vec4 Color;
LOC(2) in vec2 UV0;
LOC(3) in ivec2 UV1;
LOC(4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
LOC(5) in vec2 UV3;
#endif
LOC(6) in vec3 Normal;

#ifdef MAGIX_HALO
uniform sampler2D Sampler0;
#endif

#if MAGIX_TARGET == 261
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
#else
#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

LOC(0) out float sphericalVertexDistance;
LOC(1) out float cylindricalVertexDistance;
#endif
LOC(2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
LOC(3) out vec4 lightMapColor;
LOC(4) out vec4 overlayColor;
#endif

LOC(5) out vec2 texCoord0;
#ifdef GLINT
LOC(6) out vec2 texCoordGlint;
#endif
#endif


const int HALO_MARK_RED = 253;                       // = MARK_RED of tools/make_halo.py
const ivec3 HALO_SIGNATURE = ivec3(250, 246, 252);   // = SIGNATURE
const int HALO_SIGNATURE_ROWS = 8;                   // = DATA_ROWS
const float HALO_STEPS = 32.0;                       // = STEPS
const float HALO_LAP_SECONDS = 2.4;                  // one lap of the light (1200 / 2.4 laps: no jump when GameTime wraps)
const float HALO_TAIL = 6.0;                         // how fast the tail fades behind the light
const float HALO_BASE = 0.7;                         // the ring away from the light, times the tint
const float HALO_WHITE = 0.7;                        // how white the light's head is
const float HALO_HIDE_NEAR = 1.0;                    // blocks from the camera under which a halo is hidden
const ivec3 HALO_PRISM_TINT = ivec3(1, 2, 3);        // = PRISM_TINT of MagixCosmetics' HaloManager
const float HALO_PRISM_LAP_SECONDS = 6.0;            // one turn of the rainbow (1200 / 6 laps: no jump at the wrap)
const float HALO_PRISM_SATURATION = 0.8;

const int TWIN_MARK_R = 255;                         // = TWIN_MARK_R of tools/make_prison_pickaxe.py
const int TWIN_MARK_G = 251;                         // = TWIN_MARK_G
const int TWIN_TICK_BLUE = 200;                      // = TWIN_TICK_BLUE
const int TWIN_SWING = 6;                            // = TWIN_SWING: ticks of one strike, the game's swing
const float TWIN_LEAD = 1.0;                         // ticks the strike runs ahead of its packet
const vec3 TWIN_PIVOT = vec3(-0.56, -0.52, -0.72);   // the left hand in first person (applyItemArmTransform, side -1)

// The tick of the strike of a twin vertex (0..TWIN_SWING-1), or -1 for any other vertex.
int twinTick() {
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if (c.r != TWIN_MARK_R || c.g != TWIN_MARK_G || c.b < TWIN_TICK_BLUE || c.b >= TWIN_TICK_BLUE + TWIN_SWING) return -1;
    return c.b - TWIN_TICK_BLUE;
}

vec3 twinRotX(vec3 p, float a) { return vec3(p.x, p.y * cos(a) - p.z * sin(a), p.y * sin(a) + p.z * cos(a)); }
vec3 twinRotY(vec3 p, float a) { return vec3(p.x * cos(a) + p.z * sin(a), p.y, -p.x * sin(a) + p.z * cos(a)); }
vec3 twinRotZ(vec3 p, float a) { return vec3(p.x * cos(a) - p.y * sin(a), p.x * sin(a) + p.y * cos(a), p.z); }

// A twin vertex in view space, moved by the strike at that tick (plus the tick's fraction from the clock): EXACTLY the
// game's own first-person swing of an item (26.3 FirstPersonHandsAndItemsRenderer swingArm + applyItemArmAttackTransform)
// for the left side (side -1): translate(side * -0.4 sin(sqrt(t) pi), 0.2 sin(sqrt(t) 2 pi), -0.2 sin(t pi)), then round
// the hand Y(side (45 - 20 f)) Z(side g -20) X(g -80) Y(side -45), f = sin(t t pi), g = sin(sqrt(t) pi); at rest all of
// it is nothing (owner 20/11: «l'inclinazione del secondo piccone è diversa quando fa l'animazione»).
vec4 twinStrike(vec4 view, int tick) {
    float partial = 0.0;
#ifdef MAGIX_GLOBALS
    partial = fract(GameTime * 24000.0);
#endif
    float t = clamp((float(tick) + TWIN_LEAD + partial) / float(TWIN_SWING), 0.0, 1.0);
    const float side = -1.0;
    const float PI = 3.14159265;
    const float DEG = PI / 180.0;
    float f = sin(t * t * PI);
    float g = sin(sqrt(t) * PI);
    vec3 p = view.xyz - TWIN_PIVOT;
    p = twinRotY(p, side * -45.0 * DEG);
    p = twinRotX(p, g * -80.0 * DEG);
    p = twinRotZ(p, side * g * -20.0 * DEG);
    p = twinRotY(p, side * (45.0 + f * -20.0) * DEG);
    vec3 swing = vec3(side * -0.4 * sin(sqrt(t) * PI), 0.2 * sin(sqrt(t) * 2.0 * PI), -0.2 * sin(t * PI));
    return vec4(TWIN_PIVOT + swing + p, view.w);
}

#ifdef MAGIX_HALO
// The step round the ring of a halo vertex (0..HALO_STEPS), or -1 for any other vertex.
float haloStep() {
    ivec2 size = textureSize(Sampler0, 0);
    ivec2 at = ivec2(floor(UV0 * vec2(size)));
    if (at.x < 0 || at.y < 0 || at.x >= size.x || at.y + HALO_SIGNATURE_ROWS >= size.y) return -1.0;
    ivec4 t = ivec4(round(texelFetch(Sampler0, at, 0) * 255.0));
    if (t.r != HALO_MARK_RED || t.g < 251 || t.b < 248 || t.a != 255) return -1.0;
    ivec4 s = ivec4(round(texelFetch(Sampler0, at + ivec2(0, HALO_SIGNATURE_ROWS), 0) * 255.0));
    if (s.rgb != HALO_SIGNATURE || s.a != 255) return -1.0;
    return float((255 - t.g) * 8 + (255 - t.b));
}

// The halo's colour at that turn step: the tint, and the running light's head and tail mixed towards white.
vec4 haloColor(float turn, vec4 tint) {
    float light = 0.0;
    if (ivec3(round(tint.rgb * 255.0)) == HALO_PRISM_TINT) {
        float hue = turn / HALO_STEPS;
#ifdef MAGIX_GLOBALS
        hue += GameTime * 1200.0 / HALO_PRISM_LAP_SECONDS;
#endif
        vec3 rainbow = clamp(abs(fract(hue + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
        tint.rgb = mix(vec3(1.0), rainbow, HALO_PRISM_SATURATION);
    }
#ifdef MAGIX_GLOBALS
    float head = fract(GameTime * 1200.0 / HALO_LAP_SECONDS);
    float behind = fract(head - turn / HALO_STEPS);              // 0 at the head, growing along the tail
    light = exp(-behind * HALO_TAIL) * (1.0 - smoothstep(0.96, 1.0, behind));   // just ahead of the head: dark
#endif
    vec3 ring = tint.rgb * mix(HALO_BASE, 1.0, light);
    return vec4(mix(ring, vec3(1.0), HALO_WHITE * light * light), tint.a);
}
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    int twin = twinTick();
    vec4 color = Color;
    if (twin >= 0) {
        gl_Position = ProjMat * twinStrike(ModelViewMat * vec4(Position, 1.0), twin);
        color = vec4(1.0, 1.0, 1.0, Color.a);
    }

#ifdef MAGIX_HALO
    float halo = haloStep();
    // the wearer's own ring in first person: beyond the far plane, not drawn
    if (halo >= 0.0 && length((ModelViewMat * vec4(Position, 1.0)).xyz) < HALO_HIDE_NEAR) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
#endif

#if MAGIX_TARGET == 261
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, color) * sample_lightmap(Sampler2, UV2);
#ifdef MAGIX_HALO
    if (halo >= 0.0) vertexColor = haloColor(halo, Color);
#endif

    texCoord0 = UV0;
#else
    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, color);
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif
    #ifdef MAGIX_HALO
    if (halo >= 0.0) {
        vertexColor = haloColor(halo, Color);
        lightMapColor = vec4(1.0);
    }
    #endif

    texCoord0 = UV0;
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif
#endif
}
