#version 330
#extension GL_ARB_separate_shader_objects : require
#define MAGIX_TARGET 263
#define LOC(n) layout(location = n)

// One source for 26.1, 26.2 and 26.3: see the note at the top of gui.vsh (MAGIX_TARGET, LOC, overlays).

// MagixScoreboard: vanilla "gui" fragment shader (Minecraft 26.2) plus the sidebar background
// recolor and border. The __SB_*__ placeholders are replaced by the plugin from config.yml
// (sidebar-background.*): changing them rebuilds the resource pack.

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
#if MAGIX_TARGET >= 263
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
#else
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;

};
#endif

LOC(0) in vec4 vertexColor;
LOC(1) flat in int sbKind;
LOC(2) in vec2 sbUV;
LOC(3) in vec2 sbGui;
LOC(4) in float sbOk;
LOC(5) in float chatTag;

LOC(0) out vec4 fragColor;

// Background of title and body (same color and opacity for both). Alpha 0 = no background.
const vec4 SB_BACKGROUND = vec4(0.1176, 0.0706, 0.2118, 0.6200);
// Border on the top, left and bottom sides (never the right one), in GUI pixels. 0 = no border.
const float SB_BORDER = 1.0000;
// Horizontal gradient of the border, left to right (like the site: linear-gradient(90deg, ...)).
const vec3 SB_BORDER_START = vec3(0.7804, 0.4902, 1.0000);
const vec3 SB_BORDER_END = vec3(1.0000, 0.3333, 0.9020);
const float SB_BORDER_ALPHA = 0.7000;
// Radius of the left corners (title's top-left, body's bottom-left), GUI pixels; 0 = square (sidebar-background.corner-radius).
const float SB_RADIUS = 5.0000;

void main() {
    vec4 color = vertexColor;
    // Derivatives out of any branch: they must be computed by the whole 2x2 pixel block.
    float width = abs(dFdx(sbGui.x) / max(abs(dFdx(sbUV.x)), 1e-6));
    float height = abs(dFdy(sbGui.y) / max(abs(dFdy(sbUV.y)), 1e-6));
    float guiPerPixel = max(abs(dFdx(sbGui.x)), 1e-4);    // one screen pixel in GUI pixels: the curve's soft edge

    if (sbKind != 0) {
        color = SB_BACKGROUND;
        if (SB_BORDER > 0.0 && sbOk > 0.999) {
            float left = sbUV.x * width;
            float fromTop = sbUV.y * height;
            float fromBottom = (1.0 - sbUV.y) * height;
            // Title: left + top. Body: left + bottom. Together they outline the whole sidebar.
            bool edge = left < SB_BORDER
                    || (sbKind == 2 && fromTop < SB_BORDER)
                    || (sbKind == 1 && fromBottom < SB_BORDER);
            if (edge) {
                color = vec4(mix(SB_BORDER_START, SB_BORDER_END, clamp(sbUV.x, 0.0, 1.0)), SB_BORDER_ALPHA);
            }
        }
        // Rounded left corners (owner 22/11, like the Prison's tab): outside the curve nothing, on it the border.
        if (SB_RADIUS > 0.0 && sbOk > 0.999) {
            float left = sbUV.x * width;
            float fromEdge = sbKind == 2 ? sbUV.y * height : (1.0 - sbUV.y) * height;
            if (left < SB_RADIUS && fromEdge < SB_RADIUS) {
                float dist = length(vec2(SB_RADIUS - left, SB_RADIUS - fromEdge));
                float inside = clamp((SB_RADIUS - dist) / guiPerPixel + 0.5, 0.0, 1.0);
                if (SB_BORDER > 0.0 && dist > SB_RADIUS - SB_BORDER) {
                    color = vec4(mix(SB_BORDER_START, SB_BORDER_END, clamp(sbUV.x, 0.0, 1.0)), SB_BORDER_ALPHA);
                } else if (SB_BORDER > 0.0) {
                    color = SB_BACKGROUND;
                }
                color.a *= inside;
            }
        }
    }

    // The chat's "System" mark (gui.vsh, CHAT_TAG): all four corners marked, so 1 everywhere inside it; a bigger
    // fill with one marked corner is near 1 only right at that corner.
    if (chatTag > 0.999) {
        discard;
    }
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
