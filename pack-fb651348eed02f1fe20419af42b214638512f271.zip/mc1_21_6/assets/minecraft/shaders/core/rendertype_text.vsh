#version 330
#define MAGIX_TARGET 261
#define MAGIX_MC 216
#define LOC(n)

// MagixPack's own text shader: vanilla, plus the screen transition (transition/ScreenTransition.java). It goes in
// the pack only when no plugin registers a text shader of its own (PackService.FALLBACK_FILES): on the faction
// MagixFactions does (minimap, sidebar, theft HUD and this same transition), on the hub nobody does and this one
// is used. Like MagixFactions' shader it is one source for 26.1, 26.2 and 26.3: ShaderVariants writes it three
// times (MAGIX_TARGET, LOC(n), //#263 lines: see README, "Più versioni di Minecraft"). 26.1 has no GUI variant
// (IS_GUI is never defined there): the transition is not drawn on 26.1, its glyph is almost transparent.
// Locations: vanilla 26.3 ones (Position 0, Color 1, UV0 2, UV2 3; out 0..3), ours from 4. They must match text.fsh.

// THE GUI CODE ON 26.1 AND 1.21.6-1.21.11 (owner 22/11: «non vedo le hud dei minerali dei legni e dei token»): those
// clients have no GUI variant of the text shader (IS_GUI is never defined, ONE rendertype_text draws the world's text
// and the screen's). So on MAGIX_TARGET 261 every IS_GUI block is compiled too (MAGIX_GUI_CODE) and runs for every
// vertex, and at the end of main() a vertex drawn with a PERSPECTIVE projection (the world: ProjMat[2][3] == -1; the
// GUI's orthographic one has 0) gets vanilla's position, colour and hudMode 0 back, so nothing in the world moves.
// Globals (ScreenSize, GameTime) is bound for every pipeline there too (1.21.10's glint and end portal read it).
#if defined(IS_GUI) || MAGIX_TARGET == 261
#define MAGIX_GUI_CODE
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
vec4 sample_lightmap(sampler2D lightMap, ivec2 uv) { return texelFetch(lightMap, uv / 16, 0); }
#endif

#ifdef MAGIX_GUI_CODE
// GameTime, for the menu marquee (the GUI text pipeline has the "Globals" block, as MagixFactions' shader uses)
#moj_import <minecraft:globals.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

LOC(0) in vec3 Position;
LOC(1) in vec4 Color;
LOC(2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
LOC(3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
LOC(0) out float sphericalVertexDistance;
LOC(1) out float cylindricalVertexDistance;
#endif

LOC(2) out vec4 vertexColor;
LOC(3) out vec2 texCoord0;

#ifdef MAGIX_GUI_CODE
// The transition is a title made of the glyph of the font magixpack:transition, coloured red 254, blue 5
// (closing) or 6 (opening), green = progress 0..255: a mark no vanilla text uses. The title is centred on the
// screen, so every vertex of the glyph is on its own side of the centre, and that side picks the corner of the
// screen the vertex is moved to. Same mark and same geometry as the theft HUD in MagixFactions' text.vsh,
// which handles blue 5 and 6 the same way: if the mark changes, change both.
// The SHIELD BAR (the few seconds of protection after a teleport): blue 7, green = what is left 0..255, becomes a
// thin timer bar just under the crosshair (shieldBar() in text.fsh); its words are the subtitle, blue 8 (their
// shadow blue 9), brought back to scale 1 and centred just over the bar. SHIELD_* and the two branches are COPIED
// IDENTICAL in MagixFactions' text.vsh.
// The AFK SCREEN of MagixPack (afk/AfkScreen: a player MagixGuard marks as idle, «magix_afk»). Its title starts with
// the glyph of the font magixpack:portal_guide and the space that takes its advance back, marked blue 11: it is
// stretched over the whole screen (the corner read from its texture, guideCorner(): the words after it leave the
// glyph off the screen centre) and drawn by afkScreen() in text.fsh, a frozen, frosted veil with a light blue
// border. The words are three lines. The first is the rest of the title (blue 12, its shadow blue 13): vanilla
// draws it at scale 4 from y -10, here it goes to AFK_LINE1_SCALE from AFK_LINE1_TOP. The subtitle holds the second
// and the third line one after the other (blue 14/15, then 16/17): green = how far that line moves sideways (the
// OTHER line's half width, GUI pixels at scale 1), so each one is centred on its own; vanilla draws the subtitle at
// scale 2 from y 5, here the second goes to AFK_LINE2_SCALE from AFK_LINE2_TOP and the third to scale 1 from
// AFK_LINE3_TOP. All tops are GUI pixels from the screen centre. AFK_* and the branch are COPIED IDENTICAL in
// MagixFactions' and MagixPack's text.vsh: if they change, change both (and AfkScreen.java, which writes the marks).
const float AFK_LINE1_SCALE = 2.0;
const float AFK_LINE1_TOP = -34.0;
const float AFK_LINE2_SCALE = 1.5;
const float AFK_LINE2_TOP = -8.0;
const float AFK_LINE3_TOP = 10.0;
const vec4 AFK_LINE1_FILL = vec4(0.92, 0.98, 1.0, 1.0);
const vec4 AFK_LINE2_FILL = vec4(0.74, 0.92, 1.0, 1.0);
const vec4 AFK_LINE3_FILL = vec4(0.62, 0.82, 0.94, 1.0);
const vec4 AFK_SHADOW = vec4(0.03, 0.14, 0.24, 1.0);
LOC(4) out vec2 hudPos;          // transition: GUI pixels from the screen centre; shield bar: -1..1 across it
LOC(5) flat out int hudMode;     // 0 = vanilla text, 3 = transition, 4 = shield bar, 6 = AFK screen, 10/11 = film (the numbers MagixFactions' shader uses too), 14 = skill ring, 15 = forest screen, 16 = rope gauge, 18 = canvas glow, 20 = canvas underline, 21 = live level ring, 23 = chat halo, 24 = canvas picture light
LOC(6) flat out vec4 hudData;    // transition: half screen size in GUI pixels (xy), progress 0..255 (z), 1 = opening (w);
                                 // shield bar: half size in GUI pixels (xy), what is left 0..255 (z);
                                 // AFK screen: half screen size (xy), seconds (z, GameTime)
LOC(7) flat out vec4 hudBox;     // canvas glow: the TOOLTIP's box from the card's middle (min xy, max zw), never lit
const vec2 SHIELD_BAR_HALF = vec2(46.0, 2.5);   // half size of the shield bar, GUI pixels
const float SHIELD_BAR_Y = 24.0;                // its centre under the screen centre, GUI pixels
const vec4 SHIELD_LABEL_FILL = vec4(0.82, 1.0, 0.9, 1.0);
const vec4 SHIELD_LABEL_SHADOW = vec4(0.03, 0.2, 0.11, 1.0);
uniform sampler2D Sampler0;

// The corner (-1 or 1 on each axis, GUI y down) of a vertex of the glyph of magixpack:portal_guide. Its texture
// (magixpack:font/portal_guide.png, tools/make_portal_guide.py) says in every texel which quarter it is in: red 0 =
// left half, 255 = right; green 0 = top half, 255 = bottom; blue 77 and alpha 16 mark it. The vertex sits on a corner
// of the glyph in the font atlas: of the four texels round it, the one inside the glyph is the one whose quarter is
// that corner, and the corner is the opposite of the way to it. None found: (0, 0), the quad shrinks to nothing.
// COPIED IDENTICAL from MagixFactions' text.vsh (where the spawn portal arrow uses it too).
vec2 guideCorner() {
    vec2 at = UV0 * vec2(textureSize(Sampler0, 0));
    for (int i = 0; i < 4; i++) {
        vec2 d = vec2((i & 1) == 0 ? -1.0 : 1.0, i < 2 ? -1.0 : 1.0);   // the way to the texel looked at
        ivec4 t = ivec4(round(texelFetch(Sampler0, ivec2(floor(at + 0.5 * d)), 0) * 255.0));
        if (t.b == 77 && t.a == 16 && t.r == (d.x > 0.0 ? 0 : 255) && t.g == (d.y > 0.0 ? 0 : 255)) return -d;
    }
    return vec2(0.0);
}
#endif

#ifdef MAGIX_GUI_CODE
// --- MagixPack CINEMA: the newcomers' film (cinematic/CinematicTour) ---------------------------------------------
// The ACTION BAR carries the picture: the glyph of magixpack:portal_guide and its back-space marked red 254 + blue
// CINE_BARS_BLUE (green = how far the black bars are in, 0..255), the same glyph marked CINE_BLACK_BLUE (green = how
// black the whole screen is, 0..255), both stretched over the screen (corner read by guideCorner()) and drawn by
// cinemaScreen() of text.fsh; then the replay hint (blue CINE_REPLAY_BLUE, shadow +1), the scene's heading (blue
// CINE_HEAD_BLUE, shadow +1, in the middle of the top bar, or CINE_CARD_BLUE big over the middle of the picture: the
// opening card) and the skip hint (blue CINE_HINT_BLUE, shadow +1). The two hints go to the ends of the top bar (replay
// on the left, skip on the right: green = half the line's width); the heading's green = 128 + half (skip hint width -
// replay hint width), the way back to the middle. The SUBTITLE holds the two
// lines of the caption one after the other, blue CINE_LINE1_BLUE / CINE_LINE2_BLUE (shadows +1), green = how far that
// line moves sideways (the OTHER line's half width), both in the bottom bar. The titles fade by their own times; the
// action bar is sent again every few ticks. Text scales are whole numbers (sharp letters) that grow with the bars.
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both (and CinematicTour.java).
const int CINE_BARS_BLUE = 40;
const int CINE_BLACK_BLUE = 41;
const int CINE_HEAD_BLUE = 42;
const int CINE_CARD_BLUE = 44;
const int CINE_LINE1_BLUE = 46;
const int CINE_LINE2_BLUE = 48;
const int CINE_HINT_BLUE = 50;
const int CINE_REPLAY_BLUE = 52;
// the opening card in the TITLE, big in the middle of the screen with the MOTD's gradient (magenta to green): blue
// CINE_TITLE_BLUE (shadow +1), green = half its width in title pixels
const int CINE_TITLE_BLUE = 54;
const vec3 CINE_TITLE_FROM = vec3(0.753, 0.275, 0.910);   // #C046E8
const vec3 CINE_TITLE_TO = vec3(0.659, 0.863, 0.173);     // #A8DC2C
const int CINE_RAISED_BLUE = 56;   // the caption's two lines raised over the hotbar (+0/+1 line 1, +2/+3 line 2)
const float CINE_BAR_PART = 0.115;   // each bar, a part of the screen's height
const float CINE_BAR_MIN = 40.0;     // GUI pixels: the hints row + a heading at scale 2
const float CINE_EDGE = 10.0;        // the hints' distance from the left and right edges, GUI pixels
const float CINE_HINT_ROW = 14.0;    // the row of the two hints at the top of the top bar, GUI pixels
const vec4 CINE_HEAD_FILL = vec4(0.93, 0.80, 0.50, 1.0);
const vec4 CINE_CARD_FILL = vec4(1.0, 0.95, 0.84, 1.0);
const vec4 CINE_LINE_FILL = vec4(0.96, 0.96, 0.95, 1.0);
const vec4 CINE_HINT_FILL = vec4(0.58, 0.58, 0.62, 1.0);
const vec4 CINE_SHADOW = vec4(0.0, 0.0, 0.0, 1.0);

// The height of each black bar on a screen of half size h (GUI pixels), whole pixels.
float cinemaBar(vec2 h) {
    return floor(max(CINE_BAR_MIN, CINE_BAR_PART * 2.0 * h.y));
}

// The film's POINTER (a gold arrow bobbing towards what the narrator talks about):
//  - over a tile of a 6-row drawn menu: a glyph of magixpack:portal_guide in the MENU'S TITLE marked red 254 + blue
//    CINE_RECT_BLUE + (w - 1) * 3 + (h - 1) (w 1..9 columns, h 1..3 rows), green = its top left slot (0..89: 0-53 the
//    chest, 54-80 the player's inventory, 81-89 the hotbar), framed with a pulsing gold border, the arrow outside the window beside it;
//  - over a place of the HUD: the same glyph in the ACTION BAR marked CINE_ANCHOR_BLUE + 0 (the stats panel right of
//    the hotbar), 1 (the sidebar), 2 (the minimap), the arrow pointing at it.
// The film's CAPTION inside a drawn menu (the HUD under a menu is dimmed by the screen's backdrop): the two lines are
// written in the menu's title from the title's own start, in the default font, marked CINE_MENU_LINE_BLUE + line * 2
// (+1 the shadow), green = half the line's width; they go to the bottom bar like the subtitle's lines.
const int CINE_ANCHOR_BLUE = 90;
const int CINE_RECT_BLUE = 100;
const int CINE_MENU_LINE_BLUE = 160;
const float CINE_POINT_MARGIN = 12.0;   // room round a framed tile for its glow, GUI pixels
const float CINE_POINT_GAP = 3.0;      // the side arrow's tip from the window's edge, GUI pixels
const float CINE_POINT_ARROW = 42.0;   // room for the side arrow, GUI pixels

// The left and top of a 6-row chest window with the player's inventory (176 x 222), GUI pixels.
vec2 cinemaWindow(vec2 h) {
    return vec2(floor((ceil(2.0 * h.x - 0.01) - 176.0) * 0.5), floor((ceil(2.0 * h.y - 0.01) - 222.0) * 0.5));
}

// The top of a slot row of that window: 0-5 the chest, 6-8 the inventory, 9 the hotbar.
float cinemaSlotY(int row) {
    return row < 6 ? 18.0 + 18.0 * float(row) : row < 9 ? 139.0 + 18.0 * float(row - 6) : 197.0;
}

bool cinemaPointerVertex(ivec3 rgb, vec4 v, vec2 h, float bar, inout vec4 labelColor) {
    if (rgb.b >= CINE_RECT_BLUE && rgb.b < CINE_RECT_BLUE + 27 && rgb.g < 90) {
        int wh = rgb.b - CINE_RECT_BLUE;
        int col = rgb.g - (rgb.g / 9) * 9, row = rgb.g / 9;
        int w = wh / 3 + 1, hh = wh - (wh / 3) * 3 + 1;
        vec2 win = cinemaWindow(h);
        vec2 lo = win + vec2(7.0 + 18.0 * float(col), cinemaSlotY(row) - 1.0);
        vec2 hi = win + vec2(7.0 + 18.0 * float(min(col + w, 9)), cinemaSlotY(min(row + hh - 1, 9)) + 17.0);
        vec2 centre = (lo + hi) * 0.5, half_ = (hi - lo) * 0.5;
        // the arrow OUTSIDE the window, beside the tile's row, pointing at it from the nearer side: over the window it
        // went under the items the client draws after the title (the band, the title light)
        bool right = float(col) + float(w) * 0.5 > 4.5;
        float tip = right ? win.x + 176.0 + CINE_POINT_GAP - centre.x : win.x - CINE_POINT_GAP - centre.x;
        float bmin = min(-half_.x - CINE_POINT_MARGIN, tip - CINE_POINT_ARROW);
        float bmax = max(half_.x + CINE_POINT_MARGIN, tip + CINE_POINT_ARROW);
        vec2 qc = vec2((bmin + bmax) * 0.5, 0.0), qh = vec2((bmax - bmin) * 0.5, half_.y + CINE_POINT_MARGIN);
        vec2 corner = guideCorner();
        hudMode = 12;
        hudPos = qc + corner * qh;
        hudData = vec4(half_, GameTime * 1200.0, tip / 1000.0);   // |w| < 0.5: a framed tile, w * 1000 = the tip's x
        gl_Position = ProjMat * vec4(centre + hudPos, v.z, v.w);
        return true;
    }
    if (rgb.b >= CINE_ANCHOR_BLUE && rgb.b <= CINE_ANCHOR_BLUE + 2) {
        int kind = rgb.b - CINE_ANCHOR_BLUE;
        vec2 at, dir;
        if (kind == 0) {
            at = vec2(floor(h.x) + 91.0 + 6.0 + 34.0, 2.0 * h.y - 24.0);
            dir = vec2(0.0, 1.0);
        } else if (kind == 1) {
            at = vec2(2.0 * h.x - 132.0, h.y);
            dir = vec2(1.0, 0.0);
        } else {
            float unit = 16.0 / 9.0 * h.y;
            float side = 0.27 * unit, margin = 0.03 * unit;
            at = vec2(2.0 * h.x - margin - side - 4.0, margin + side + 4.0);
            dir = normalize(vec2(1.0, -1.0));
        }
        vec2 corner = guideCorner();
        hudMode = 12;
        hudPos = corner * 36.0 - dir * 20.0;    // the tip at hudPos 0, the arrow's body behind it
        hudData = vec4(dir, GameTime * 1200.0, 1.0);
        gl_Position = ProjMat * vec4(at - dir * 20.0 + corner * 36.0, v.z, v.w);
        return true;
    }
    if (rgb.b >= CINE_MENU_LINE_BLUE && rgb.b <= CINE_MENU_LINE_BLUE + 3) {
        int line = (rgb.b - CINE_MENU_LINE_BLUE) / 2;
        bool shadow = (rgb.b - CINE_MENU_LINE_BLUE) % 2 == 1;
        vec2 win = cinemaWindow(h);
        float s = max(1.0, floor(bar / 30.0));
        vec2 local = v.xy - (win + vec2(8.0, 6.0)) - vec2(float(rgb.g), 4.5);
        float gap = 5.5 * s + 1.0;
        vec2 at = local * s + vec2(0.0, h.y - bar * 0.5 + (line == 0 ? -gap : gap));
        gl_Position = ProjMat * vec4(h + at, v.z, v.w);
        labelColor = vec4((shadow ? CINE_SHADOW : CINE_LINE_FILL).rgb, Color.a);
        return true;
    }
    return false;
}

// A vertex of the film's picture or words: moved where it goes (gl_Position, hudMode, hudPos, hudData, labelColor);
// false for any other vertex.
bool cinemaVertex(ivec3 rgb, inout vec4 labelColor) {
    if (rgb.r != 254 || rgb.b < CINE_BARS_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    float bar = cinemaBar(h);
    if (rgb.b > CINE_TITLE_BLUE + 1 && (rgb.b < CINE_RAISED_BLUE || rgb.b > CINE_RAISED_BLUE + 3)) {
        return cinemaPointerVertex(rgb, v, h, bar, labelColor);
    }
    float s = max(1.0, floor(bar / 30.0));
    if (rgb.b == CINE_BARS_BLUE || rgb.b == CINE_BLACK_BLUE) {
        vec2 corner = guideCorner();
        hudMode = rgb.b == CINE_BARS_BLUE ? 10 : 11;
        hudPos = corner * h;
        hudData = vec4(h, float(rgb.g), bar);
        gl_Position = ProjMat * vec4(h + corner * h, v.z, v.w);
        return true;
    }
    int kind = (rgb.b - CINE_HEAD_BLUE) / 2;   // 0 heading, 1 card, 2 caption line 1, 3 caption line 2, 4 hint, 5 replay
    bool shadow = (rgb.b - CINE_HEAD_BLUE) % 2 == 1;
    // the caption RAISED over the hotbar (the scene that points at the HUD, without bars): CINE_RAISED_BLUE..+3
    bool raised = rgb.b >= CINE_RAISED_BLUE && rgb.b <= CINE_RAISED_BLUE + 3;
    if (raised) {
        kind = rgb.b < CINE_RAISED_BLUE + 2 ? 2 : 3;
        shadow = (rgb.b - CINE_RAISED_BLUE) % 2 == 1;
    } else if (rgb.b == CINE_TITLE_BLUE || rgb.b == CINE_TITLE_BLUE + 1) {
        // the title: vanilla draws it at scale 4 from y -10 round the middle; centred on the middle here
        vec2 local = (v.xy - h) / 4.0 + vec2(0.0, 5.5);
        float u = clamp(local.x / max(1.0, float(rgb.g)) * 0.5 + 0.5, 0.0, 1.0);
        vec3 grad = mix(CINE_TITLE_FROM, CINE_TITLE_TO, u);
        bool titleShadow = rgb.b == CINE_TITLE_BLUE + 1;
        gl_Position = ProjMat * vec4(h + local * max(2.0, floor(h.y / 40.0)), v.z, v.w);
        labelColor = vec4(titleShadow ? grad * 0.22 : grad, Color.a);
        return true;
    } else if (rgb.b > CINE_REPLAY_BLUE + 1) {
        return false;
    }
    vec2 at;
    vec4 fill;
    // the action bar: scale 1 from (width / 2, height - 68), the text from y -4
    vec2 bar1 = v.xy - vec2(h.x, 2.0 * h.y - 68.0) - vec2(0.0, 0.5);
    if (kind <= 1) {
        // the heading, in the action bar between the hints: back to the middle, then scaled
        vec2 local = bar1 + vec2(float(rgb.g) - 128.0, 0.0);
        if (kind == 0) {
            // big in the middle of the top bar, under the row of the two hints
            at = local * max(2.0, s) + vec2(0.0, -h.y + (bar + CINE_HINT_ROW) * 0.5);
            fill = CINE_HEAD_FILL;
        } else {
            at = local * max(2.0, floor(h.y / 40.0)) + vec2(0.0, -h.y * 0.12);
            fill = CINE_CARD_FILL;
        }
    } else if (kind <= 3) {
        // the subtitle: vanilla draws it at scale 2 from y 5
        vec2 local = (v.xy - h) / 2.0 - vec2(0.0, 9.5);
        local.x += kind == 2 ? float(rgb.g) : -float(rgb.g);
        float gap = 5.5 * s + 1.0;
        at = local * s + vec2(0.0, h.y - bar * 0.5 + (kind == 2 ? -gap : gap) - (raised ? bar * 0.5 + 30.0 : 0.0));
        fill = CINE_LINE_FILL;
    } else if (kind == 4) {
        at = vec2(h.x - CINE_EDGE - float(rgb.g) + bar1.x, -h.y + CINE_HINT_ROW * 0.5 + 2.0 + bar1.y);
        fill = CINE_HINT_FILL;
    } else {
        at = vec2(-h.x + CINE_EDGE + float(rgb.g) + bar1.x, -h.y + CINE_HINT_ROW * 0.5 + 2.0 + bar1.y);
        fill = CINE_HINT_FILL;
    }
    gl_Position = ProjMat * vec4(h + at, v.z, v.w);
    labelColor = vec4((shadow ? CINE_SHADOW : fill).rgb, Color.a);
    return true;
}

// --- MagixPack MANA FLIGHT (owner 4/11, MagixPrison's fx/ManaFlight): the Mana of a dig flies into the scoreboard ------
// After the orb rose out of the dug block and bounced in the world, MagixPrison sends one TITLE a tick made of ONE glyph
// of the font magixprison:mana_flight (16 pixels tall, ascent 8, no shadow) coloured red 254 + blue MANA_FLIGHT_BLUE +
// green = progress 0..255. Here the glyph pops out of the crosshair, grows, then flies along a curve up to the Mana bar
// of the scoreboard, shrinking and fading into it. MANA_FLIGHT_TARGET is the bar's place: GUI pixels left of the
// screen's right edge (x) and from the screen's middle (y), on the prison's board (14 lines, the bar on the third: the
// game puts line t of n at H/2 + 3n - 9(n - t)); tune it there if the orb lands beside the bar. MagixPack only (the
// faction runs MagixFactions' text shader and has no Mana).
const int MANA_FLIGHT_BLUE = 200;
const vec2 MANA_FLIGHT_TARGET = vec2(48.0, -62.0);
bool manaFlightVertex(ivec3 rgb, inout vec4 labelColor) {
    if (rgb.r != 254 || rgb.b != MANA_FLIGHT_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    // the title at scale 4 from y -10 round the middle; the glyph's own middle is (-0.5, 7) there
    vec2 local = (v.xy - h) / 4.0 + vec2(0.0, 10.0) - vec2(-0.5, 7.0);
    vec2 corner = vec2(local.x > 0.0 ? 1.0 : -1.0, local.y > 0.0 ? 1.0 : -1.0);
    float p = clamp(float(rgb.g) / 255.0, 0.0, 1.0);
    vec2 start = vec2(0.0, -10.0);
    vec2 target = vec2(h.x - MANA_FLIGHT_TARGET.x, MANA_FLIGHT_TARGET.y);
    vec2 pos;
    float size;
    float alpha = 1.0;
    if (p < 0.18) {
        // the pop: out of the crosshair, growing with a small overshoot
        float t = p / 0.18;
        pos = mix(vec2(0.0, 0.0), start, t);
        size = mix(2.0, 6.0, sin(t * 1.9));
    } else {
        // the flight: a curve rising above the line between the two places, faster and faster, smaller and smaller
        float t = (p - 0.18) / 0.82;
        float e = t * t * (3.0 - 2.0 * t);
        e = mix(e, t * t, 0.5);
        vec2 control = vec2(mix(start.x, target.x, 0.35), min(start.y, target.y) - 70.0);
        pos = mix(mix(start, control, e), mix(control, target, e), e);
        size = mix(5.5, 2.0, e);
        alpha = 1.0 - smoothstep(0.86, 1.0, t);
    }
    gl_Position = ProjMat * vec4(h + pos + corner * size, v.z, v.w);
    labelColor = vec4(1.0, 1.0, 1.0, Color.a * alpha);
    return true;
}

// --- MagixPack MINERAL FLIGHT (owner 8/11, MagixPrison's fx/ManaFlight): a piece of the dug ore flies into its slot ----
// «così come il mana è animato e va verso la scoreboard, i minerali devono andare verso il pannello minerali (verso la
// loro slot)». An ore dug: MagixPrison sends, as the SUBTITLE (scale 2, from y 5; the Mana's orb keeps the title), one
// glyph of the font magixprison:mineral_flight (the ore block's own texture, 16 tall, ascent 8, no shadow) coloured
// red 254 + blue MINERAL_FLIGHT_BLUE + the mineral's slot (0..8) + green = progress. It pops out of the crosshair,
// spins and flies along an arc into that slot of the HOTBAR HUD's panel (the same anchor and shrink as the HOTBAR_HUD
// block below: slots of 21 from x 0, the item's middle 11 in and 22 rows under the panel's top), shrinking into it;
// there the slot's item swallows it (the gulp of the HOTBAR HUD block, blue 96 + phase).
const float MINERAL_HUD_GAP = 6.0;      // = HOTBAR_HUD_GAP
const float MINERAL_HUD_UP = 33.0;      // = HOTBAR_HUD_UP
const float MINERAL_HUD_FIT_W = 190.0;  // = HOTBAR_HUD_FIT_W
const float MINERAL_HUD_MARGIN = 3.0;   // = HOTBAR_HUD_MARGIN
const int MINERAL_FLIGHT_BLUE = 210;
// THE HOTBAR PANELS' SIZE IS EACH PLAYER'S CHOICE (owner 14/11: «qualcuno le vede più grandi rispetto alla hotbar
// vanilla»; MagixPrison /prison hud size, the settings' «Schermo» page): the panel's mark red says which of three sizes
// the player chose, for every Prison panel of the HOTBAR HUD (minerals, runes, wood, tokens, enchantments) and the
// flights into their slots (their green carries it, see HUD_SIZE_STEPS):
//   HOTBAR_HUD_RED (247)       = NORMAL: one panel pixel per GUI pixel, always the vanilla hotbar's own size;
//   HOTBAR_HUD_RED_SMALL (246) = SMALL: HUD_SIZE_SMALL of the hotbar's size;
//   HOTBAR_HUD_RED_LARGE (244) = LARGE: HUD_SIZE_LARGE of the hotbar's size, or the fixed size of 13/11 (HUD_LOCK_PIXELS
//                                screen pixels a panel pixel, the hotbar's at GUI scale 3) when that is bigger.
// They still shrink where there is no room (hudFit), never under HUD_LOCK_MIN. Until 14/11 every player had the fixed
// size: at GUI scale 2 the panels were one and a half times the hotbar.
const int HOTBAR_HUD_RED = 247;
const int HOTBAR_HUD_RED_SMALL = 246;
const int HOTBAR_HUD_RED_LARGE = 244;
const float HUD_SIZE_SMALL = 0.75;
const float HUD_SIZE_LARGE = 1.25;
const float HUD_LOCK_PIXELS = 3.0;
const float HUD_LOCK_MIN = 0.3;
// a flight into a slot carries the size in its green: size * HUD_SIZE_STEPS + progress (0..HUD_SIZE_STEPS - 1)
const int HUD_SIZE_STEPS = 85;
// 0 normal, 1 small, 2 large, -1 not a panel's red
int hudSizeOf(int red) {
    return red == HOTBAR_HUD_RED ? 0 : red == HOTBAR_HUD_RED_SMALL ? 1 : red == HOTBAR_HUD_RED_LARGE ? 2 : -1;
}
float hudSize(float guiH, int size) {
    if (size == 1) return HUD_SIZE_SMALL;
    if (size != 2) return 1.0;
#ifdef MAGIX_GUI_CODE
    float guiScale = ScreenSize.y / max(guiH, 1.0);
    return max(HUD_SIZE_LARGE, guiScale > 0.0 ? HUD_LOCK_PIXELS / guiScale : 1.0);
#else
    return HUD_SIZE_LARGE;
#endif
}
float hudFit(float guiH, float fit, int size) {
    return max(min(hudSize(guiH, size), fit), HUD_LOCK_MIN);
}

bool mineralFlightVertex(ivec3 rgb, inout vec4 labelColor) {
    if (rgb.r != 254 || rgb.b < MINERAL_FLIGHT_BLUE || rgb.b > MINERAL_FLIGHT_BLUE + 8) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 local = (v.xy - h) / 2.0 - vec2(0.0, 5.0) - vec2(-0.5, 7.0);
    vec2 corner = vec2(local.x > 0.0 ? 1.0 : -1.0, local.y > 0.0 ? 1.0 : -1.0);
    int hudSz = min(rgb.g / HUD_SIZE_STEPS, 2);
    float p = clamp(float(rgb.g - hudSz * HUD_SIZE_STEPS) / float(HUD_SIZE_STEPS - 1), 0.0, 1.0);
    float slot = float(rgb.b - MINERAL_FLIGHT_BLUE);
    float screenW = round(2.0 * h.x);
    float left = floor(screenW * 0.5) + 91.0 + MINERAL_HUD_GAP;
    float scale = hudFit(2.0 * h.y, (screenW - left - MINERAL_HUD_MARGIN) / MINERAL_HUD_FIT_W, hudSz);
    vec2 target = vec2(left + (slot * 21.0 + 11.0) * scale, 2.0 * h.y - MINERAL_HUD_UP * scale + 22.0 * scale) - h;
    vec2 pos;
    float size;
    float alpha = 1.0;
    float angle;
    if (p < 0.2) {
        // the pop out of the crosshair, growing with a small overshoot
        float t = p / 0.2;
        pos = vec2(0.0, -6.0 * t);
        size = mix(1.5, 5.5, sin(t * 1.9));
        angle = t * 1.2;
    } else {
        // an arc over the line to the slot, faster and faster, spinning, smaller and smaller
        float t = (p - 0.2) / 0.8;
        float e = mix(t * t * (3.0 - 2.0 * t), t * t, 0.5);
        vec2 start = vec2(0.0, -6.0);
        vec2 control = vec2(mix(start.x, target.x, 0.6), min(start.y, target.y) - 50.0);
        pos = mix(mix(start, control, e), mix(control, target, e), e);
        size = mix(5.0, 2.5 * scale, e);
        angle = 1.2 + e * 9.0;
        alpha = 1.0 - smoothstep(0.92, 1.0, t);
    }
    vec2 c = corner * size;
    float cs = cos(angle), sn = sin(angle);
    gl_Position = ProjMat * vec4(h + pos + vec2(c.x * cs - c.y * sn, c.x * sn + c.y * cs), v.z, v.w);
    labelColor = vec4(1.0, 1.0, 1.0, Color.a * alpha);
    return true;
}

#endif

#ifdef MAGIX_GUI_CODE
// --- MagixPack menu MARQUEE: a menu label too wide for its box scrolls from right to left -------------------
// MagixPack (menu/MenuPanel.marquee, a label wider than its max) writes every character of the label in a colour
// of its own: red 253 (the mark), green = the character's distance from the label's start, blue = the label's whole
// width rounded up to 8 (GUI pixels) + the index of its box in MARQUEE_BOXES (= MenuPanel.MARQUEE_BOXES). Here every
// character moves left with time and comes back on the right after the end (one copy of the text, then
// MARQUEE_GAP), fading in and out at the edges of the box, from the label's start. After each turn the text rests
// MARQUEE_HOLD seconds at its start. The words are drawn white (the mark is not a colour).
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both.
const float MARQUEE_BOXES[8] = float[8](36.0, 48.0, 64.0, 80.0, 96.0, 112.0, 144.0, 192.0); // GUI pixels (the fades reach MARQUEE_FADE past each edge: a tile's 36 + 8 inside its 3 slots)
const float MARQUEE_GAP = 18.0;     // between the end of the text and its start coming back
const float MARQUEE_SPEED = 16.0;   // GUI pixels per second
const float MARQUEE_HOLD = 1.5;     // seconds at the start of each turn
const float MARQUEE_FADE = 4.0;     // GUI pixels of fading at each edge
const float MARQUEE_CHAR = 5.0;     // the width of a character, for the right edge

// --- MagixPack panel CREDITS: a side panel of a drawn menu with more lines than fit scrolls up like end credits ------
// MagixPack (menu/MenuPanel.panel, a panel with more lines than menu-panel.lines) writes every character of the panel
// on the panel's FIRST text row, in a colour of its own: red 250 (the mark), green = the line's number (0-31) + 32 * its
// colour (an index of CREDITS_PALETTE), blue = how many lines the panel has. Here every character goes down to its line
// minus the distance scrolled with time: the lines leave at the top of the window (CREDITS_LINES lines of CREDITS_LINE
// GUI pixels) and come back from its bottom, fading at both edges; each turn starts with CREDITS_HOLD seconds still.
// Never 251: 251 % 8 == 3, the mark of MagixFactions' sidebar lines (every channel % 8 == 3), whose reddest colours have
// red 251: on 17/10 the scoreboard scrolled up like the panel. Only blue 2..32 with the line under it counts.
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both (and MenuPanel.CREDITS_*).
const float CREDITS_LINE = 10.0;    // = menu-panel.line-height
const float CREDITS_LINES = 15.0;   // = menu-panel.lines: the window's height in lines
const float CREDITS_GAP = 3.0;      // empty lines between the last line and the first coming back
const float CREDITS_SPEED = 9.0;    // GUI pixels per second
const float CREDITS_HOLD = 3.0;     // seconds still at the start of each turn
const float CREDITS_FADE = 8.0;     // GUI pixels of fading at the top and the bottom
const float CREDITS_TOP_FADE = 3.0; // GUI pixels over the window's top in which a line leaving fades out: never more,
                                    // the panel's glyph (the avatar) sits right over it (owner 4/11: lines crossed it)
const vec3 CREDITS_PALETTE[8] = vec3[](vec3(1.0), vec3(0.6667), vec3(1.0, 0.761, 0.239), vec3(1.0, 0.541, 0.541),
        vec3(0.498, 0.839, 1.0), vec3(0.333, 0.902, 0.510), vec3(0.788, 0.733, 0.847), vec3(0.604, 0.549, 0.659));
#endif

#ifdef MAGIX_GUI_CODE
// --- MagixPack COMPACT MENUS: a drawn menu fits a screen too short or too narrow for it --------------------------
// The client centres a chest's window and never moves its slots (clicks land where the client thinks the slots are),
// but everything MagixPack draws AROUND the window is ours to move. With a big GUI scale on a small screen (scale 4 on
// 1920x1080: 480 x 270 GUI pixels, 253 in a window) the page under a drawn menu (518 wide, up to 328 tall with the
// boss banner) went off the screen. Three marks, all written by MagixPack (menu/MenuPanel):
//  - a PIECE OF THE PAGE (menu-page/<id>.png): red FIT_PAGE_RED, green 128 + zone + 4 * (rows - 1), blue = how far the
//    page reaches above its window (GUI pixels). The page is cut on the window's top and bottom lines and on the edges
//    of its side margins, so every piece is in one zone: 0 beside or behind the window (never moved), 1 above it
//    (squeezed towards the window's top until it fits between it and the screen's top), 2 under it (its bottom
//    stops at the screen's bottom). Every piece is also kept inside the screen's width (only the side margins,
//    pure landscape, reach past the banner's width). rows = the chest's rows: the window's top is where the client
//    puts it, (screen height - (114 + 18 * rows)) / 2 rounded down.
//  - a piece of the BANNER above the window (its picture or board): red FIT_BANNER_RED, green 160 + rows, blue = how
//    far the banner's top is above the window. When the window's top is nearer to the screen's top than that, the
//    banner cannot fit: it goes away (with its labels, and the sharp copy drawn by items: MagixPack's
//    position_tex_color.vsh, same rule).
//  - a LETTER above the window (the fonts of the label rows above the title's line, any colour): a see-through texel
//    in each corner of its texture, red = the banner's height above the window as above, green = 64 + 1 (right
//    column) + 2 (bottom row), blue = 128 + the window's top minus that corner's y. Found like guideCorner().
// Everything keeps FIT_MARGIN GUI pixels from the screen's edges (owner, 17/10: the menu must never touch them).
// Marked pieces are drawn white (the marks are not colours). Nothing changes while the menu fits. A vertex sent out
// of the screen with its three companions is not drawn. A LETTER is never moved: its vertex only turns see-through
// (alpha 0, fitLetterHidden), and only when its mark agrees with where a window's top is (fitLetterOnWindow); a real
// letter has its four vertices marked, so all of it goes, while a vertex misread on another glyph only fades a piece of
// it (23/10, Lunar Client: the tablist's names still drew red streaks to the bottom left with FIT_GONE).
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both (and MenuPanel.FIT_*,
// and menu-panel/position_tex_color.vsh of MagixPack).
const int FIT_PAGE_RED = 249;
const int FIT_BANNER_RED = 248;
const float FIT_MARGIN = 6.0;   // GUI pixels kept free between the menu and the screen's edges (= position_tex_color.vsh)
const vec4 FIT_GONE = vec4(-4.0, -4.0, 0.0, 1.0);

// The window's top (GUI y) of a chest of that many rows on a screen guiH GUI pixels tall. The projection may say a
// height that is not whole (the window's pixels divided by the GUI scale, e.g. 344.25), while the client lays the screen
// out on that height rounded UP (Window.guiScaledHeight): rounding it any other way put the window's top one pixel off,
// and a line of the world showed between the squeezed page and the window (17/10).
float fitWindowTop(float guiH, int rows) {
    return floor((ceil(guiH - 0.01) - float(114 + 18 * rows)) * 0.5);
}

// The mark of a letter above the window (see FIT_PAGE_RED): x = the window's top minus this vertex's y, y = the
// banner's height above the window; y < 0: no mark (any other letter).
vec2 fitLetterMark() {
    vec2 at = UV0 * vec2(textureSize(Sampler0, 0));
    for (int i = 0; i < 4; i++) {
        vec2 d = vec2((i & 1) == 0 ? -1.0 : 1.0, i < 2 ? -1.0 : 1.0);   // the way to the texel looked at
        ivec4 t = ivec4(round(texelFetch(Sampler0, ivec2(floor(at + 0.5 * d)), 0) * 255.0));
        int corner = (d.x < 0.0 ? 1 : 0) + (d.y < 0.0 ? 2 : 0);          // the texel is inside, the vertex on this corner
        if (t.a == 0 && t.g == 64 + corner && t.r > 0) return vec2(float(t.b - 128), float(t.r));
    }
    return vec2(0.0, -1.0);
}

// A letter's mark says where the window's top is (its y + the mark). A mark read from ANOTHER glyph next to this one in
// the font atlas (Lunar Client packs its glyphs with no gap between them: the corner texel of a marked letter is then
// also round a corner of its neighbour) says a window's top that is nowhere: such a vertex is left alone. Before this
// (19/10) single vertices of the boss bar and of Lunar's HUD text went out of the screen and drew long streaks of
// light from the bottom left corner, and letters lost a piece («Boss» read «Loss»). Since 23/10 a hidden letter is not
// moved at all (fitLetterHidden): a misread vertex can no longer draw a streak, whatever coincidence lets it through.
bool fitLetterOnWindow(float windowTop, float guiH) {
    for (int rows = 1; rows <= 6; rows++) {
        if (abs(windowTop - fitWindowTop(guiH, rows)) <= 1.5) return true;
    }
    return false;
}
#endif

#ifdef MAGIX_GUI_CODE
// --- HOTBAR HUD: a boss bar title drawn RIGHT OF THE HOTBAR (MagixPrison economy/MineralHud, owner 7/11) -------------
// The same mark as MagixFactions' text.vsh (MagixQuests' stats panel on the faction, see HOTBAR_HUD_WIDTH there): a
// title exactly HOTBAR_HUD_WIDTH GUI pixels wide sent as a see-through WHITE boss bar; every character marked red
// HOTBAR_HUD_RED + green = GUI pixels from the panel's top to its row + 1 + blue = 32 + its colour index in
// HOTBAR_PALETTE (+ 16 for its shadow, which the plugin sets itself) is moved so that the panel's left edge is
// HOTBAR_HUD_GAP right of the hotbar and its top HOTBAR_HUD_UP over the screen's bottom (the Prison's panel is 33 tall:
// its hint line over the slots, 11 over the hotbar's top, owner 7/11), at the GUI's own scale. Pictures are glyphs of a bitmap font marked like text
// (white = the picture as it is), each inside its boss bar line (at most 11 tall, ascent 10: a taller one is split
// between two lines and stretched across the screen, 7/11). Only characters in the band where such a title can be are
// moved. The palette here is the Prison's (Soldi and the minerals): MagixFactions' shader, used on the faction, has its
// own.
const float HOTBAR_HUD_WIDTH = 256.0;
const float HOTBAR_HUD_GAP = 6.0;
const float HOTBAR_HUD_UP = 33.0;
const float HOTBAR_HUD_BAND = 200.0;
// How far past the title's expected left and right ends a marked vertex still counts. Every vertex decides alone, so a
// glyph whose quad crosses the band's edge had some vertices moved down to the hotbar and the others left at the top:
// a streak across the whole screen. Lunar Client measures a boss bar title a few pixels wider than vanilla (18/11: two
// dark streaks from the boss bars down to the rune and mineral panels; the slack was 2): the band is wide enough now.
const float HOTBAR_HUD_SLACK = 32.0;
// how wide the panel is drawn (MagixPrison's MineralHud: nine slots of 22 touching = 190) and the room kept at the
// screen's right edge: on a GUI narrower than the hotbar + gap + this the panel shrinks to fit (see the HOTBAR HUD block)
const float HOTBAR_HUD_FIT_W = 190.0;
const float HOTBAR_HUD_MARGIN = 3.0;
// THE LEFT PANEL (MagixPrison rune/RuneHud, owner 8/11: runes and neutral gems «a sinistra»): the same title and marks with
// blue 64 + colour (+ 16 for its shadow): drawn so that its RIGHT edge is HOTBAR_HUD_GAP left of the off hand's slot
// (HOTBAR_HUD_OFFHAND left of the hotbar), the panel HOTBAR_HUD_LEFT_W wide (owner 8/11: the six runes, slots of 22
// touching = 127, plus a pixel each side for the bigger frame of the rune on the pickaxe = 130).
const float HOTBAR_HUD_LEFT_W = 130.0;
const float HOTBAR_HUD_OFFHAND = 29.0;
// THE WOOD PANEL (MagixPrison economy/Woods, owner 9-11/11): the same title, marks blue 128 + colour (+ 16 its shadow),
// one slot every WOOD_PITCH pixels of the title (glyphs of a slot never reach the next: the slot is 22 wide), drawn in a
// column on the screen's LEFT EDGE, WOOD_MARGIN in, centred on WOOD_MAX slots half way up; WOOD_TOP = the slot's top
// row in the title (MineralHud.TOP), WOOD_ROW = a slot under the other (22, touching like the hotbar's = 21).
const float WOOD_PITCH = 40.0;
const float WOOD_INSET = 9.0;
const float WOOD_PER_GROUP = 6.0;
const float WOOD_GROUP_G = 64.0;
const float WOOD_ROW = 21.0;
const float WOOD_TOP = 11.0;
const float WOOD_MARGIN = 4.0;
const float WOOD_MAX = 11.0;
// «Apri con /woods» (owner 19/11): the wood panel's hint, marked green + WOOD_HINT_G (96..127, over every slot's own
// greens, the second line's included) in the title along the column's WOOD_MAX * WOOD_ROW pixels, turned a quarter LEFT
// (reading upwards like the tokens') and drawn RIGHT of the column, WOOD_HINT_GAP from it (the screen's edge is left of it).
const float WOOD_HINT_G = 96.0;
const float WOOD_HINT_GAP = 4.0;
// THE TOKENS' PANEL (MagixPrison MineralHud tokenPanel, owner 13/11: «portalo sotto la scoreboard a destra»): the same
// title, marks blue 160 + colour (+ 16 its shadow), written like the wood's (a slot every WOOD_PITCH pixels, WOOD_INSET
// in), drawn as ONE COLUMN of slots touching like the hotbar's (21 apart, owner 13/11: «in verticale»), TOKEN_RIGHT from
// the screen's right edge (the sidebar's own right edge), TOKEN_GAP under the sidebar, shrunk (down to 0.5) when it would
// reach the screen's bottom or the minerals' panel. The game draws the sidebar's bottom at guiHeight / 2
// + (lines * 9) / 3 (Hud#displayScoreboardSidebar, 26.2): the Prison's board always has TOKEN_SB_LINES lines (the
// game's most, 15).
const float TOKEN_MAX = 6.0;
const float TOKEN_GAP = 8.0;   // owner 13/11: «staccalo dalla scoreboard, è appiccicato» (2 until 0.42.21)
const float TOKEN_RIGHT = 4.0;   // = WOOD_MARGIN: as far from the right edge as the wood from the left (owner 13/11; 1 until 0.42.22)
const float TOKEN_SB_LINES = 15.0;
// «Apri con /tokens» (owner 14/11): the token panel's hint, marked green + TOKEN_HINT_G (96..127) in the title along
// the column's TOKEN_MAX * WOOD_ROW pixels, turned a quarter LEFT (reading upwards) and drawn TOKEN_HINT_W left of the
// column, the glyphs' top towards the screen's middle.
const float TOKEN_HINT_G = 96.0;
const float TOKEN_HINT_W = 10.0;
// THE ENCHANTMENTS' PANEL (MagixPrison MineralHud enchantTitle, owner 14/11: «in alto a tutto come bossbar, le altre
// bossbar SOTTO di esso»): its OWN boss bar title, the player's first, marks blue 192 + colour (+ 16 its shadow), a row of
// five medallions with their words in the title's middle ENCH_W pixels, drawn centred at ENCH_TOP GUI pixels from the
// screen's top at the GUI's own scale, like a boss bar (33 rows tall: medallions, then their words). MagixPrison sends an empty boss bar right after
// it, so the other boss bars start from the third line (y 50), under the panel.
const float ENCH_W = 250.0;
const float ENCH_TOP = 2.0;
const float ENCH_SIZE_MAX = 1.15;
// THE GOLEM'S PANEL (MagixPrison economy/MineralHud golemTitle, owner 16/11: «usa la posizione della minimap (smp) per
// tutte le info del golem»): its own boss bar title, marks blue 224 + colour (+ 16 its shadow), a board GOLEM_W pixels
// wide from the title's x 0, its lines one under the other by the marks' green; drawn in the screen's TOP RIGHT corner,
// GOLEM_RIGHT from the right edge and GOLEM_TOP from the top, at the player's panel size (never past GOLEM_SIZE_MAX).
const float GOLEM_W = 150.0;
const float GOLEM_RIGHT = 4.0;
const float GOLEM_TOP = 4.0;
const float GOLEM_SIZE_MAX = 1.15;
const vec3 HOTBAR_PALETTE[16] = vec3[16](
    vec3(1.0, 1.0, 1.0),          // 0 white
    vec3(0.604, 0.549, 0.659),    // 1 grey violet #9A8CA8
    vec3(0.635, 0.863, 0.173),    // 2 Soldi green #A2DC2C
    vec3(0.722, 0.722, 0.769),    // 3 coal #B8B8C4
    vec3(0.906, 0.518, 0.353),    // 4 copper #E7845A
    vec3(0.902, 0.839, 0.784),    // 5 iron #E6D6C8
    vec3(0.369, 0.553, 1.0),      // 6 lapis #5E8DFF
    vec3(1.0, 0.267, 0.267),      // 7 redstone #FF4444
    vec3(1.0, 0.847, 0.290),      // 8 gold #FFD84A
    vec3(0.239, 0.863, 0.518),    // 9 emerald #3DDC84
    vec3(0.373, 0.941, 0.941),    // 10 diamond #5FF0F0
    vec3(0.769, 0.580, 0.533),    // 11 netherite #C49488
    vec3(0.941, 0.486, 1.0),      // 12 magenta #F07CFF
    vec3(1.0, 0.761, 0.239),      // 13 amber #FFC23D
    vec3(0.420, 0.380, 0.460),    // 14 dark grey violet
    vec3(0.0, 0.0, 0.0));         // 15 black
#endif

#ifdef MAGIX_GUI_CODE
// --- MagixPack RUNE UNLOCKED (owner 9/11, MagixPrison's fx/RuneUnlock): a rune's card, then into its slot -------------
// «Nuova runa sbloccata»: MagixPrison sends one TITLE a tick made of TWO glyphs of the font magixprison:rune_unlock
// (tools/make_rune_unlock.py: 16 tall, ascent 8, advance 17, no shadow): the LIGHT (blue RUNE_UNLOCK_BLUE + 6 + slot)
// then the CARD (blue RUNE_UNLOCK_BLUE + slot), both red 254 + green = progress 0..255; slot = the rune's place in the
// rune panel left of the hotbar (MagixPrison MineralHud.RUNE_ORDER). (The explosion is in the WORLD, at the dug block,
// before this: owner 9/11.) The light flashes open, the card pops out of it big, spinning round its upright axis,
// holds there turning slowly with the light breathing and turning behind it, then flies along an arc into its slot of
// the left panel (the HOTBAR HUD block's left anchor), spinning and shrinking to the slot's item. The words come as the
// subtitle, plain. RUNE_UNLOCK_FLASH / _POP / _HOLD are the phases' ends (MagixPrison's fx/RuneUnlock has the same;
// fx.rune-unlock.ticks sets the whole length). One more card of a rune (no new rune, no new level: owner 9/11) is the
// QUICK flight: ONE glyph, the card marked blue RUNE_UNLOCK_BLUE + 12 + slot, popping small out of the crosshair and
// flying straight down into its slot (fx.rune-unlock.quick-ticks).
const int RUNE_UNLOCK_BLUE = 220;
const float RUNE_UNLOCK_FLASH = 0.06;
const float RUNE_UNLOCK_POP = 0.18;
const float RUNE_UNLOCK_HOLD = 0.64;
const float RUNE_UNLOCK_Y = -44.0;      // the card's middle, GUI pixels from the screen's middle (over the subtitle)
const float RUNE_UNLOCK_CARD = 30.0;    // half the card's side while it is shown
const float RUNE_UNLOCK_LIGHT = 2.6;    // the light's side over the card's
bool runeUnlockVertex(ivec3 rgb, inout vec4 labelColor) {
    if (rgb.r != 254 || rgb.b < RUNE_UNLOCK_BLUE || rgb.b > RUNE_UNLOCK_BLUE + 17) return false;
    bool quick = rgb.b >= RUNE_UNLOCK_BLUE + 12;
    bool isLight = !quick && rgb.b >= RUNE_UNLOCK_BLUE + 6;
    float slot = float(rgb.b - RUNE_UNLOCK_BLUE - (quick ? 12 : isLight ? 6 : 0));
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    // the title at scale 4 from y -10 round the middle, 34 wide from -17: the light spans x -17..-1, the card 0..16,
    // both y -1..15
    // (the quick flight's single glyph spans x -8.5..7.5)
    vec2 local = (v.xy - h) / 4.0 + vec2(0.0, 10.0) - vec2(quick ? -0.5 : isLight ? -9.0 : 8.0, 7.0);
    vec2 corner = vec2(local.x > 0.0 ? 1.0 : -1.0, local.y > 0.0 ? 1.0 : -1.0);
    int hudSz = min(rgb.g / HUD_SIZE_STEPS, 2);
    float p = clamp(float(rgb.g - hudSz * HUD_SIZE_STEPS) / float(HUD_SIZE_STEPS - 1), 0.0, 1.0);
    // the slot's item in the left panel (= the HOTBAR HUD block: right edge left of the off hand, 130 wide, slots of
    // 21 from x 1, the item 3 in, its middle 22 rows under the panel's top)
    float screenW = round(2.0 * h.x);
    float rightEdge = floor(screenW * 0.5) - 91.0 - HOTBAR_HUD_OFFHAND - HOTBAR_HUD_GAP;
    float scale = hudFit(2.0 * h.y, (rightEdge - HOTBAR_HUD_MARGIN) / HOTBAR_HUD_LEFT_W, hudSz);
    float leftEdge = rightEdge - HOTBAR_HUD_LEFT_W * scale;
    vec2 target = vec2(leftEdge + (12.0 + slot * 21.0) * scale, 2.0 * h.y - HOTBAR_HUD_UP * scale + 21.0 * scale) - h;
    vec2 centre = vec2(0.0, RUNE_UNLOCK_Y);
    vec2 pos = centre;
    float size = 0.0, spin = 0.0, alpha = 1.0, lightSize = 0.0, lightAlpha = 0.0;
    float turn = GameTime * 1200.0;
    if (quick) {
        // out of the crosshair with a hop, then straight down into the slot, spinning, shrinking to the slot's item
        vec2 start = vec2(0.0, -8.0);
        if (p < 0.2) {
            float t = p / 0.2;
            pos = mix(vec2(0.0), start, t);
            size = mix(4.0, 14.0, sin(t * 1.9));
            spin = t * 3.0;
        } else {
            float t = (p - 0.2) / 0.8;
            float e = mix(t * t * (3.0 - 2.0 * t), t * t, 0.5);
            vec2 control = vec2(mix(start.x, target.x, 0.5), start.y - 24.0);
            pos = mix(mix(start, control, e), mix(control, target, e), e);
            size = mix(13.0, 8.0 * scale, e);
            spin = 3.0 + e * 12.566;
            alpha = 1.0 - smoothstep(0.92, 1.0, t);
        }
        gl_Position = ProjMat * vec4(h + pos + vec2(corner.x * size * cos(spin), corner.y * size), v.z, v.w);
        labelColor = vec4(1.0, 1.0, 1.0, Color.a * alpha);
        return true;
    }
    if (p < RUNE_UNLOCK_FLASH) {
        // the light flashes open, bigger than it will stay
        float t = p / RUNE_UNLOCK_FLASH;
        lightSize = RUNE_UNLOCK_CARD * RUNE_UNLOCK_LIGHT * 1.5 * (1.0 - (1.0 - t) * (1.0 - t) * (1.0 - t));
        lightAlpha = smoothstep(0.0, 0.4, t);
    } else if (p < RUNE_UNLOCK_POP) {
        // out of the light, with an overshoot, spinning fast and slowing down
        float t = (p - RUNE_UNLOCK_FLASH) / (RUNE_UNLOCK_POP - RUNE_UNLOCK_FLASH);
        float u = t - 1.0;
        float back = 1.0 + 2.2 * u * u * u + 1.2 * u * u;
        size = RUNE_UNLOCK_CARD * back;
        spin = (1.0 - t) * (1.0 - t) * 18.85;
        lightSize = RUNE_UNLOCK_CARD * RUNE_UNLOCK_LIGHT * mix(1.5, 1.0, smoothstep(0.0, 1.0, t));
        lightAlpha = 1.0;
    } else if (p < RUNE_UNLOCK_HOLD) {
        // still in the middle: it turns slowly round its upright axis, breathing; the light pulses behind it
        float t = (p - RUNE_UNLOCK_POP) / (RUNE_UNLOCK_HOLD - RUNE_UNLOCK_POP);
        pos = centre + vec2(0.0, 1.5 * sin(t * 12.566));
        size = RUNE_UNLOCK_CARD * (1.0 + 0.04 * sin(t * 18.85));
        spin = t * 6.2832;
        lightSize = RUNE_UNLOCK_CARD * RUNE_UNLOCK_LIGHT * (1.0 + 0.08 * sin(t * 25.13));
        lightAlpha = 1.0;
    } else {
        // the flight: an arc down to its slot, faster and faster, turning, shrinking to the slot's item
        float t = (p - RUNE_UNLOCK_HOLD) / (1.0 - RUNE_UNLOCK_HOLD);
        float e = mix(t * t * (3.0 - 2.0 * t), t * t, 0.4);
        vec2 control = vec2(mix(centre.x, target.x, 0.15) - 40.0, centre.y - 30.0);
        pos = mix(mix(centre, control, e), mix(control, target, e), e);
        size = mix(RUNE_UNLOCK_CARD, 8.0 * scale, e);
        spin = e * 12.566;
        alpha = 1.0 - smoothstep(0.93, 1.0, t);
        lightSize = size * RUNE_UNLOCK_LIGHT;
        lightAlpha = 1.0 - smoothstep(0.0, 0.7, t);
    }
    vec2 c;
    if (isLight) {
        // the light turns in the screen's plane, slowly
        float a = turn * 0.6;
        vec2 k = corner * lightSize;
        c = vec2(k.x * cos(a) - k.y * sin(a), k.x * sin(a) + k.y * cos(a));
        alpha *= lightAlpha;
    } else {
        // the card turns round its upright axis: its width follows the cosine (its back is the mirrored front)
        c = vec2(corner.x * size * cos(spin), corner.y * size);
    }
    gl_Position = ProjMat * vec4(h + pos + c, v.z, v.w);
    labelColor = vec4(1.0, 1.0, 1.0, Color.a * alpha);
    return true;
}
#endif

#ifdef MAGIX_GUI_CODE
// --- MagixPack CANVAS GLOW (owner 19/11: «si illumina il bordo del tasto selezionato») --------------------------------
// The Prison's full-screen menus are CANVAS dialogs of MagixMenus (tools/prison_canvas.py): a grid of the client's own
// buttons, CANVAS_PITCH apart, each covered by a slice of one picture. The client never says which button the mouse is
// on, but it draws that button's TOOLTIP: every tooltip ends with ONE glyph of magixpack:portal_guide (and the space
// that takes its advance back) coloured red CANVAS_GLOW_RED, green = first column (bits 0-2) + columns - 1 (bits 3-5)
// + tint (bits 6-7), blue = first row (bits 0-3) + rows - 1 (bits 4-7): the cells of the CARD that button belongs to.
// Here the glyph leaves the tooltip: its quad (corner read from its texture, guideCorner()) becomes that card's box
// (its cells less CANVAS_INSET, as prison_canvas.py draws every card) plus CANVAS_GLOW_PAD, and canvasGlow() of
// text.fsh draws a lit edge with a light running round it (hudMode 18). Where the grid is on the screen is the
// client's own layout (DialogScreen, HeaderAndFooterLayout of 26.3): centred, its top at 63 or as low as the screen
// lets it; CANVAS_ROWS is the same for every canvas.
const int CANVAS_GLOW_RED = 243;
// THE SIZES OF A CANVAS (owner 20/11, prison_canvas.py Geo, MagixMenus screen/ScreenSizes): the same screen 352 x 180
// (size 0, every window), x 1.5, x 2 and x 3. The lit edge's mark is red 243 - size (its blue's low four bits, the
// first row, are 8 at most: a FIT mark, blue 77, is never taken for one); each size has its own grid and body.
const float CANVAS_COLUMNS = 8.0;
const float CANVAS_ROWS = 9.0;
const float CANVAS_GLOW_PAD = 9.0;
// 1.21.6-1.21.10 (MAGIX_MC 216, owner's screenshot 22/11 at GUI scale 3: the lit edge 4 screen pixels right of the
// card and 12 under it) draw the board without that shift and 4 GUI pixels higher than 26.3's layout
#ifdef MAGIX_MC
#if MAGIX_MC == 216
#define MAGIX_CANVAS_OLD_LAYOUT
#endif
#endif
#ifdef MAGIX_CANVAS_OLD_LAYOUT
const vec2 CANVAS_GLOW_SHIFT = vec2(0.0, -4.0);
#else
// 3.5 SCREEN pixels, whatever the GUI scale (measured at GUI scale 3 as 4 / 3 of a GUI pixel; a player at GUI scale 4,
// 23/11: «sembra un pixel ancora spostato a destra»: 4 / 3 there is 5.3 screen pixels). NOT THE CLIENT'S LAYOUT: 26.2's
// code (javap, 23/11) puts the board exactly at boardX in whole GUI pixels (ScrollableLayout reserve 10, padding 4, every
// line centred: X + width / 2 - line / 2, reach cancels on an even board, bitmap glyphs with no left bearing); the shift
// is measured on screenshots only. 4 -> 3.5 on 23/11 (owner's crops: a lit tile 3 screen pixels clear on its left and 4
// on its right, «sulla parte destra c'è un pixel nero tipo un ombra»: the card's dark outline showing on the right)
vec2 canvasGlowShiftOf() {
    float shiftGuiH = ceil(abs(2.0 / ProjMat[1][1]) - 0.01);
    return vec2(3.5 / max(1.0, ScreenSize.y / max(shiftGuiH, 1.0)), 0.0);
}
#define CANVAS_GLOW_SHIFT canvasGlowShiftOf()
#endif
// a button INSIDE a card (= prison_canvas.INNER, left top right bottom): on its card's last row, first row, as tall as it
vec4 canvasInnerInset(int a) { return a == 17 ? vec4(3.0, -1.0, 3.0, 3.0) : a == 18 ? vec4(3.0, 3.0, 3.0, -1.0) : a == 19 ? vec4(3.0) : vec4(0.0); }
// = Geo of tools/prison_canvas.py: pitch, margin (the TOP one), the board's width, the body's lines, the scale
vec2 canvasPitch(int s) { return s == 3 ? vec2(123.0, 54.0) : s == 2 ? vec2(82.0, 36.0) : s == 1 ? vec2(63.0, 27.0) : vec2(42.0, 18.0); }
vec2 canvasMargin(int s) { return s == 3 ? vec2(15.0, 39.0) : s == 2 ? vec2(18.0, 26.0) : s == 1 ? vec2(12.0, 18.0) : vec2(8.0, 12.0); }
float canvasBoardW(int s) { return s == 3 ? 1014.0 : s == 2 ? 692.0 : s == 1 ? 528.0 : 352.0; }
float canvasLines(int s) { return s == 3 ? 60.0 : s == 2 ? 40.0 : s == 1 ? 30.0 : 20.0; }
float canvasScale(int s) { return s == 3 ? 3.0 : s == 2 ? 2.0 : s == 1 ? 1.5 : 1.0; }
// THE CLIENT'S LAYOUT (MagixMenus 0.9.58: an empty dialog list, so a footer of 5, not 33): header 33, the content (the
// body widget, its lines x 9 + 2 x 4 of padding, + 10 of spacing + the empty button grid) placed at
// min(33 + 30, H - 5 - content); the scroll area (widget = board + 8 + MagixMenus' CANVAS_SLACK 2, + 2 x 10) centred
// while it fits the screen. A board that does not fit SCROLLS (or is pinned left): the shader cannot know by how much.
float canvasContentH(int s) { return canvasLines(s) * 9.0 + 8.0 + 10.0; }
// THE CAROUSEL'S SIDES (owner 23/11, MagixMenus canvas-sides, tools/prison_canvas.py SIDES): the body is this much wider at
// each side of the board, where the turned menus and the arrows are; the fit counts them for every canvas (the main screen
// has them, the chooser speaks for all), the board's place does not move (its lines stay centred in the wider widget)
float canvasSides(int s) { return s == 1 ? 35.0 : 17.0; }   // = prison_canvas SIDES (since 23/11: the faces' own width)
float canvasWidgetW(int s) { return canvasBoardW(s) + 10.0 + 2.0 * canvasSides(s); }
bool canvasFits(int s, vec2 gui) { return gui.y - 33.0 - 5.0 >= canvasContentH(s) && gui.x >= canvasWidgetW(s) + 20.0; }
// What the chooser (screen_fit) TELLS the player (owner 20/11: on 1920x1080 windowed at GUI scale 3 the size it
// recommended filled the window and scrolled): «fits» keeps CANVAS_FIT_SAFE GUI pixels to spare (a window's real
// height is a few pixels off what anyone guesses), and the RECOMMENDED size is the biggest that fills at most
// CANVAS_COMFORT of the window each way: a menu with room round it, never one wall to wall.
const float CANVAS_FIT_SAFE = 10.0;
const float CANVAS_COMFORT = 0.8;
bool canvasFitsSafe(int s, vec2 gui) { return canvasFits(s, gui - CANVAS_FIT_SAFE); }
bool canvasComfy(int s, vec2 gui) {
    return canvasContentH(s) + 38.0 <= CANVAS_COMFORT * gui.y && canvasWidgetW(s) + 20.0 <= CANVAS_COMFORT * gui.x;
}
// only sizes 0 and 1 exist since 21/11 (owner: «togli enorme e grande. per sempre»): never recommend x 2 or x 3
int canvasBestSize(vec2 gui) { return canvasComfy(1, gui) ? 1 : 0; }
bool canvasGlowVertex(ivec3 rgb) {
    if (rgb.r > CANVAS_GLOW_RED || rgb.r < CANVAS_GLOW_RED - 3 || (rgb.b & 15) > 8) return false;
    // THE SHAPED LIGHT (owner 23/11, the glass carousel; MagixMenus glow inner 8): its size's red 2 lower (241 Piccolo, 240
    // Grande, free since the sizes x 2 and x 3 went): a light from behind starting at the card's round edge (text.fsh)
    bool shapedStyle = rgb.r <= CANVAS_GLOW_RED - 2;
    int size = shapedStyle ? CANVAS_GLOW_RED - 2 - rgb.r : CANVAS_GLOW_RED - rgb.r;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 gui = vec2(round(abs(2.0 / ProjMat[0][0])), ceil(abs(2.0 / ProjMat[1][1]) - 0.01));
    vec2 corner = guideCorner();
    vec2 first = vec2(float(rgb.g & 7), float(rgb.b & 15));
    // rows written 9..11 = a ROW of a panel, (rows - 8) tall (MagixMenus glow kind 4, owner 21/11): lit as a fill;
    // 12..14 = a filled BUTTON, (rows - 11) tall (kind 5): its edge lit, its face lighter
    int rowsField = (rgb.b >> 4) & 15;
    // 15 = an AURA, 3 rows tall (kind 6, owner 22/11): no edge, a light from behind the round picture in the cells
    bool auraStyle = rowsField == 15;
    bool buttonStyle = rowsField >= 12 && !auraStyle;
    bool rowStyle = rowsField >= 9 && !buttonStyle;
    vec2 count = vec2(float((rgb.g >> 3) & 7) + 1.0, auraStyle ? 3.0 : buttonStyle ? float(rowsField - 11) : rowStyle ? float(rowsField - 8)
                      : float(rowsField) + 1.0);
    vec2 pitch = canvasPitch(size);
    float k = canvasScale(size);
    float boardW = canvasBoardW(size);
    float contentH = canvasContentH(size);
    float widgetW = canvasWidgetW(size);
    float areaW = widgetW + 20.0;
    // a board that only just fits may still scroll a few pixels when clicked (owner 20/11: the lit edge came out
    // shifted): the lit edge needs the chooser's safety margin too, else it is not drawn (the screen offers «Adatta»)
    if (!canvasFitsSafe(size, gui)) {
        hudMode = 0;
        gl_Position = vec4(-4.0, -4.0, 0.0, 1.0);
        return true;
    }
    float widgetX = floor((gui.x - areaW) * 0.5) + 10.0;
    float boardX = widgetX + floor(widgetW * 0.5) - floor(boardW * 0.5);
    vec2 origin = vec2(boardX, min(63.0, gui.y - 5.0 - contentH) + 4.0) + canvasMargin(size);
    // measured in game (owner 20/11, Medio at GUI scale 3, the same at every size): the client draws the board
    // 4 screen pixels right of where the layout says (owner: not under it); the lit edge follows it
    origin += CANVAS_GLOW_SHIFT;
    vec2 lo = origin + first * pitch + k;
    vec2 hi = origin + (first + count) * pitch - 3.0 * k;   // = cell_rect (2 + INSET) drawn at the size
    // an INNER button's mark (magixpack:canvas_tip from U+E800, its middle texel's alpha 17): its edge sits
    // canvasInnerInset inside its cells, as prison_canvas draws a button inside a card (owner 20/11)
    ivec4 tipData = ivec4(round(texelFetch(Sampler0, ivec2(floor(UV0 * vec2(textureSize(Sampler0, 0)) - corner * 1.5)), 0) * 255.0));
    vec4 inner = tipData.b == 78 ? canvasInnerInset(tipData.a) * k : vec4(0.0);
    lo += inner.xy;
    hi -= inner.zw;
    vec2 ext = (hi - lo) * 0.5;
    hudMode = 18;
    hudPos = corner * (ext + CANVAS_GLOW_PAD);   // the halo as wide at every size (owner 20/11)
    // z: tint + 4 x the size, + 16 for a button INSIDE a card (a secondary one: its lit edge thin, owner 20/11)
    hudData = vec4(ext, float(rgb.g >> 6) + 4.0 * float(size) + (inner.x > 0.0 ? 16.0 : 0.0) + (rowStyle ? 32.0 : 0.0) + (buttonStyle ? 64.0 : 0.0) + (auraStyle ? 128.0 : 0.0) + (shapedStyle ? 256.0 : 0.0),
                   GameTime * 1200.0);
    // the tooltip's box (owner 20/11: the lit edge is never drawn over the tooltip): a mark of magixpack:canvas_tip
    // stands at the tooltip's start, 8 GUI pixels tall like a letter, and its middle texel says the widest line / 4
    // (red) and the lines (green) (tools/make_canvas_tip_font.py); the tooltip's text starts at its top left, the
    // client's lines are 10 apart, 2 more under the first, the frame round it ~4
    hudBox = vec4(0.0);
    if (tipData.b == 78 && tipData.a >= 16 && tipData.a <= 19) {
        vec2 tipStart = v.xy - (corner + 1.0) * 4.0;
        float tipLines = float(tipData.g);
        vec2 tipMax = tipStart + vec2(float(tipData.r) * 4.0, tipLines * 10.0 + (tipLines > 1.5 ? 2.0 : 0.0) - 1.0);
        hudBox = vec4(tipStart - 5.0, tipMax + 5.0) - vec4((lo + hi) * 0.5, (lo + hi) * 0.5);
    }
    gl_Position = ProjMat * vec4((lo + hi) * 0.5 + hudPos, v.z, v.w);
    return true;
}
// THE SHAPED PICTURE LIGHT (owner 23/11, the island's map: «la glow deve essere limitata alla forma del pezzo di isola»):
// a glyph of the screen's own font at the START of a land's tooltip, red 237 (Piccolo) / 236 (Grande), green = the
// tooltip's widest line / 4, blue = its lines. Its square texture is the land's light over the cells it covers; the
// texel next to each corner's guide (inward along x, blue 76) says those cells: red = first column | first row << 3,
// green = columns - 1 | (rows - 1) << 3. The quad is moved over those cells (as canvasGlowVertex), the fragment draws
// the texture, never over the tooltip (text.fsh hudMode 24). MagixMenus button `glow-picture` (prison_canvas area light=).
const int CANVAS_PICTURE_RED = 237;
bool canvasPictureVertex(ivec3 rgb) {
    if (rgb.r != CANVAS_PICTURE_RED && rgb.r != CANVAS_PICTURE_RED - 1) return false;
    vec2 corner = guideCorner();
    if (corner == vec2(0.0)) return false;
    int size = CANVAS_PICTURE_RED - rgb.r;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 gui = vec2(round(abs(2.0 / ProjMat[0][0])), ceil(abs(2.0 / ProjMat[1][1]) - 0.01));
    vec2 at = UV0 * vec2(textureSize(Sampler0, 0));
    ivec4 d = ivec4(round(texelFetch(Sampler0, ivec2(floor(at - corner * 0.5 + vec2(-corner.x, 0.0))), 0) * 255.0));
    if (d.b != 76 || !canvasFitsSafe(size, gui)) {
        hudMode = 0;
        gl_Position = vec4(-4.0, -4.0, 0.0, 1.0);
        return true;
    }
    // bit 7 of red: the first column is -1 (a side of the carousel), of green: the first row is -1 (the frame's top edge)
    vec2 first = vec2((d.r & 128) != 0 ? -1.0 : float(d.r & 7), (d.g & 128) != 0 ? -1.0 : float((d.r >> 3) & 15));
    vec2 count = vec2(float(d.g & 7) + 1.0, float((d.g >> 3) & 15) + 1.0);
    vec2 pitch = canvasPitch(size);
    float k = canvasScale(size);
    float widgetW = canvasWidgetW(size);
    float areaW = widgetW + 20.0;
    float widgetX = floor((gui.x - areaW) * 0.5) + 10.0;
    float boardX = widgetX + floor(widgetW * 0.5) - floor(canvasBoardW(size) * 0.5);
    vec2 origin = vec2(boardX, min(63.0, gui.y - 5.0 - canvasContentH(size)) + 4.0) + canvasMargin(size) + CANVAS_GLOW_SHIFT;
    vec2 lo = origin + first * pitch;
    vec2 hi = origin + (first + count) * pitch - 2.0 * k;
    // THE LIGHT'S OWN BOX (owner 23/11: «quello verde è poco dettagliato», Soldi and Magix): the picture covers only its
    // light, not its whole cells (a pill 36 wide had 3 columns, 1.5 texels a pixel): two more texels inward from each
    // corner's guide say how far it starts inside the cells, in quarters of a GUI pixel of this size (prison_canvas
    // _light_glyph): blue 75 red = left, green = right; blue 74 red = top, green = bottom
    ivec4 insX = ivec4(round(texelFetch(Sampler0, ivec2(floor(at - corner * 0.5 + vec2(-2.0 * corner.x, 0.0))), 0) * 255.0));
    ivec4 insY = ivec4(round(texelFetch(Sampler0, ivec2(floor(at - corner * 0.5 + vec2(-3.0 * corner.x, 0.0))), 0) * 255.0));
    if (insX.b == 75 && insY.b == 74) {
        lo += vec2(float(insX.r), float(insY.r)) * 0.25;
        hi -= vec2(float(insX.g), float(insY.g)) * 0.25;
    }
    vec2 ext = (hi - lo) * 0.5;
    hudMode = 24;
    hudPos = corner * ext;
    hudData = vec4(ext, 0.0, GameTime * 1200.0);
    vec2 tipStart = v.xy - (corner + 1.0) * 4.0;
    float tipLines = float(rgb.b);
    vec2 tipMax = tipStart + vec2(float(rgb.g) * 4.0, tipLines * 10.0 + (tipLines > 1.5 ? 2.0 : 0.0) - 1.0);
    hudBox = vec4(tipStart - 5.0, tipMax + 5.0) - vec4((lo + hi) * 0.5, (lo + hi) * 0.5);
    vertexColor = vec4(1.0);
    gl_Position = ProjMat * vec4((lo + hi) * 0.5 + hudPos, v.z, v.w);
    return true;
}
// THE FIT MARK (prison_canvas fit_colour): words and pictures seen only by some windows, red 240 + green 64 x size +
// 16 x mode + blue 77 (their shadows red 60 + green / 4 + blue 19); mode 0 = that size takes the window, 1 = it does
// not, 2 = it is the biggest the window takes. Seen: drawn white (the shadow at a quarter); else not at all.
const int CANVAS_FIT_RED = 240;
const int CANVAS_FIT_BLUE = 77;
// the mark's green (-1: none) and whether it is a shadow
ivec2 canvasFitMark(ivec3 rgb) {
    if (rgb.r == CANVAS_FIT_RED && rgb.b == CANVAS_FIT_BLUE && rgb.g % 16 == 0 && (rgb.g % 64) / 16 <= 2) return ivec2(rgb.g, 0);
    if (rgb.r == CANVAS_FIT_RED / 4 && rgb.b == CANVAS_FIT_BLUE / 4 && rgb.g % 4 == 0 && (rgb.g % 16) / 4 <= 2) return ivec2(rgb.g * 4, 1);
    return ivec2(-1, 0);
}
bool canvasFitHolds(int green, vec2 gui) {
    int size = green / 64, mode = (green % 64) / 16;
    return mode == 0 ? canvasFitsSafe(size, gui) : mode == 1 ? !canvasFitsSafe(size, gui) : canvasBestSize(gui) == size;
}
// --- MagixPack CANVAS UNDERLINE (owner 20/11: «rendi cliccabile soldi, che si sottolinea col mouse sopra») ---------------
// WORDS of a canvas that are a button of their own (MagixMenus canvas text `actions`) carry at their tooltip's start a
// mark of magixpack:canvas_tip from U+E4C0 (its middle texel's alpha 20, blue 78; tools/make_canvas_tip_font.py),
// coloured red = the size's lit-edge red (CANVAS_GLOW_RED - size), green + blue's low 2 bits = the words' left, blue's
// high 6 bits = the low bits of their top; the texel says half their width (red) and the high bits of their top (green
// / 16): GUI pixels from the grid's top left corner at that size (MagixMenus DialogManager#lineMark). Here the mark
// leaves the tooltip and becomes the line under the words, where the game draws an underline (y + 8, x - 1 .. x + w);
// canvasLine() of text.fsh draws it (hudMode 20).
bool canvasLineVertex(ivec3 rgb) {
    if (rgb.r > CANVAS_GLOW_RED || rgb.r < CANVAS_GLOW_RED - 3 || canvasFitMark(rgb).x >= 0) return false;
    vec2 corner = guideCorner();
    ivec4 d = ivec4(round(texelFetch(Sampler0, ivec2(floor(UV0 * vec2(textureSize(Sampler0, 0)) - corner * 1.5)), 0) * 255.0));
    if (d.b != 78 || d.a != 20) return false;
    int size = CANVAS_GLOW_RED - rgb.r;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 gui = vec2(round(abs(2.0 / ProjMat[0][0])), ceil(abs(2.0 / ProjMat[1][1]) - 0.01));
    if (!canvasFitsSafe(size, gui)) {   // a board that may scroll: no line at a guessed place (as the lit edge)
        hudMode = 0;
        gl_Position = vec4(-4.0, -4.0, 0.0, 1.0);
        return true;
    }
    float widgetW = canvasWidgetW(size);
    float widgetX = floor((gui.x - widgetW - 20.0) * 0.5) + 10.0;
    float boardX = widgetX + floor(widgetW * 0.5) - floor(canvasBoardW(size) * 0.5);
    vec2 origin = vec2(boardX, min(63.0, gui.y - 5.0 - canvasContentH(size)) + 4.0) + canvasMargin(size) + CANVAS_GLOW_SHIFT;
    float left = float(rgb.g | ((rgb.b & 3) << 8));
    float top = float((rgb.b >> 2) | ((d.g >> 4) << 6)) - 32.0;   // = MagixMenus LINE_TOP_BIAS (words over the grid)
    float w = float(d.r) * 2.0;
    vec2 ext = vec2((w + 1.0) * 0.5, 0.5);
    vec2 centre = origin + vec2(left - 1.0, top + 8.0) + ext;
    hudMode = 20;
    hudPos = corner * (ext + 2.0);      // room round it for its soft glow
    hudData = vec4(ext, float(size), GameTime * 1200.0);
    // never over the TOOLTIP (owner 20/11: «la sottolineatura va nel tooltip»): the mark stands at the tooltip's start (8
    // GUI pixels tall like a letter), the tooltip grows right and down from there; its size is not in this mark, so a
    // generous box (360 x 72, its frame 5 round) is left out
    vec2 tipStart = v.xy - (corner + 1.0) * 4.0;
    hudBox = vec4(tipStart - 5.0, tipStart + vec2(360.0, 72.0)) - vec4(centre, centre);
    gl_Position = ProjMat * vec4(centre + hudPos, v.z, v.w);
    return true;
}
#endif
#ifdef MAGIX_GUI_CODE
// --- MagixPack SKILL RING (owner 10/11, MagixPrison's fx/MiningCombo): the SKILL charge as a ring round the crosshair ----
// «il cerchio nei pressi del crosshair fallo a percentuale che si colora in senso orario». MagixPrison's SKILL boss bar
// has as its title ONE glyph of magixpack:portal_guide coloured red 254 + blue SKILL_RING_BLUE + the rune (0 = the base
// skill, 1..6 = fire water earth storm sun abyss) + green = the charge (0..250, 255 = ready). Here that glyph leaves the
// boss bar's line: its quad (corner read from its texture, guideCorner()) becomes a square SKILL_RING_HALF GUI pixels
// round the crosshair, and skillRing() of text.fsh draws the ring filling clockwise from the top (hudMode 14).
const int SKILL_RING_BLUE = 240;
const float SKILL_RING_HALF = 20.0;
bool skillRingVertex(ivec3 rgb) {
    if (rgb.r != 254 || rgb.b < SKILL_RING_BLUE || rgb.b > SKILL_RING_BLUE + 6) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 corner = guideCorner();
    hudMode = 14;
    hudPos = corner * SKILL_RING_HALF;
    hudData = vec4(float(rgb.b - SKILL_RING_BLUE), float(rgb.g), GameTime * 1200.0, 0.0);
    gl_Position = ProjMat * vec4(h + corner * SKILL_RING_HALF, v.z, v.w);
    return true;
}
#endif

#ifdef MAGIX_GUI_CODE
// --- MagixPack TWIN CROSSHAIR (owner 20/11, MagixPrison's pickaxe/TwinPickaxe): the twin pickaxe digs the row on the
// player's left, «voglio il secondo mirino». MagixPrison's crosshair boss bar has as its title ONE glyph of
// magixpack:portal_guide coloured red 254 + blue TWIN_CROSS_BLUE (green 0, unused). Here
// that glyph leaves the boss bar's line: its quad becomes a square TWIN_CROSS_HALF GUI pixels round a point left of the
// game's crosshair, FIXED on the screen (the server does not know the player's field of view): TWIN_CROSS_SHIFT half
// screen heights, where the block left of the one aimed at falls three blocks away with the default FOV 70.
// twinCross() of text.fsh draws a plain crosshair (hudMode 19).
const int TWIN_CROSS_BLUE = 247;
const float TWIN_CROSS_HALF = 9.0;
const float TWIN_CROSS_SHIFT = 0.475;
bool twinCrossVertex(ivec3 rgb) {
    if (rgb.r != 254 || rgb.b != TWIN_CROSS_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 corner = guideCorner();
    hudMode = 19;
    hudPos = corner * TWIN_CROSS_HALF;
    hudData = vec4(float(rgb.g), 0.0, GameTime * 1200.0, 0.0);
    vec2 centre = vec2(floor(h.x - TWIN_CROSS_SHIFT * h.y) + 0.5, floor(h.y) + 0.5);
    gl_Position = ProjMat * vec4(centre + corner * TWIN_CROSS_HALF, v.z, v.w);
    return true;
}
#endif

#ifdef MAGIX_GUI_CODE
// --- MagixPack ROPE GAUGE (owner 14/11, MagixPrison's mine/MineGuide): while a player climbs the grappling hook's rope
// «un indicatore di livello con una freccia per far capire a che altezza sei, al centro schermo, con shaders». A
// see-through boss bar's title is ONE glyph of magixpack:portal_guide coloured red 254 + blue ROPE_GAUGE_BLUE + green =
// how far up he is (0 = where he threw the hook, 255 = the surface). The glyph leaves the boss bar's line: its quad
// becomes an upright box ROPE_GAUGE_HALF GUI pixels round a point ROPE_GAUGE_X right of the crosshair, and ropeGauge()
// of text.fsh draws the column from rock to surface, its filling and the arrow at his height (hudMode 16).
const int ROPE_GAUGE_BLUE = 250;
const vec2 ROPE_GAUGE_HALF = vec2(18.0, 58.0);
const float ROPE_GAUGE_X = 30.0;
bool ropeGaugeVertex(ivec3 rgb) {
    if (rgb.r != 254 || rgb.b != ROPE_GAUGE_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 corner = guideCorner();
    hudMode = 16;
    hudPos = corner * ROPE_GAUGE_HALF;
    hudData = vec4(float(rgb.g) / 255.0, GameTime * 1200.0, 0.0, 0.0);
    gl_Position = ProjMat * vec4(h + vec2(ROPE_GAUGE_X, 0.0) + corner * ROPE_GAUGE_HALF, v.z, v.w);
    return true;
}
#endif

#ifdef MAGIX_GUI_CODE
// --- MagixPack FOREST SCREEN (owner 11/11, MagixPrison's forest/ForestLife: «effetti con shaders, non solo particelle»).
// While a player is inside the Bosco Magico a see-through boss bar's title is ONE glyph of magixpack:portal_guide coloured
// red 254 + blue FOREST_SCREEN_BLUE + green = the strength (0..255, it fades in and out): the glyph is stretched over the
// whole screen and forestScreen() of text.fsh draws a violet vignette, an aurora waving across the top and motes of light
// drifting up (hudMode 15). Nothing at the screen's middle: the player sees through it.
const int FOREST_SCREEN_BLUE = 248;
bool forestScreenVertex(ivec3 rgb) {
    if (rgb.r != 254 || rgb.b != FOREST_SCREEN_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 corner = guideCorner();
    hudMode = 15;
    hudPos = corner * h;
    hudData = vec4(h, GameTime * 1200.0, float(rgb.g) / 255.0);
    gl_Position = ProjMat * vec4(h + corner * h, v.z, v.w);
    return true;
}
#endif

#ifdef MAGIX_GUI_CODE
// --- MagixPack MINE TREMOR (owner 14/11, MagixPrison's island/MineLife: the mountain settling must never look like a
// blow taken; until then it was the game's hurt tilt). A see-through boss bar's title is ONE glyph of
// magixpack:portal_guide coloured red 254 + blue TREMOR_SCREEN_BLUE + green = the strength (0..255, it swells and dies
// away): stretched over the whole screen, tremorScreen() of text.fsh draws a veil of dust shaking, grit falling from the
// top and the edges darkening at every jolt (hudMode 17). The middle stays clear.
const int TREMOR_SCREEN_BLUE = 249;
bool tremorScreenVertex(ivec3 rgb) {
    if (rgb.r != 254 || rgb.b != TREMOR_SCREEN_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 corner = guideCorner();
    hudMode = 17;
    hudPos = corner * h;
    hudData = vec4(h, GameTime * 1200.0, float(rgb.g) / 255.0);
    gl_Position = ProjMat * vec4(h + corner * h, v.z, v.w);
    return true;
}
#endif

#ifdef MAGIX_GUI_CODE
// MagixPrison's CARRY BAR (mine/CarryHud, owner 9/11): an action bar whose every piece (the plate and card glyphs of
// magixprison:placed_carry_hud, the words) is coloured red CARRY_RED + green 16 x palette index + blue 255; its words'
// shadows come as red 61, green 4 x index, blue 63. Only round the action bar's place (CARRY_BAND over the screen's
// bottom, CARRY_HALF_W from its middle): lifted CARRY_LIFT GUI pixels and coloured from CARRY_PALETTE.
const int CARRY_RED = 245;
const float CARRY_LIFT = 14.0;
const vec2 CARRY_BAND = vec2(96.0, 40.0);
const float CARRY_HALF_W = 220.0;
// Since 10/11 (owner: the Mana's «+N» in the action bar replaced the carry bar) the bar is the title of its own
// see-through boss bar: a piece within CARRY_BOSS_BAND of the screen's top leaves its boss bar line (text row at
// 3 + 19 x line; the whole bar spans -5..+13 of it, tools/make_prison_carry_hud.py) and its text row goes
// CARRY_BOSS_TOP GUI pixels over the screen's bottom: above the action bar, its second line too, always there.
const float CARRY_BOSS_BAND = 200.0;
const float CARRY_BOSS_TOP = 103.0;
// index + 8 = the same colour on the SECOND line, CARRY_SECOND_DROP pixels under the first (owner 9/11: «se muori le
// perdi» on a line of its own, under the plate)
const float CARRY_SECOND_DROP = 17.0;
const vec3 CARRY_PALETTE[6] = vec3[6](vec3(1.0), vec3(1.0), vec3(0.851, 0.659, 1.0), vec3(1.0, 0.55, 0.30),
        vec3(0.86, 0.85, 0.90), vec3(1.0, 0.45, 0.45));
#endif

// THE CAROUSEL'S TURN (MagixMenus DialogManager#veil, see the block in main()): how far apart the codes of x are, how long
// the turn lasts (ticks: 8 = 0.4 s), how far the face turns, the ring's radius and the eye's distance (x the board's
// width: the face ends at the board's side, about as wide as a turned menu), how dark it ends (= the side menus' 42%)
const float TURN_FAR = 1024.0;
const float TURN_TICKS = 8.0;
const float TURN_ANGLE = 1.396;   // 80 degrees
const float TURN_RING = 0.79;
const float TURN_EYE = 1.5;
const float TURN_DARK = 0.42;
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#ifdef MAGIX_GUI_CODE
    hudMode = 0;
    hudPos = vec2(0.0);
    hudData = vec4(0.0);
    vec4 hudLabelColor = vec4(-1.0);
    ivec3 hudRgb = ivec3(round(Color.rgb * 255.0));
    if (hudRgb.r == 254 && hudRgb.b >= 5 && hudRgb.b <= 17 && hudRgb.b != 10) {
        vec4 hudVert = ModelViewMat * vec4(Position, 1.0);
        vec2 hudHalf = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
        vec2 hudCorner = vec2(hudVert.x > hudHalf.x ? 1.0 : -1.0, hudVert.y > hudHalf.y ? 1.0 : -1.0);
        if (hudRgb.b >= 11) {
            // MagixPack AFK screen (see AFK_LINE1_SCALE).
            if (hudRgb.b == 11) {
                vec2 afkCorner = guideCorner();
                hudMode = 6;
                hudPos = afkCorner * hudHalf;
                hudData = vec4(hudHalf, GameTime * 1200.0, 0.0);
                gl_Position = ProjMat * vec4(hudHalf + afkCorner * hudHalf, hudVert.z, hudVert.w);
            } else {
                int afkLine = (hudRgb.b - 12) / 2;
                bool afkShadow = (hudRgb.b - 12) % 2 == 1;
                vec2 afkLocal = hudVert.xy - hudHalf;
                vec2 afkAt;
                if (afkLine == 0) {
                    afkAt = (afkLocal / 4.0 + vec2(0.0, 10.0)) * AFK_LINE1_SCALE + vec2(0.0, AFK_LINE1_TOP);
                } else {
                    vec2 afkU = afkLocal / 2.0 - vec2(0.0, 5.0);
                    afkU.x += afkLine == 1 ? float(hudRgb.g) : -float(hudRgb.g);
                    afkAt = afkLine == 1 ? afkU * AFK_LINE2_SCALE + vec2(0.0, AFK_LINE2_TOP)
                            : afkU + vec2(0.0, AFK_LINE3_TOP);
                }
                gl_Position = ProjMat * vec4(hudHalf + afkAt, hudVert.z, hudVert.w);
                vec4 afkFill = afkLine == 0 ? AFK_LINE1_FILL : afkLine == 1 ? AFK_LINE2_FILL : AFK_LINE3_FILL;
                hudLabelColor = vec4((afkShadow ? AFK_SHADOW : afkFill).rgb, Color.a);
            }
        } else if (hudRgb.b == 7) {
            // the shield bar: a thin bar under the crosshair, hudPos -1..1 across it
            hudMode = 4;
            hudPos = hudCorner;
            hudData = vec4(SHIELD_BAR_HALF, float(hudRgb.g), 0.0);
            gl_Position = ProjMat * vec4(hudHalf + vec2(0.0, SHIELD_BAR_Y) + hudCorner * SHIELD_BAR_HALF, hudVert.z, hudVert.w);
        } else if (hudRgb.b >= 8) {
            // its words (the subtitle, drawn at scale 2 from y 5 to 13): scale 1, centred just over the bar
            vec2 hudLocal = (hudVert.xy - hudHalf) * 0.5 - vec2(0.0, 9.0);
            vec2 hudAt = hudHalf + hudLocal + vec2(0.0, SHIELD_BAR_Y - SHIELD_BAR_HALF.y - 6.5);
            gl_Position = ProjMat * vec4(hudAt, hudVert.z, hudVert.w);
            hudLabelColor = vec4((hudRgb.b == 8 ? SHIELD_LABEL_FILL : SHIELD_LABEL_SHADOW).rgb, Color.a);
        } else {
            hudMode = 3;
            hudPos = hudCorner * hudHalf;
            hudData = vec4(hudHalf, float(hudRgb.g), hudRgb.b == 6 ? 1.0 : 0.0);
            gl_Position = ProjMat * vec4(hudHalf + hudCorner * hudHalf, hudVert.z, hudVert.w);
        }
    }
    // MagixPack mana flight (see MANA_FLIGHT_BLUE), else the newcomers' film (see CINE_BARS_BLUE).
    // the twin crosshair (TWIN_CROSS_BLUE) first: cinemaVertex takes every blue from CINE_BARS_BLUE up (MagixPack 0.42.88
    // called it apart, and the film's pointer moved it off the screen)
    if (!twinCrossVertex(hudRgb) && !manaFlightVertex(hudRgb, hudLabelColor) && !mineralFlightVertex(hudRgb, hudLabelColor)
            && !runeUnlockVertex(hudRgb, hudLabelColor) && !skillRingVertex(hudRgb) && !forestScreenVertex(hudRgb)
            && !ropeGaugeVertex(hudRgb) && !tremorScreenVertex(hudRgb) && !canvasLineVertex(hudRgb) && !canvasPictureVertex(hudRgb) && !canvasGlowVertex(hudRgb))
            cinemaVertex(hudRgb, hudLabelColor);
#endif

#ifdef MAGIX_GUI_CODE
    // MagixPack hotbar HUD (see HOTBAR_HUD_RED).
    vec4 hotbarColor = vec4(-1.0);
    {
        ivec3 hotbarRgb = ivec3(round(Color.rgb * 255.0));
        int hotbarSize = hudSizeOf(hotbarRgb.r);
        if (hotbarSize >= 0 && hotbarRgb.b >= 32) {
            vec4 hotbarVert = ModelViewMat * vec4(Position, 1.0);
            float hotbarScreenW = round(abs(2.0 / ProjMat[0][0]));
            float hotbarScreenH = abs(2.0 / ProjMat[1][1]);
            float hotbarLeft = floor(hotbarScreenW * 0.5) - HOTBAR_HUD_WIDTH * 0.5;
            if (hotbarVert.x >= hotbarLeft - HOTBAR_HUD_SLACK && hotbarVert.x <= hotbarLeft + HOTBAR_HUD_WIDTH + HOTBAR_HUD_SLACK
                    && hotbarVert.y < HOTBAR_HUD_BAND) {
                float hotbarLine = floor((hotbarVert.y + 0.5) / 19.0) * 19.0;   // 3 over the line's text (+0.5: a top on the line, 7/11)
                // green 0..159 = rows from the panel's top; 160..191 = rows OVER it (green - 192: -32..-1, owner 9/11: the
                // rune panel's hint on two lines when the engraved rune can be raised)
                float hotbarG = float(hotbarRgb.g >= 160 && hotbarRgb.g < 192 ? hotbarRgb.g - 192 : hotbarRgb.g);
                vec2 hotbarRel = vec2(hotbarVert.x - hotbarLeft, hotbarVert.y - hotbarLine - 3.0 + hotbarG);
                bool hotbarGulp = hotbarRgb.b >= 96 && hotbarRgb.b < 112;
                vec3 hotbarFill = HOTBAR_PALETTE[hotbarGulp ? 0 : hotbarRgb.b % 16];
                hotbarColor = vec4(!hotbarGulp && hotbarRgb.b % 32 >= 16 ? hotbarFill * 0.25 : hotbarFill, Color.a);
                if (hotbarGulp) {
                    // THE SLOT SWALLOWS THE ORE'S PIECE (owner 8/11, «come se ingoiasse il detrito»): a mineral's item
                    // marked blue 96 + phase (0..15) by MagixPrison's MineralHud is squashed and stretched round its
                    // own middle: the mouth opens wide, the gulp stretches it up, a little bounce, back still. The
                    // middle: slots of 21 from x 0, the 16 x 16 item 3 in; its top at row 15 here, so the middle at
                    // 11 / 23 and each corner 8 from it.
                    float gulpT = float(hotbarRgb.b - 96) / 15.0;
                    float gulpSlot = floor(hotbarRel.x / 21.0);
                    vec2 gulpMid = vec2(gulpSlot * 21.0 + 11.0, 23.0);
                    vec2 gulpDir = vec2(hotbarRel.x < gulpMid.x ? -8.0 : 8.0, hotbarRel.y < gulpMid.y ? -8.0 : 8.0);
                    vec2 gulpK;
                    if (gulpT < 0.25) gulpK = mix(vec2(1.0), vec2(1.3, 0.78), gulpT / 0.25);
                    else if (gulpT < 0.5) gulpK = mix(vec2(1.3, 0.78), vec2(0.82, 1.3), (gulpT - 0.25) / 0.25);
                    else if (gulpT < 0.75) gulpK = mix(vec2(0.82, 1.3), vec2(1.1, 0.92), (gulpT - 0.5) / 0.25);
                    else gulpK = mix(vec2(1.1, 0.92), vec2(1.0), (gulpT - 0.75) / 0.25);
                    // it stands on the slot's floor while it stretches, and hops a little at the gulp
                    vec2 gulpAt = gulpMid + vec2(0.0, 8.0 - 8.0 * gulpK.y - 2.0 * sin(3.14159 * gulpT));
                    hotbarRel = gulpAt + gulpDir * gulpK;
                }
                // a narrow GUI (1920x1080 at GUI scale 4 is 480 wide, 1366x768 at 3 is 455) has no room for the whole
                // panel right of the hotbar: it shrinks to fit, its bottom kept where it was (owner 7/11, «con tutti
                // gli schermi si vede bene»); the pictures are 4 texels a GUI pixel, so down to 0.5 they stay sharp
                float hotbarLeftEdge = floor(hotbarScreenW * 0.5) + 91.0 + HOTBAR_HUD_GAP;
                float hotbarScale = hudFit(hotbarScreenH, (hotbarScreenW - hotbarLeftEdge - HOTBAR_HUD_MARGIN) / HOTBAR_HUD_FIT_W, hotbarSize);
                if (hotbarRgb.b >= 64 && hotbarRgb.b < 96) {
                    // the left panel: its right edge left of the off hand's slot, shrunk the same way on a narrow GUI
                    float hotbarRightEdge = floor(hotbarScreenW * 0.5) - 91.0 - HOTBAR_HUD_OFFHAND - HOTBAR_HUD_GAP;
                    hotbarScale = hudFit(hotbarScreenH, (hotbarRightEdge - HOTBAR_HUD_MARGIN) / HOTBAR_HUD_LEFT_W, hotbarSize);
                    hotbarLeftEdge = hotbarRightEdge - HOTBAR_HUD_LEFT_W * hotbarScale;
                }
                if (hotbarRgb.b >= 224) {
                    // THE GOLEM'S PANEL (blue 224 + colour): the top right corner (see GOLEM_*)
                    float golemK = min(hudSize(hotbarScreenH, hotbarSize), GOLEM_SIZE_MAX);
                    hotbarVert.xy = vec2(hotbarScreenW - GOLEM_RIGHT - GOLEM_W * golemK + hotbarRel.x * golemK,
                            GOLEM_TOP + (hotbarRel.y - 1.0) * golemK);
                } else if (hotbarRgb.b >= 192) {
                    // THE ENCHANTMENTS (blue 192 + colour): at the top, centred, at the GUI's own scale (see ENCH_*)
                    // the player's size too (never past ENCH_SIZE_MAX: the boss bars under it keep their two lines)
                    float enchK = min(hudSize(hotbarScreenH, hotbarSize), ENCH_SIZE_MAX);
                    hotbarVert.xy = vec2(floor(hotbarScreenW * 0.5) + (hotbarRel.x - ENCH_W * 0.5) * enchK,
                            ENCH_TOP + (hotbarRel.y - 1.0) * enchK);
                } else if (hotbarRgb.b >= 128) {
                    // THE WOOD PANEL (blue 128 + colour, + 16 its shadow): slot i is written at x = WOOD_PITCH * i of the
                    // title and drawn in a COLUMN on the screen's left edge, half way up, slot i WOOD_ROW under slot 0
                    // (they touch like the hotbar's); shrunk on a short GUI so WOOD_MAX slots always fit
                    // A SLOT IS FOUND WITH ROOM TO SPARE (owner 11/11: «non si vede il pannello ma solo il legno»): a
                    // slot's glyphs are written WOOD_INSET in from the start of its own WOOD_PITCH pixels of the title,
                    // 22 wide, so every vertex of a slot falls in its own stretch even when the title sits a few
                    // pixels off (its width is not exactly the panel's: the box's edges fell into the next slot and
                    // its quad was torn between two rows). Six slots fit a title line, so the slots from the seventh
                    // on are written on a second one: green + WOOD_GROUP_G.
                    bool woodHint = hotbarRgb.b < 160 && hotbarG >= WOOD_HINT_G && hotbarG < WOOD_HINT_G + 32.0;
                    float woodGroup = hotbarRgb.b < 160 && hotbarG >= WOOD_GROUP_G && !woodHint ? 1.0 : 0.0;
                    hotbarRel.y -= woodGroup * WOOD_GROUP_G;
                    float woodColumn = floor(hotbarRel.x / WOOD_PITCH);
                    float woodSlot = woodColumn + woodGroup * WOOD_PER_GROUP;
                    if (hotbarRgb.b >= 160) {
                        // THE TOKENS (blue 160 + colour): one COLUMN at the right edge under the sidebar (see
                        // TOKEN_*), shrunk when it would reach the screen's bottom or, where the minerals' panel
                        // right of the hotbar comes as far right as the column, that panel's top
                        float tokenY = floor(hotbarScreenH * 0.5) + floor(TOKEN_SB_LINES * 9.0 / 3.0) + TOKEN_GAP;
                        float mineralScale = hudFit(hotbarScreenH, (hotbarScreenW - floor(hotbarScreenW * 0.5) - 91.0 - HOTBAR_HUD_GAP
                                - HOTBAR_HUD_MARGIN) / HOTBAR_HUD_FIT_W, hotbarSize);
                        float mineralRight = floor(hotbarScreenW * 0.5) + 91.0 + HOTBAR_HUD_GAP + HOTBAR_HUD_FIT_W * mineralScale;
                        float tokenBottom = mineralRight > hotbarScreenW - TOKEN_RIGHT - 23.0 * hudSize(hotbarScreenH, hotbarSize)
                                ? hotbarScreenH - HOTBAR_HUD_UP * mineralScale - 2.0 : hotbarScreenH - 2.0;
                        hotbarScale = hudFit(hotbarScreenH, (tokenBottom - tokenY) / (TOKEN_MAX * WOOD_ROW + 1.0), hotbarSize);
                        vec2 tokenTop = vec2(hotbarScreenW - TOKEN_RIGHT - 22.0 * hotbarScale, tokenY);
                        if (hotbarG >= TOKEN_HINT_G && hotbarG < TOKEN_HINT_G + 32.0) {
                            // the vertical hint: title x = along the column from its bottom, title y = towards it
                            float hintV = hotbarRel.y - TOKEN_HINT_G;
                            hotbarVert.xy = vec2(tokenTop.x - (TOKEN_HINT_W - hintV) * hotbarScale,
                                    tokenY + (TOKEN_MAX * WOOD_ROW - hotbarRel.x) * hotbarScale);
                        } else {
                        vec2 tokenRel = vec2(hotbarRel.x - woodColumn * WOOD_PITCH - WOOD_INSET,
                                hotbarRel.y - WOOD_TOP + woodColumn * WOOD_ROW);
                        hotbarVert.xy = tokenTop + (tokenRel - vec2(0.0, 1.0)) * hotbarScale;
                        }
                    } else {
                    hotbarScale = hudFit(hotbarScreenH, (hotbarScreenH - 2.0 * WOOD_MARGIN) / (WOOD_MAX * WOOD_ROW + 2.0), hotbarSize);
                    vec2 woodTop = vec2(WOOD_MARGIN, floor(hotbarScreenH * 0.5 - WOOD_MAX * WOOD_ROW * 0.5 * hotbarScale));
                    if (woodHint) {
                        // the vertical hint: title x = along the column from its bottom, title y = away from it
                        float hintV = hotbarRel.y - WOOD_HINT_G;
                        hotbarVert.xy = vec2(woodTop.x + (22.0 + WOOD_HINT_GAP + hintV) * hotbarScale,
                                woodTop.y + (WOOD_MAX * WOOD_ROW - hotbarRel.x) * hotbarScale);
                    } else {
                    vec2 woodRel = vec2(hotbarRel.x - woodColumn * WOOD_PITCH - WOOD_INSET, hotbarRel.y - WOOD_TOP + woodSlot * WOOD_ROW);
                    hotbarVert.xy = woodTop + (woodRel - vec2(0.0, 1.0)) * hotbarScale;
                    }
                    }
                } else {
                    hotbarVert.xy = vec2(hotbarLeftEdge, hotbarScreenH - HOTBAR_HUD_UP * hotbarScale)
                            + (hotbarRel - vec2(0.0, 1.0)) * hotbarScale;
                }
                gl_Position = ProjMat * hotbarVert;
            }
        }
    }
#endif

#ifdef MAGIX_GUI_CODE
    // MagixPrison's carry bar (see CARRY_RED).
    vec4 carryColor = vec4(-1.0);
    {
        ivec3 carryRgb = ivec3(round(Color.rgb * 255.0));
        bool carryFill = carryRgb.r == CARRY_RED && carryRgb.b == 255 && carryRgb.g % 16 == 0 && carryRgb.g < 224;
        bool carryShadow = carryRgb.r == CARRY_RED / 4 && carryRgb.b == 63 && carryRgb.g % 4 == 0 && carryRgb.g < 56;
        if (carryFill || carryShadow) {
            vec4 carryVert = ModelViewMat * vec4(Position, 1.0);
            float carryScreenW = abs(2.0 / ProjMat[0][0]);
            float carryScreenH = abs(2.0 / ProjMat[1][1]);
            bool carryNearMiddle = abs(carryVert.x - carryScreenW * 0.5) < CARRY_HALF_W;
            bool carryBoss = carryNearMiddle && carryVert.y < CARRY_BOSS_BAND;
            if (carryBoss || (carryNearMiddle && carryVert.y > carryScreenH - CARRY_BAND.x
                    && carryVert.y < carryScreenH - CARRY_BAND.y)) {
                int carryIndex = carryFill ? carryRgb.g / 16 : carryRgb.g / 4;
                vec3 carryFillRgb = CARRY_PALETTE[min(carryIndex % 8, 5)];
                carryColor = vec4(carryShadow ? carryFillRgb * 0.25 : carryFillRgb, Color.a);
                float carryDrop = carryIndex >= 8 ? CARRY_SECOND_DROP : 0.0;
                if (carryBoss) {
                    float carryRow = floor((carryVert.y + 2.5) / 19.0) * 19.0 + 3.0;
                    carryVert.y = carryScreenH - CARRY_BOSS_TOP + (carryVert.y - carryRow) + carryDrop;
                } else {
                    carryVert.y -= CARRY_LIFT - carryDrop;
                }
                gl_Position = ProjMat * carryVert;
            }
        }
    }
#endif

#ifdef MAGIX_GUI_CODE
    // MagixPack menu marquee (see MARQUEE_BOXES).
    float marqueeAlpha = -1.0;
    ivec3 marqueeRgb = ivec3(round(Color.rgb * 255.0));
    if (marqueeRgb.r == 253) {
        float marqueeOffset = float(marqueeRgb.g);
        int marqueeBoxIndex = marqueeRgb.b - (marqueeRgb.b / 8) * 8;
        float marqueeBox = MARQUEE_BOXES[marqueeBoxIndex];
        float marqueePeriod = float(marqueeRgb.b - marqueeBoxIndex) + MARQUEE_GAP;
        float marqueeTurn = marqueePeriod / MARQUEE_SPEED + MARQUEE_HOLD;
        float marqueeShift = max(0.0, mod(GameTime * 1200.0, marqueeTurn) - MARQUEE_HOLD) * MARQUEE_SPEED;
        // where the character is now, from the label's start: -FADE .. period - FADE (out on the left = back on the right)
        float marqueeAt = mod(marqueeOffset - marqueeShift + MARQUEE_FADE, marqueePeriod) - MARQUEE_FADE;
        vec4 marqueeVert = ModelViewMat * vec4(Position, 1.0);
        gl_Position = ProjMat * vec4(marqueeVert.x + marqueeAt - marqueeOffset, marqueeVert.yzw);
        marqueeAlpha = clamp((marqueeAt + MARQUEE_FADE) / MARQUEE_FADE, 0.0, 1.0)
                * clamp((marqueeBox - MARQUEE_CHAR - marqueeAt) / MARQUEE_FADE + 1.0, 0.0, 1.0);
    }
    // MagixPack panel credits (see CREDITS_LINE).
    float creditsAlpha = -1.0;
    vec3 creditsColour = vec3(1.0);
    if (marqueeRgb.r == 250 && marqueeRgb.b >= 2 && marqueeRgb.b <= 32 && marqueeRgb.g % 32 < marqueeRgb.b) {
        float creditsLine = float(marqueeRgb.g % 32);
        creditsColour = CREDITS_PALETTE[marqueeRgb.g / 32];
        float creditsPeriod = (float(marqueeRgb.b) + CREDITS_GAP) * CREDITS_LINE;
        float creditsTurn = creditsPeriod / CREDITS_SPEED + CREDITS_HOLD;
        float creditsShift = max(0.0, mod(GameTime * 1200.0, creditsTurn) - CREDITS_HOLD) * CREDITS_SPEED;
        // where the line is now, from the window's top: -FADE .. period - FADE (out at the top = back at the bottom)
        float creditsAt = mod(creditsLine * CREDITS_LINE - creditsShift + CREDITS_FADE, creditsPeriod) - CREDITS_FADE;
        vec4 creditsVert = ModelViewMat * vec4(Position, 1.0);
        gl_Position = ProjMat * vec4(creditsVert.x, creditsVert.y + creditsAt, creditsVert.zw);
        creditsAlpha = clamp((creditsAt + CREDITS_TOP_FADE) / CREDITS_TOP_FADE, 0.0, 1.0)
                * clamp((CREDITS_LINES * CREDITS_LINE - CREDITS_LINE - creditsAt) / CREDITS_FADE + 1.0, 0.0, 1.0);
    }
#endif

#ifdef MAGIX_GUI_CODE
    // MagixPack compact menus (see FIT_PAGE_RED).
    bool fitWhite = false;
    bool fitLetterHidden = false;
    {
        ivec3 fitRgb = ivec3(round(Color.rgb * 255.0));
        vec2 fitScreen = vec2(abs(2.0 / ProjMat[0][0]), abs(2.0 / ProjMat[1][1]));
        vec4 fitVert = ModelViewMat * vec4(Position, 1.0);
        if (fitRgb.r == FIT_PAGE_RED && fitRgb.g >= 128 && fitRgb.g < 152 && (fitRgb.g - 128) % 4 < 3) {
            int fitZone = (fitRgb.g - 128) % 4;
            int fitRows = (fitRgb.g - 128) / 4 + 1;
            float fitTop = fitWindowTop(fitScreen.y, fitRows);
            if (fitZone == 1 && fitRgb.b > 0) {
                fitVert.y = fitTop + (fitVert.y - fitTop) * clamp((fitTop - FIT_MARGIN) / float(fitRgb.b), 0.0, 1.0);
            }
            if (fitZone == 2) fitVert.y = max(min(fitVert.y, fitScreen.y - FIT_MARGIN), fitTop + float(114 + 18 * fitRows));
            fitVert.x = clamp(fitVert.x, FIT_MARGIN, fitScreen.x - FIT_MARGIN);
            gl_Position = ProjMat * fitVert;
            fitWhite = true;
        } else if (fitRgb.r == FIT_BANNER_RED && fitRgb.g > 160 && fitRgb.g <= 166) {
            if (fitWindowTop(fitScreen.y, fitRgb.g - 160) < float(fitRgb.b) + FIT_MARGIN) gl_Position = FIT_GONE;
            fitWhite = true;
        } else {
            vec2 fitMark = fitLetterMark();
            if (fitMark.y > 0.0 && fitLetterOnWindow(fitVert.y + fitMark.x, fitScreen.y)
                    && fitVert.y + fitMark.x < fitMark.y + FIT_MARGIN) fitLetterHidden = true;
        }
    }
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
#ifdef MAGIX_GUI_CODE
    if (hudLabelColor.r >= 0.0) vertexColor = hudLabelColor;
    if (hotbarColor.r >= 0.0) vertexColor = hotbarColor;
    if (carryColor.r >= 0.0) vertexColor = carryColor;
#endif
#ifdef MAGIX_GUI_CODE
    if (marqueeAlpha >= 0.0) vertexColor = vec4(1.0, 1.0, 1.0, Color.a * marqueeAlpha);
    if (creditsAlpha >= 0.0) vertexColor = vec4(creditsColour, Color.a * creditsAlpha);
#endif
#ifdef MAGIX_GUI_CODE
    if (fitWhite) vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    if (fitLetterHidden) vertexColor.a = 0.0;
    {
        ivec2 fitMark = canvasFitMark(ivec3(round(Color.rgb * 255.0)));
        if (fitMark.x >= 0) {
            vec2 fitGui = vec2(round(abs(2.0 / ProjMat[0][0])), ceil(abs(2.0 / ProjMat[1][1]) - 0.01));
            vertexColor = canvasFitHolds(fitMark.x, fitGui) ? vec4(vec3(fitMark.y == 1 ? 0.25 : 1.0), Color.a) : vec4(0.0);
            if (vertexColor.a > 0.0 && (fitMark.x % 64) / 16 == 2) {
                // the recommended size PULSES and a light SWEEPS across it (owner 20/11)
                float fitT = GameTime * 1200.0;
                float fitPulse = 0.5 + 0.5 * sin(fitT * 6.2832 / 1.4);
                vec2 fitPx = (gl_Position.xy * vec2(0.5, -0.5) + 0.5) * fitGui;
                float fitD = mod(fitPx.x + 0.6 * fitPx.y - fitT * 70.0, 150.0) - 75.0;
                float fitShine = exp(-fitD * fitD / 450.0);
                vertexColor.rgb *= 0.85 + 0.35 * fitPulse + 1.1 * fitShine;
                vertexColor.a *= 0.65 + 0.35 * fitPulse;
            }
        }
    }
    // THE SHINE MARK (prison_canvas SHINE_ORBIT / SHINE_SWEEP, owner 20/11: «il grafico a torta deve avere animazioni»,
    // «il tasto guida illuminato»): a picture of a canvas tinted red 238 + blue 78 is drawn by canvasShine() of text.fsh
    // with a light that moves (green 0 = round it, 1 = across it, 2 = a twinkling spark, 3 = a flowing rainbow, 4..6 = a
    // halo of the VIP, Plus, Prime colour with a light running round it) and a breath; where a texel is in the picture rides in
    // its own colour's low bits (prison_canvas.shine_encode): never gl_VertexID, which clients compiling to SPIR-V lack
    {
        ivec3 shineRgb = ivec3(round(Color.rgb * 255.0));
        if (shineRgb.r == 238 && shineRgb.b == 78 && shineRgb.g <= 6) {
            hudMode = 7;
            hudData = vec4(float(shineRgb.g), GameTime * 1200.0, 0.0, 0.0);
            vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
        } else if (shineRgb.r == 238 && shineRgb.b == 79) {
            // THE LIVE RING (owner 20/11, the pack under 35 MB): ONE picture of four quarter marks (guideCorner()), the
            // whole level ring drawn by canvasRing() of text.fsh at the player's own percent, green 0..100 (MagixMenus
            // canvas text tint-green): 202 pictures a size before (the ring and its spark at every percent)
            hudMode = 21;
            hudPos = guideCorner();
            hudData = vec4(float(shineRgb.g) / 100.0, GameTime * 1200.0, 0.0, 0.0);
            vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
        } else if (shineRgb.r == 238 && shineRgb.b == 80 && shineRgb.g <= 1) {
            // THE CAROUSEL'S ARROWS (owner 23/11: «le frecce devono brillare oltre che oscillare su e giù»; MagixMenus
            // canvas-extras color, prison_canvas ARROW_MARK): the crystal arrow at each side of the board BOBS 3 GUI
            // pixels up and down and BREATHES brighter, both in a 1.1 s beat; its picture is drawn as it is (its click
            // box, the client's, stays still)
            float arrowT = GameTime * 1200.0 * 6.2831853 / 1.1;
            float arrowGuiH = ceil(abs(2.0 / ProjMat[1][1]) - 0.01);
            gl_Position.y += sin(arrowT) * 3.0 * 2.0 / arrowGuiH * gl_Position.w;
            vertexColor = vec4(vec3(0.92 + 0.30 * (0.5 + 0.5 * sin(arrowT + 1.2))), Color.a);
        } else if (shineRgb.r == 238 && shineRgb.b >= 95 && shineRgb.b <= 127) {
            // THE CHAT HALO (owner 23/11, MagixPack chat/ChatRibbon, docs/PRISON-CHAT-PLAN.md): the halo on a writer's face
            // in the Prison chat. Its two halves (glyphs chat_halo_back|front, DATA: each texel's place round the ring) are
            // tinted red 238 + blue 96..111 (animated) or 112..127 (still) + the halo's colour in nibbles (green = red4,
            // green4; blue - 96 or - 112 = blue4; 000 = the prism); its star (chat_halo_star) red 238 + blue 95 + green = the
            // writer's own moment. chatHalo() of text.fsh colours the ring and runs a light round it (hudMode 23). Animated,
            // the ring and its star float down and up by half a GUI pixel every 4 s (the same beat for every line: a
            // vertex cannot tell which line it is on without shearing its glyph) and the star twinkles now and then.
            bool chatStar = shineRgb.b == 95;
            bool chatStill = shineRgb.b >= 112;
            int chatB4 = chatStar ? 0 : shineRgb.b - (chatStill ? 112 : 96);
            float chatT = GameTime * 1200.0;
            if (!chatStill) {
                float chatGuiH = ceil(abs(2.0 / ProjMat[1][1]) - 0.01);
                float chatDown = 0.25 + 0.25 * sin(chatT * 6.2831853 / 4.0);
                gl_Position.y -= chatDown * 2.0 / chatGuiH * gl_Position.w;
            }
            hudMode = 23;
            hudData = chatStar ? vec4(1.0, 1.0, 1.0, 2.0)
                    : vec4(float(shineRgb.g >> 4), float(shineRgb.g & 15), float(chatB4), 0.0) / vec4(15.0, 15.0, 15.0, 1.0)
                      + vec4(0.0, 0.0, 0.0, chatStill ? 1.0 : 0.0);
            hudPos = vec2(chatStill ? 0.0 : chatT, chatStar ? float(shineRgb.g) / 255.0 : 0.0);
            vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
        }
    }
    // THE CAROUSEL'S TURN (owner 23/11: «deve vedersi l'animazione del carosello»; MagixMenus DialogManager#veil): a click
    // on a side of the carousel opens the next screen with the OLD face's glyphs on its last body line, coloured red 238 +
    // blue 81 (the face leaves to the left) or 82 (to the right), green = the open tick's low 8 bits. Each glyph stands
    // TURN_FAR x k GUI pixels left of its place, k = 1 + code: code bits 0-5 = its old line's distance from the last line
    // + 8, bit 6 = the size (Grande), bits 7-12 = the tick's bits 8-13 (every number an integer: exact in floats). From
    // the open tick (GameTime = the world's game time, the same tick the server read) the face turns round the ring in
    // perspective to its side and darkens for TURN_TICKS, then is hidden; a jump of the world's time hides it at once.
    {
        ivec3 turnRgb = ivec3(round(Color.rgb * 255.0));
        if (turnRgb.r == 238 && (turnRgb.b == 81 || turnRgb.b == 82)) {
            vec4 tv = ModelViewMat * vec4(Position, 1.0);
            vec2 tGui = vec2(round(abs(2.0 / ProjMat[0][0])), ceil(abs(2.0 / ProjMat[1][1]) - 0.01));
            float tCx = tGui.x * 0.5;
            float tK = floor((tCx - tv.x) / TURN_FAR + 0.5);
            if (tK >= 1.0 && tK <= 8192.0) {
                int tCode = int(tK) - 1;
                float tU = tv.x + TURN_FAR * tK - tCx;          // the glyph's x from the board's middle
                int tSize = (tCode >> 6) & 1;
                float tY = tv.y - float((tCode & 63) - 8) * 9.0;  // back on its own line
                float tTick = float(turnRgb.g + 256 * ((tCode >> 7) & 63));
                float tE = mod(mod(GameTime * 24000.0, 16384.0) - tTick + 8192.0, 16384.0) - 8192.0;
                if (tE < -3.0 || tE > TURN_TICKS) {
                    gl_Position = vec4(-4.0, -4.0, 0.0, 1.0);
                } else {
                    float t = clamp(tE / TURN_TICKS, 0.0, 1.0);
                    float ease = t * t * (3.0 - 2.0 * t);
                    float tDir = turnRgb.b == 81 ? -1.0 : 1.0;
                    float tW = tSize == 1 ? 528.0 : 352.0;
                    float tLines = tSize == 1 ? 30.0 : 20.0;
                    float tCy = min(63.0, tGui.y - 5.0 - (tLines * 9.0 + 18.0)) + 4.0 + tLines * 4.5;
                    // the ring: its centre TURN_RING x the board's width behind the face, the eye TURN_EYE x it in front
                    float tR = TURN_RING * tW;
                    float tD = TURN_EYE * tW;
                    float phi = tDir * ease * TURN_ANGLE;
                    float tX = tR * sin(phi) + tU * cos(phi);
                    float tZ = tR * (1.0 - cos(phi)) + tU * sin(phi);   // the leading edge goes deeper
                    float tS = tD / max(tD + tZ, 1.0);
                    gl_Position = ProjMat * vec4(tCx + tX * tS, tCy + (tY - tCy) * tS, tv.z, tv.w);
                    vertexColor = vec4(vec3(mix(1.0, TURN_DARK, ease)), Color.a * (1.0 - smoothstep(0.65, 1.0, t)));
                }
            }
        }
    }
#endif
#if !defined(IS_GUI) && MAGIX_TARGET == 261
    // 26.1 and 1.21.x: the world's text stays vanilla (see MAGIX_GUI_CODE)
    if (ProjMat[2][3] != 0.0) {
        gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
        vertexColor = Color * sample_lightmap(Sampler2, UV2);
        hudMode = 0;
        hudPos = vec2(0.0);
        hudData = vec4(0.0);
        hudBox = vec4(0.0);
    }
#endif
    texCoord0 = UV0;
}
