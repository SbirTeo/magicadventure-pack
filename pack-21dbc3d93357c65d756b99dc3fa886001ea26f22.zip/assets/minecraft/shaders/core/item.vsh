#version 330
#define MAGIX_TARGET 262
#define LOC(n)

// MagixPack's item vertex shader: vanilla, plus the running light of the VIP halo. One source for 26.1, 26.2 and 26.3
// (pack/ShaderVariants writes it three times, MAGIX_TARGET and LOC(n)): 26.3's own lines are under GLINT /
// GLINT_SPECIAL / OIT_* (never defined before 26.3), 26.1's are under MAGIX_TARGET == 261 (no lightMapColor /
// overlayColor there, the light map goes in vertexColor). Until MagixPack 0.33.9 it also hid the sharp copy of a drawn
// menu's banner on small screens; that is done by position_tex_color.vsh now (menu-panel/ template of MenuPanel).
//
// HALO: the VIP halo of MagixCosmetics (item model magixpack:halo, tools/make_halo.py), a ring of HALO_STEPS sides
// tinted in the player's colour, with a light running round it. Its vertices are recognised by the texel under
// them: red HALO_MARK_RED, green and blue = the step round the ring (255 - step / 8, 255 - step % 8), and the
// signature HALO_SIGNATURE HALO_SIGNATURE_ROWS rows under it (no other texture has both). A halo vertex is drawn
// in the tint's colour, always lit and without the side shading, and the light (a bright head with a fading tail)
// goes round in HALO_LAP_SECONDS from the game time (Globals: 26.2 and 26.3; on 26.1 the ring stays still).
// A halo vertex closer to the camera than HALO_HIDE_NEAR blocks is not drawn: in first person the camera is inside
// the player's own head and his ring would sit at the top of the screen; in third person (F5) the camera is ~4
// blocks away and he sees it (owner, 17/10). Other players' rings are never that close.
// Numbers shared with tools/make_halo.py: change both.

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#if MAGIX_TARGET >= 262 && !defined(OIT_ALPHA_ONLY) && !defined(OIT_ACCUMULATE)
// GameTime: the item pipelines have the Globals block (ITEM_SNIPPET, checked in the 26.2 and 26.3 clients);
// the OIT ones of 26.3 do not
#define MAGIX_GLOBALS
#moj_import <minecraft:globals.glsl>
#endif
#if !defined(OIT_ALPHA_ONLY) && !defined(OIT_ACCUMULATE)
// the halo is opaque (cutout pipeline): never drawn by the translucent passes of 26.3
#define MAGIX_HALO
#endif

LOC(0) in vec3 Position;
LOC(1) in vec4 Color;
LOC(2) in vec2 UV0;
LOC(3) in ivec2 UV1;
LOC(4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
LOC(5) in vec2 UV3;
#endif
LOC(6) in vec3 Normal;

#ifdef MAGIX_HALO
uniform sampler2D Sampler0;
#endif

#if MAGIX_TARGET == 261
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
#else
#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

LOC(0) out float sphericalVertexDistance;
LOC(1) out float cylindricalVertexDistance;
#endif
LOC(2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
LOC(3) out vec4 lightMapColor;
LOC(4) out vec4 overlayColor;
#endif

LOC(5) out vec2 texCoord0;
#ifdef GLINT
LOC(6) out vec2 texCoordGlint;
#endif
#endif


const int HALO_MARK_RED = 253;                       // = MARK_RED of tools/make_halo.py
const ivec3 HALO_SIGNATURE = ivec3(250, 246, 252);   // = SIGNATURE
const int HALO_SIGNATURE_ROWS = 8;                   // = DATA_ROWS
const float HALO_STEPS = 32.0;                       // = STEPS
const float HALO_LAP_SECONDS = 2.4;                  // one lap of the light (1200 / 2.4 laps: no jump when GameTime wraps)
const float HALO_TAIL = 6.0;                         // how fast the tail fades behind the light
const float HALO_BASE = 0.7;                         // the ring away from the light, times the tint
const float HALO_WHITE = 0.7;                        // how white the light's head is
const float HALO_HIDE_NEAR = 1.0;                    // blocks from the camera under which a halo is hidden

#ifdef MAGIX_HALO
// The step round the ring of a halo vertex (0..HALO_STEPS), or -1 for any other vertex.
float haloStep() {
    ivec2 size = textureSize(Sampler0, 0);
    ivec2 at = ivec2(floor(UV0 * vec2(size)));
    if (at.x < 0 || at.y < 0 || at.x >= size.x || at.y + HALO_SIGNATURE_ROWS >= size.y) return -1.0;
    ivec4 t = ivec4(round(texelFetch(Sampler0, at, 0) * 255.0));
    if (t.r != HALO_MARK_RED || t.g < 251 || t.b < 248 || t.a != 255) return -1.0;
    ivec4 s = ivec4(round(texelFetch(Sampler0, at + ivec2(0, HALO_SIGNATURE_ROWS), 0) * 255.0));
    if (s.rgb != HALO_SIGNATURE || s.a != 255) return -1.0;
    return float((255 - t.g) * 8 + (255 - t.b));
}

// The halo's colour at that turn step: the tint, and the running light's head and tail mixed towards white.
vec4 haloColor(float turn, vec4 tint) {
    float light = 0.0;
#ifdef MAGIX_GLOBALS
    float head = fract(GameTime * 1200.0 / HALO_LAP_SECONDS);
    float behind = fract(head - turn / HALO_STEPS);              // 0 at the head, growing along the tail
    light = exp(-behind * HALO_TAIL) * (1.0 - smoothstep(0.96, 1.0, behind));   // just ahead of the head: dark
#endif
    vec3 ring = tint.rgb * mix(HALO_BASE, 1.0, light);
    return vec4(mix(ring, vec3(1.0), HALO_WHITE * light * light), tint.a);
}
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#ifdef MAGIX_HALO
    float halo = haloStep();
    // the wearer's own ring in first person: beyond the far plane, not drawn
    if (halo >= 0.0 && length((ModelViewMat * vec4(Position, 1.0)).xyz) < HALO_HIDE_NEAR) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
#endif

#if MAGIX_TARGET == 261
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * sample_lightmap(Sampler2, UV2);
#ifdef MAGIX_HALO
    if (halo >= 0.0) vertexColor = haloColor(halo, Color);
#endif

    texCoord0 = UV0;
#else
    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif
    #ifdef MAGIX_HALO
    if (halo >= 0.0) {
        vertexColor = haloColor(halo, Color);
        lightMapColor = vec4(1.0);
    }
    #endif

    texCoord0 = UV0;
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif
#endif
}
