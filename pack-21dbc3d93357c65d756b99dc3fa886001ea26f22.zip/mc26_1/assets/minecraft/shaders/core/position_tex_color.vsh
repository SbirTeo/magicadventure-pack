#version 330
#define MAGIX_TARGET 261
#define LOC(n)

// MagixPack's position_tex_color vertex shader: vanilla, plus the COMPACT MENUS rule for the sharp copy of a banner
// above a drawn menu (menu/MenuPanel.bannerItems: item models on slots 0, 4, 8). A TEMPLATE: MenuPanel writes it in the
// pack with the banner's numbers of menu-panel (__FIT_*__), and ShaderVariants makes one copy per Minecraft version
// (MAGIX_TARGET, LOC(n)). 26.1 binds no Globals to the GUI pipelines: there it is vanilla.
//
// An oversized item is drawn first in a picture of its own and the picture is then copied on the screen with this
// shader (PictureInPictureRenderer.blitTexture, pipeline GUI_TEXTURED_PREMULTIPLIED_ALPHA): a quad with the whole
// texture (u 0..1, v 1 at its top, 0 at its bottom), as big as the item's bounds, the texture GUI scale times bigger.
// Here everything is exact: the projection gives the screen in GUI pixels, ScreenSize / that the GUI scale, the
// texture's size / the scale the picture's size, so every vertex knows its whole quad. When the screen is too short
// for the banner (the same rule as the banner of the title in text.vsh: the window's top less than the banner's
// height above it plus FIT_MARGIN), a whole-texture quad of the banner's height, with its top where the banner's is
// and inside the banner's width, is sent out of the screen. Until 17/10 this was done in item.vsh, guessing the GUI
// scale from the item's own picture: the piece with the market's moving tiles stayed on the screen.
// Copied rule, same numbers: FIT_* of text.vsh (MagixPack's and MagixFactions').

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamictransforms.glsl, projection.glsl and (26.2+) globals.glsl
#if MAGIX_TARGET >= 263
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
#else
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
#endif
layout(std140) uniform Projection {
    mat4 ProjMat;
};
#if MAGIX_TARGET >= 263
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};
uniform sampler2D Sampler0;
#elif MAGIX_TARGET >= 262
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    vec3 CameraOffset;
    vec2 ScreenSize;
    float GlintAlpha;
    float GameTime;
    int MenuBlurRadius;
    int UseRgss;
};
uniform sampler2D Sampler0;
#endif

LOC(0) in vec3 Position;
LOC(1) in vec2 UV0;
LOC(2) in vec4 Color;

LOC(0) out vec2 texCoord0;
LOC(1) out vec4 vertexColor;

const float FIT_BANNER_HEIGHT = 52.0;   // menu-panel.top-height
const float FIT_REACH = 66.0;                   // the banner's top above the window: top-gap + top-height
const float FIT_HALF_WIDTH = 229.0;         // half the banner's width (the window and both side panels)
const float FIT_MARGIN = 6.0;                            // = text.vsh
const float FIT_CHEST_HEIGHT = 222.0;                    // the double chest's window (the banner is only on 6-row menus)

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if MAGIX_TARGET >= 262
    // MagixPack compact menus (see the top of this file): an orthographic projection with y down (the GUI) and a
    // whole-texture quad only
    if (ProjMat[2][3] == 0.0 && ProjMat[1][1] < 0.0 && ScreenSize.y > 0.0
            && (UV0.x == 0.0 || UV0.x == 1.0) && (UV0.y == 0.0 || UV0.y == 1.0)) {
        vec2 fitScreen = vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]);
        float fitScale = max(1.0, round(ScreenSize.y / fitScreen.y));
        vec2 fitSize = vec2(textureSize(Sampler0, 0)) / fitScale;
        vec4 fitVert = ModelViewMat * vec4(Position, 1.0);
        float fitTop = UV0.y == 1.0 ? fitVert.y : fitVert.y - fitSize.y;
        float fitLeft = UV0.x == 0.0 ? fitVert.x : fitVert.x - fitSize.x;
        // the client lays the screen out on its size rounded up, and centres the chest's window in it
        float fitWindowTop = floor((ceil(fitScreen.y - 0.01) - FIT_CHEST_HEIGHT) * 0.5);
        float fitCentre = floor((ceil(fitScreen.x - 0.01) - 176.0) * 0.5) + 88.0;
        if (fitWindowTop < FIT_REACH + FIT_MARGIN
                && abs(fitSize.y - FIT_BANNER_HEIGHT) <= 1.0
                && abs(fitTop - (fitWindowTop - FIT_REACH)) <= 1.5
                && fitLeft >= fitCentre - FIT_HALF_WIDTH - 2.0
                && fitLeft + fitSize.x <= fitCentre + FIT_HALF_WIDTH + 2.0) {
            // every vertex of the quad to its top left corner: the quad shrinks to a point, not drawn. Never out of the
            // screen: a quad that only looks like the banner's on some of its vertices (Lunar Client copies its own HUD
            // pictures with this shader) drew streaks of light from the bottom left corner (19/10); now it stays local.
            gl_Position = ProjMat * vec4(fitLeft, fitTop, fitVert.z, fitVert.w);
        }
    }
#endif

    texCoord0 = UV0;
    vertexColor = Color;
}
