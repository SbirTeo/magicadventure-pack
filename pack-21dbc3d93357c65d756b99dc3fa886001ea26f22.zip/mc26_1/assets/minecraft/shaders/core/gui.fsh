#version 330
#define MAGIX_TARGET 261
#define LOC(n)

// One source for 26.1, 26.2 and 26.3: see the note at the top of gui.vsh (MAGIX_TARGET, LOC, overlays).

// MagixScoreboard: vanilla "gui" fragment shader (Minecraft 26.2) plus the sidebar background
// recolor and border. The __SB_*__ placeholders are replaced by the plugin from config.yml
// (sidebar-background.*): changing them rebuilds the resource pack.

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
#if MAGIX_TARGET >= 263
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
#else
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
#endif

LOC(0) in vec4 vertexColor;
LOC(1) flat in int sbKind;
LOC(2) in vec2 sbUV;
LOC(3) in vec2 sbGui;
LOC(4) in float sbOk;
LOC(5) in float chatTag;

LOC(0) out vec4 fragColor;

// Background of title and body (same color and opacity for both). Alpha 0 = no background.
const vec4 SB_BACKGROUND = vec4(0.0000, 0.0000, 0.0000, 0.5000);
// Border on the top, left and bottom sides (never the right one), in GUI pixels. 0 = no border.
const float SB_BORDER = 1.0000;
// Horizontal gradient of the border, left to right (like the site: linear-gradient(90deg, ...)).
const vec3 SB_BORDER_START = vec3(0.6392, 0.9020, 0.2078);
const vec3 SB_BORDER_END = vec3(0.7529, 0.3098, 0.9412);
const float SB_BORDER_ALPHA = 0.5000;

void main() {
    vec4 color = vertexColor;
    // Derivatives out of any branch: they must be computed by the whole 2x2 pixel block.
    float width = abs(dFdx(sbGui.x) / max(abs(dFdx(sbUV.x)), 1e-6));
    float height = abs(dFdy(sbGui.y) / max(abs(dFdy(sbUV.y)), 1e-6));

    if (sbKind != 0) {
        color = SB_BACKGROUND;
        if (SB_BORDER > 0.0 && sbOk > 0.999) {
            float left = sbUV.x * width;
            float fromTop = sbUV.y * height;
            float fromBottom = (1.0 - sbUV.y) * height;
            // Title: left + top. Body: left + bottom. Together they outline the whole sidebar.
            bool edge = left < SB_BORDER
                    || (sbKind == 2 && fromTop < SB_BORDER)
                    || (sbKind == 1 && fromBottom < SB_BORDER);
            if (edge) {
                color = vec4(mix(SB_BORDER_START, SB_BORDER_END, clamp(sbUV.x, 0.0, 1.0)), SB_BORDER_ALPHA);
            }
        }
    }

    // The chat's "System" mark (gui.vsh, CHAT_TAG): all four corners marked, so 1 everywhere inside it; a bigger
    // fill with one marked corner is near 1 only right at that corner.
    if (chatTag > 0.999) {
        discard;
    }
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
