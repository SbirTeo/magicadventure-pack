#version 330
#extension GL_ARB_separate_shader_objects : require
#define MAGIX_TARGET 263
#define LOC(n) layout(location = n)

// One source for 26.1, 26.2 and 26.3: see the note at the top of text.vsh (MAGIX_TARGET, LOC, overlays).
// 26.3 also adds order-independent transparency (OIT): the world variant can be compiled with OIT_ALPHA_ONLY
// (no colour output at all), OIT_ACCUMULATE and the other OIT_* defines. Every colour this file writes goes
// through magixEmit, which does what vanilla 26.3 does in each case.

// MagixFactions minimap HUD — porting a Paper/Minecraft 26.2 (2026-07-23): vedi la nota gemella in
// text.vsh. Il vanilla "rendertype_text.fsh" e' diventato questo "text.fsh" unico, condiviso da tre
// varianti (mondo/GUI/see-through). La nostra logica (custom==1 minimap, custom==2 mappa-item) esiste
// SOLO nella variante "mondo" (le altre due non hanno neppure `custom`/`uvCoord`/`arrows` dichiarati,
// dato che il vertex shader li dichiara nello stesso #if) — va quindi eseguita PRIMA e dentro lo stesso
// #if, con un default identico al vanilla per le altre due varianti (invariato, solo re-indentato).

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
// 26.3 only: MagixPack turns this comment into the include in the mc26_3 overlay (oit.glsl does not exist before).
#include <minecraft:oit.glsl>
// The Store box's running light (storeGlow) needs GameTime: 26.2 and 26.3 only (26.1 has no GUI text variant).

#include <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
LOC(0) in float sphericalVertexDistance;
LOC(1) in float cylindricalVertexDistance;
#endif

LOC(2) in vec4 vertexColor;
LOC(3) in vec2 texCoord0;

#if MAGIX_TARGET < 263 || !defined(OIT_ALPHA_ONLY)
LOC(0) out vec4 fragColor;
#endif

// Writes a final colour: plain on 26.1/26.2 and in the GUI, the OIT phase of 26.3 otherwise (as vanilla 26.3).
void magixEmit(vec4 c) {
#if MAGIX_TARGET >= 263 && defined(OIT_ALPHA_ONLY)
    executeAlphaOnlyPhase(gl_FragCoord.z, c.a);
#elif MAGIX_TARGET >= 263 && defined(OIT_ACCUMULATE)
    fragColor = sampleColorForAccumulation(c);
#else
    fragColor = c;
#endif
}

// Depth that keeps the minimap and the info panel in front of everything: 26.2+ use reversed-Z (1.0 is the
// nearest, see the minimap branch), 26.1 the classic depth (0.0 is the nearest).
#if MAGIX_TARGET >= 262
const float HUD_DEPTH = 1.0;
#else
const float HUD_DEPTH = 0.0;
#endif

#ifdef IS_GUI
// MagixFactions theft HUD: see the note in text.vsh (above HUD_ARROW_HALF).
LOC(4) in vec2 hudPos;
LOC(5) flat in int hudMode;
LOC(6) flat in vec4 hudData;

const vec3 HUD_FRAME_YELLOW = vec3(1.0, 0.82, 0.12);
const vec3 HUD_FRAME_RED = vec3(0.9, 0.08, 0.08);
const vec3 HUD_ARROW_FILL = vec3(1.0, 0.78, 0.15);
const vec3 HUD_ARROW_EDGE = vec3(0.25, 0.08, 0.0);

// The frame: a glow along the four edges, strongest at the edge, gone at about a ninth of the short side.
vec4 hudFrame() {
    vec2 extent = hudData.xy;
    vec2 p = abs(hudPos);
    float d = min(extent.x - p.x, extent.y - p.y);
    float width = max(min(extent.x, extent.y) * 0.22, 8.0);
    float a = 1.0 - clamp(d / width, 0.0, 1.0);
    a = a * a * 0.6;
    vec3 rgb = hudData.z > 0.5 ? HUD_FRAME_RED : HUD_FRAME_YELLOW;
    // 2 = theft during a siege: red on the upper half, yellow on the lower one (GUI y grows downwards)
    if (hudData.z > 1.5) rgb = mix(HUD_FRAME_RED, HUD_FRAME_YELLOW, smoothstep(-6.0, 6.0, hudPos.y));
    return vec4(rgb, a);
}

// The arrow: a long, narrow dart near the edge of its square, pointing at the angle (clockwise from up). Its back
// is notched (the wings reach further back than the middle), so the pointing end can never be mistaken.
vec4 hudArrow() {
    vec2 dir = vec2(sin(hudData.x), -cos(hudData.x));   // GUI y grows downwards
    float f = dot(hudPos, dir);
    float s = abs(dot(hudPos, vec2(-dir.y, dir.x)));
    float tip = 0.94, back = 0.36, notch = 0.14, halfWidth = 0.16;
    float limit = (tip - f) / (tip - back) * halfWidth;  // half width of the dart at f
    float tail = back + notch * (1.0 - clamp(s / halfWidth, 0.0, 1.0));
    float inside = min(min(f - tail, tip - f), limit - s);
    float aa = fwidth(inside) + 0.0001;
    float outer = smoothstep(-aa, aa, inside + 0.045);
    if (outer <= 0.0) return vec4(0.0);
    float fill = smoothstep(-aa, aa, inside);
    return vec4(mix(HUD_ARROW_EDGE, HUD_ARROW_FILL, fill), outer * 0.9);
}

// The spawn portal arrow of MagixPack (guide/PortalGuide, see text.vsh): the theft arrow's dart in green, pointing at
// the portal. On 26.2 and 26.3 it breathes (lighter and darker) and nudges out and back, from GameTime: 800 beats a
// GameTime cycle, one every 1.5 seconds, so no jump when it wraps.
const vec3 GUIDE_ARROW_FILL = vec3(0.24, 1.0, 0.52);
const vec3 GUIDE_ARROW_LIGHT = vec3(0.86, 1.0, 0.9);
const vec3 GUIDE_ARROW_EDGE = vec3(0.0, 0.2, 0.08);
// the pumpkin arrow of MagixHolidays (hudData.y = 1): Halloween orange
const vec3 PUMPKIN_ARROW_FILL = vec3(1.0, 0.54, 0.11);
const vec3 PUMPKIN_ARROW_LIGHT = vec3(1.0, 0.86, 0.55);
const vec3 PUMPKIN_ARROW_EDGE = vec3(0.24, 0.07, 0.0);

vec4 guideArrow() {
    float beat = 0.0;
#if MAGIX_TARGET >= 262
    beat = 0.5 + 0.5 * sin(6.28318530718 * fract(GameTime * 800.0));
#endif
    vec2 dir = vec2(sin(hudData.x), -cos(hudData.x));   // GUI y grows downwards
    vec2 p = hudPos - dir * (0.05 * beat);
    float f = dot(p, dir);
    float s = abs(dot(p, vec2(-dir.y, dir.x)));
    float tip = 0.9, back = 0.32, notch = 0.14, halfWidth = 0.18;
    float limit = (tip - f) / (tip - back) * halfWidth;
    float tail = back + notch * (1.0 - clamp(s / halfWidth, 0.0, 1.0));
    float inside = min(min(f - tail, tip - f), limit - s);
    float aa = fwidth(inside) + 0.0001;
    float outer = smoothstep(-aa, aa, inside + 0.05);
    if (outer <= 0.0) return vec4(0.0);
    float fill = smoothstep(-aa, aa, inside);
    bool pumpkin = hudData.y > 0.5;
    vec3 body = pumpkin ? mix(PUMPKIN_ARROW_FILL, PUMPKIN_ARROW_LIGHT, beat * 0.55)
                        : mix(GUIDE_ARROW_FILL, GUIDE_ARROW_LIGHT, beat * 0.55);
    return vec4(mix(pumpkin ? PUMPKIN_ARROW_EDGE : GUIDE_ARROW_EDGE, body, fill), outer * 0.95);
}

// --- MagixPack screen transition (teleports and server switches) ---------------------------------------
// A diamond wipe. The diamonds sit on two square grids, the second shifted by half a cell, TRANSITION_ROWS of
// them per screen height whatever the resolution or GUI scale. Closing, each grows from nothing to a size that
// covers its cell, the ones on the vertical centre line first, the ones at the sides TRANSITION_SPREAD later;
// opening, they shrink back in the same order. hudData: half screen size in GUI pixels (xy), progress 0..255
// (z), 1 = opening (w). THIS BLOCK IS COPIED IDENTICAL in MagixPack's text.fsh (the hub has no MagixFactions):
// if it changes, change both.
const float TRANSITION_ROWS = 12.0;
const float TRANSITION_SPREAD = 1.2;

// Radius (in cells, 0.5 = the cell covered) of the diamond centred at `cell` (in cells from the screen centre).
float transitionRadius(vec2 cell, float cellSize, float t, bool opening) {
    float side = clamp(abs(cell.x) * cellSize / max(hudData.x, 1.0), 0.0, 1.0);
    float grown = clamp(t * (1.0 + TRANSITION_SPREAD) - TRANSITION_SPREAD * side, 0.0, 1.0);
    return (opening ? 1.0 - grown : grown) * 0.52;
}

float transitionCover(float dist, float radius, float aa) {
    return radius > 0.0 ? 1.0 - smoothstep(-aa, aa, dist - radius) : 0.0;
}

vec4 hudTransition() {
    float t = hudData.z / 255.0;
    bool opening = hudData.w > 0.5;
    if (!opening && t >= 1.0) return vec4(0.0, 0.0, 0.0, 1.0);
    float cellSize = max(hudData.y * 2.0 / TRANSITION_ROWS, 4.0);
    vec2 q = hudPos / cellSize;
    vec2 a = round(q);                 // grid through the screen centre
    vec2 b = floor(q) + 0.5;           // grid shifted by half a cell
    float aa = fwidth(q.x) + 0.0001;
    float cover = max(
            transitionCover(abs(q.x - a.x) + abs(q.y - a.y), transitionRadius(a, cellSize, t, opening), aa),
            transitionCover(abs(q.x - b.x) + abs(q.y - b.y), transitionRadius(b, cellSize, t, opening), aa));
    return vec4(0.0, 0.0, 0.0, cover);
}

// --- MagixPack shield bar (the few seconds of protection after a teleport) -------------------------------------
// A thin timer bar under the crosshair: a dark track with a soft edge and, from the left, a green fill as long as
// what is left (hudData.z 0..255), lighter at its head. hudPos: -1..1 across the bar; hudData.xy: its half size in
// GUI pixels. THIS BLOCK IS COPIED IDENTICAL in the other text.fsh (MagixFactions' on the faction, MagixPack's on
// the hub): if it changes, change both.
const vec3 SHIELD_FILL_FROM = vec3(0.12, 0.72, 0.4);
const vec3 SHIELD_FILL_TO = vec3(0.55, 1.0, 0.74);

vec4 shieldBar() {
    vec2 bh = hudData.xy;
    vec2 p = hudPos * bh;
    float r = bh.y;
    vec2 q = abs(p) - (bh - vec2(r));
    float dist = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;   // < 0 inside the rounded bar
    float aa = fwidth(p.x) + 0.0001;
    float body = 1.0 - smoothstep(-aa, aa, dist);
    if (body <= 0.0) return vec4(0.0);
    float left = clamp(hudData.z / 255.0, 0.0, 1.0);
    float head = -bh.x + 2.0 * bh.x * left;                        // where the fill ends
    float fill = (1.0 - smoothstep(-aa, aa, p.x - head)) * (1.0 - smoothstep(-aa, aa, dist + 1.0));
    float along = clamp((p.x + bh.x) / max(2.0 * bh.x, 1.0), 0.0, 1.0);
    vec3 rgb = mix(SHIELD_FILL_FROM, SHIELD_FILL_TO, along);
    rgb += vec3(0.35) * exp(-abs(p.x - head) * 0.6) * step(0.001, left);   // a light at the head
    rgb += vec3(0.12) * (1.0 - smoothstep(-r, 0.0, p.y + r * 0.2));       // a highlight on the upper half
    vec4 track = vec4(0.02, 0.07, 0.05, 0.55);
    return vec4(mix(track.rgb, rgb, fill), mix(track.a, 0.95, fill) * body);
}

// --- The boss's combo bar (MagixFactions boss/Combos) -----------------------------------------------------------
// Like the shield bar, in gold: a dark track and, from the left, a fill as long as the combo (hudData.z 0..255: 20%
// for one blow of five, 100% at combo.max-hits). Full, it pulses: brighter and a halo that breathes every 0.8 s.
const vec3 COMBO_FILL_FROM = vec3(1.0, 0.55, 0.05);
const vec3 COMBO_FILL_TO = vec3(1.0, 0.92, 0.3);

vec4 comboBar() {
    vec2 bh = hudData.xy;
    vec2 p = hudPos * bh;
    float r = bh.y;
    vec2 q = abs(p) - (bh - vec2(r));
    float dist = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;   // < 0 inside the rounded bar
    float aa = fwidth(p.x) + 0.0001;
    float full = clamp(hudData.z / 255.0, 0.0, 1.0);
    float pulse = 0.0;
#if MAGIX_TARGET >= 262
    pulse = step(0.995, full) * (0.5 + 0.5 * sin(6.28318530718 * fract(GameTime * 1500.0)));   // every 16 ticks
#endif
    float halo = pulse * (1.0 - smoothstep(0.0, 3.0, dist)) * step(0.0, dist);
    float body = 1.0 - smoothstep(-aa, aa, dist);
    if (body <= 0.0 && halo <= 0.0) return vec4(0.0);
    float head = -bh.x + 2.0 * bh.x * full;                        // where the fill ends
    float fill = (1.0 - smoothstep(-aa, aa, p.x - head)) * (1.0 - smoothstep(-aa, aa, dist + 1.0));
    float along = clamp((p.x + bh.x) / max(2.0 * bh.x, 1.0), 0.0, 1.0);
    vec3 rgb = mix(COMBO_FILL_FROM, COMBO_FILL_TO, along);
    rgb += vec3(0.35) * exp(-abs(p.x - head) * 0.6) * step(0.001, full) * (1.0 - step(0.995, full));
    rgb += vec3(0.12) * (1.0 - smoothstep(-r, 0.0, p.y + r * 0.2));
    rgb += vec3(0.35, 0.3, 0.15) * pulse;
    vec4 track = vec4(0.08, 0.05, 0.01, 0.55);
    vec4 bar = vec4(mix(track.rgb, rgb, fill), mix(track.a, 0.95, fill) * body);
    return bar.a >= halo * 0.6 ? bar : vec4(1.0, 0.85, 0.3, halo * 0.6);
}

// --- MagixPack AFK screen (afk/AfkScreen: a player MagixGuard marks as idle) -------------------------------------
// The screen looks frozen: a cold veil over everything, thicker towards the edges, frost growing in from the four
// sides with a few glints that come and go, a light blue border just inside the edge that breathes slowly, and a
// darker band where the three lines of words are (text.vsh puts them there, AFK_LINE*_TOP). hudPos: GUI pixels from
// the screen centre; hudData: half screen size in GUI pixels (xy), seconds (z). THIS BLOCK IS COPIED IDENTICAL in
// MagixFactions' and MagixPack's text.fsh: if it changes, change both.
const vec3 AFK_VEIL = vec3(0.60, 0.82, 0.95);
const vec3 AFK_FROST = vec3(0.88, 0.96, 1.0);
const vec3 AFK_BORDER = vec3(0.40, 0.86, 1.0);
const vec3 AFK_BAND = vec3(0.02, 0.08, 0.15);
const float AFK_BORDER_INSET = 5.0;    // GUI pixels from the screen's edge to the border's middle
const float AFK_FROST_DEPTH = 30.0;    // how far the frost reaches in from the edges, GUI pixels

float afkHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float afkNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(afkHash(i), afkHash(i + vec2(1.0, 0.0)), f.x),
            mix(afkHash(i + vec2(0.0, 1.0)), afkHash(i + vec2(1.0, 1.0)), f.x), f.y);
}

float afkFbm(vec2 p) {
    float n = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        n += a * afkNoise(p);
        p = p * 2.07 + vec2(17.3, 9.1);
        a *= 0.5;
    }
    return n;
}

// `rgb` with alpha `a` laid over `under` (straight alpha).
vec4 afkOver(vec4 under, vec3 rgb, float a) {
    float out_a = a + under.a * (1.0 - a);
    vec3 out_rgb = (rgb * a + under.rgb * under.a * (1.0 - a)) / max(out_a, 0.0001);
    return vec4(out_rgb, out_a);
}

vec4 afkScreen() {
    vec2 half_ = max(hudData.xy, vec2(1.0));
    vec2 p = hudPos;
    float t = hudData.z;
    float edge = min(half_.x - abs(p.x), half_.y - abs(p.y));   // GUI pixels to the nearest edge
    float aa = max(fwidth(p.x), 0.0001);
    // the cold veil, thicker towards the corners
    float vignette = smoothstep(0.3, 1.3, length(p / half_));
    vec4 c = vec4(AFK_VEIL, 0.16 + 0.30 * vignette);
    // the darker band under the words
    float band = 1.0 - smoothstep(34.0, 58.0, abs(p.y + 6.0));
    c = afkOver(c, AFK_BAND, band * 0.42);
    // frost growing in from the edges: ragged, in streaks
    float grain = afkFbm(p / 9.0) * 0.65 + afkFbm(vec2(p.x + p.y, p.x - p.y) / 3.5) * 0.35;
    float reach = AFK_FROST_DEPTH * (0.45 + 0.9 * grain);
    float frost = 1.0 - smoothstep(reach * 0.55, reach, edge);
    c = afkOver(c, AFK_FROST, frost * (0.35 + 0.4 * grain));
    // glints in the frost, each one on and off on its own
    vec2 cell = floor(p / 3.0);
    float seed = afkHash(cell);
    float twinkle = pow(max(0.0, sin(t * (0.6 + seed * 1.4) + seed * 40.0)), 24.0);
    float dot_ = 1.0 - smoothstep(0.15, 0.9, length(fract(p / 3.0) - 0.5) * 2.0);   // a soft round point
    c = afkOver(c, vec3(1.0), frost * step(0.95, seed) * twinkle * dot_);
    // the light blue border, with its glow on both sides, breathing every 4 seconds
    float d = abs(edge - AFK_BORDER_INSET);
    float breath = 0.75 + 0.25 * sin(t * 1.5707963);
    float line = 1.0 - smoothstep(0.9 - aa, 0.9 + aa, d);
    float glow = exp(-d * 0.28) * 0.55 * breath;
    c = afkOver(c, AFK_BORDER, max(line, glow));
    c = afkOver(c, vec3(1.0), line * 0.35 * breath);
    return c;
}
#endif

#ifdef IS_GUI
// Pictures drawn SMALLER than their texels (the scoreboard's level shield: 120 rows shown about 45 pixels tall) lose
// rows at random with the font's nearest sampling, and their stripes come out crooked. Their opaque texels carry
// alpha SMOOTH_MARK (254, the level shields of MagixPack's glyphs/level_<n>.png): there, when a screen pixel covers
// more than 1.25 texels, the texels under it are averaged (4 x 4 samples, alpha-weighted). Anything else, and the same
// picture drawn big (the level up title), stays exactly as before.
const int SMOOTH_MARK = 254;

vec4 smoothMark(vec4 tex, vec2 uv, vec2 foot) {
    if (int(round(tex.a * 255.0)) != SMOOTH_MARK || max(foot.x, foot.y) < 1.25) return tex;
    vec2 step = min(foot, vec2(8.0)) / vec2(textureSize(Sampler0, 0)) / 4.0;
    vec4 sum = vec4(0.0);
    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 4; x++) {
            vec4 s = textureLod(Sampler0, uv + (vec2(x, y) - 1.5) * step, 0.0);
            sum += vec4(s.rgb * s.a, s.a);
        }
    }
    sum /= 16.0;
    return sum.a > 0.0 ? vec4(sum.rgb / sum.a, sum.a) : vec4(0.0);
}
#endif

#if defined(IS_GUI) && MAGIX_TARGET >= 262 && !defined(IS_GRAYSCALE)
// --- MagixPack Store box of the pause screen: a light running clockwise round its border --------------------
// A glyph's texture cannot be animated, so the light is drawn here. menu/PauseScreen marks the box's border:
// alpha 253 = the violet ring, 252 = the pixels just outside and inside it, and the 3 low bits of red, green and
// blue hold the pixel's place along the border (0..511 = one lap, clockwise from the top-left corner). Soft edges
// of other pictures (menu frame, logos, glyphs) are full of 252 next to 253, so a pixel counts only when it is
// really the box's: a ring pixel (253) has the ring's own violet in its 5 high bits (STORE_GLOW_RING, BORDER of
// PauseScreen) and a 252 neighbour whose place is at most STORE_GLOW_NEAR steps away; a 252 pixel has such a ring
// pixel next to it. Until MagixPack 0.32.5 a 252 next to any 253 was enough: whole pictures shimmered.
// GameTime (globals.glsl) is 1/24000 a tick, partial tick included: 1200 seconds a cycle, a whole number of laps
// in it, so no jump when it wraps.
// THIS BLOCK IS COPIED IDENTICAL in MagixPack's and MagixFactions' text.fsh: if it changes, change both.
const float STORE_GLOW_LAPS = 400.0;     // laps a GameTime cycle: one lap every 3 seconds
const float STORE_GLOW_TAIL = 0.24;      // the trail behind the light, a part of the lap
const float STORE_GLOW_FRONT = 0.012;    // the soft front of the light
const vec3 STORE_GLOW_HEAD = vec3(1.0, 0.96, 0.82);
const vec3 STORE_GLOW_TRAIL = vec3(1.0, 0.45, 0.92);

const ivec3 STORE_GLOW_RING = ivec3(0x98, 0x58, 0xD0);  // the ring's violet, 5 high bits (PauseScreen BORDER)
const int STORE_GLOW_NEAR = 4;           // most steps between a marked pixel and its neighbour on the other side

bool storeGlowRing(ivec4 c) {
    return c.a == 253 && (c.rgb & ivec3(0xF8)) == STORE_GLOW_RING;
}

int storeGlowPlace(ivec4 c) {
    return (c.r & 7) | ((c.g & 7) << 3) | ((c.b & 7) << 6);
}

vec4 storeGlow(vec4 tex) {
    ivec4 c = ivec4(round(tex * 255.0));
    if (c.a != 253 && c.a != 252) return tex;
    if (c.a == 253 && !storeGlowRing(c)) return tex;
    int other = c.a == 253 ? 252 : 253;
    int place = storeGlowPlace(c);
    ivec2 texel = ivec2(texCoord0 * vec2(textureSize(Sampler0, 0)));
    bool marked = false;
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            ivec4 n = ivec4(round(texelFetch(Sampler0, texel + ivec2(dx, dy), 0) * 255.0));
            if (n.a != other || (other == 253 && !storeGlowRing(n))) continue;
            int apart = abs(storeGlowPlace(n) - place);
            if (min(apart, 512 - apart) <= STORE_GLOW_NEAR) marked = true;
        }
    }
    if (!marked) return tex;
    float at = (float(place) + 0.5) / 512.0;
    float head = fract(GameTime * STORE_GLOW_LAPS);
    float behind = fract(head - at);
    float ahead = fract(at - head);
    float trail = behind < STORE_GLOW_TAIL ? pow(1.0 - behind / STORE_GLOW_TAIL, 2.0) : 0.0;
    float front = ahead < STORE_GLOW_FRONT ? 1.0 - ahead / STORE_GLOW_FRONT : 0.0;
    float k = max(trail, front * front);
    vec3 light = mix(STORE_GLOW_TRAIL, STORE_GLOW_HEAD, max(trail * trail * trail, front));
    return vec4(mix(tex.rgb, light, k * (c.a == 253 ? 1.0 : 0.6)), 1.0);
}
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
LOC(4) in vec2 uvCoord;
LOC(5) flat in int custom;

// Frecce dei giocatori (decodificate nel vertex shader dall'header). .xy = pixel-mappa, .z = angolo,
// .w = tipo (0 tu / 1 fazione / 2 alleato / 3 nemico) oppure < 0 = slot vuoto. ARROW_MAX combacia col
// vertex shader e con MapService.ARROW_MAX.
#define ARROW_MAX 6
LOC(6) flat in vec4 arrows[ARROW_MAX];   // locations 6..11
#endif

// Cornice della minimap a due tinte (bordo esterno piu' scuro, interno = colore scelto), per restare
// leggibile su qualunque terreno sotto. Colore e spessore sono sostituiti dal plugin dai placeholder
// __BORDER_R/G/B__ e 3.0 (config map.minimap.border-color / border-size). Il bordo esterno
// e' lo stesso colore scurito (x0.44) -> effetto in rilievo automatico.
const vec4 BORDER_INNER = vec4(0.3529, 0.3529, 0.3529, 1.0);
const vec4 BORDER_OUTER = vec4(BORDER_INNER.rgb * 0.44, 1.0);
const float RADIUS = 58.0;                  // raggio del contenuto mappa (in pixel della mappa, centro a 64,64)
const float BORDER_WIDTH = 3.0; // spessore della cornice (px), oltre RADIUS

// Le prime 2 righe della map texture contengono i BIT delle frecce (header): vanno sempre nascoste.
// Sulla minimap rotonda cadono gia' fuori dal cerchio; sulla quadrata le nascondiamo esplicitamente
// (indipendentemente dallo spessore cornice) sotto.
const float HEADER_ROWS = 2.0;

// Forma minimap: 1 e' sostituito dal plugin (0 = rotonda, 1 = quadrata) da config map.minimap.shape.
#define SQUARE 1
// Levigatura smart dei bordi: 1 e' sostituito dal plugin (1 = stile "magix", 0 = "vanilla"
// puro, pixel nudi) da config map.style.
#define SMOOTH 1

// Pannello info (custom==3): colore-CHIAVE dello sfondo trasparente. Lo shader scarta SEMPRE i pixel di
// questo colore (fisso, InfoPanelRenderer.TRANSPARENT_KEY): cosi' "trasparente vs riquadro pieno" e' una
// scelta LIVE del renderer (fondo = chiave -> scartato; fondo = colore vero -> resta), senza riavvio. Un
// colore di riquadro vero non coincide mai col magenta-chiave, quindi il riquadro pieno funziona lo stesso.
// __PANEL_KEY_*__ = RGB EFFETTIVO reso dalla palette dal byte-chiave (non il magenta teorico), sostituito
// dal plugin cosi' il confronto e' esatto.
const vec3 PANEL_KEY = vec3(0.6980, 0.2980, 0.8471);

// --- Frecce dei giocatori (minimap): SPRITE del cursore-mappa VANILLA -----------------------------
// Copia PIXEL-PER-PIXEL della texture ufficiale del cursore giocatore di Minecraft
// (assets/minecraft/textures/map/decorations/player.png, 8x8 — estratta dal client e ricodificata
// qui, non ricostruita a memoria): contorno nero, corpo con TRE livelli di ombreggiatura
// (255 / 224 / 188, l'effetto "in rilievo" del cursore vero). Stessa scala del nativo (1 px-sprite =
// 1 px-mappa, come gli 8x8 sui 128 dell'item in mano) e rotazione rigida: la forma non cambia MAI,
// a qualsiasi angolo — i cursori nativi veri non si possono agganciare alla minimap HUD (vedi
// MapContentBuilder), quindi lo sprite lo campioniamo qui, identico.
// Ogni freccia arriva gia' decodificata dal vertex shader (posizione pixel-mappa, angolo, tipo).
// Convenzione mappa: la direzione di sguardo e' (-sin(yaw), cos(yaw)) con +x=est, +y=sud.
//
// Sprite 8x8, riga 0 = punta, 3 bit per colonna (LSB = colonna 0): 0=trasparente, 1=contorno NERO,
// 2=corpo pieno (lum 255), 3=corpo medio (224), 4=corpo scuro (188). Layout della texture ufficiale
// (B=nero, X=255, W=224, g=188, .=vuoto):
//   row0: . . . . B . . .
//   row1: . . . B g B . .
//   row2: . . B g W g B .
//   row3: . . B W X W B .
//   row4: . . B W X W B .
//   row5: . . B g W g B .
//   row6: . . . B B B . .
//   row7: . . . . . . . .
const int ARROW_SPRITE[8] = int[8](4096, 49664, 407616, 370240, 370240, 407616, 37376, 0);

// Colore del corpo per tipo. Combacia coi cursori nativi della mappa-item (bianco/verde/blu/rosso),
// cosi' le due mappe restano identiche. L'ombreggiatura dello sprite MOLTIPLICA questo colore (per
// gli altri giocatori la freccia e' la stessa ma tinta, come le varianti colorate dei cursori nativi).
vec3 arrowColor(int t) {
    if (t == 0) return vec3(1.0);               // tu: bianco (come il cursore PLAYER)
    if (t == 1) return vec3(0.33, 0.85, 0.33);  // stessa fazione: verde
    if (t == 2) return vec3(0.36, 0.62, 1.0);   // alleato: blu
    return vec3(1.0, 0.33, 0.33);               // nemico: rosso
}

// --- Upscaling "intelligente" del contenuto minimap (stile Scale2x/cleanEdge) ---------------------
// La mappa e' 128x128 FISSI (limite Minecraft) e viene ingrandita parecchio a schermo: col campionamento
// nearest puro le diagonali (coste, fiumi, confini) mostrano le "scalette" dei pixel. Qui, per ogni
// fragment, guardiamo i vicini del texel: se i due vicini adiacenti all'angolo sono UGUALI tra loro e
// diversi dal texel centrale (= angolo di una scaletta), l'angolo viene TAGLIATO a 45° col colore dei
// vicini -> la scaletta diventa una linea continua liscia. E' la stessa classe di ricostruzione-bordi
// degli upscaler pixel-art (Scale2x/xBR): niente sfocatura (il bilineare "annebbiava", gia' bocciata),
// i colori restano netti, solo i gradini spariscono. Le guardie sugli opposti (regola Scale2x) proteggono
// linee da 1px e pattern del dithering dall'essere "mangiati".
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
vec3 mapTexel(ivec2 t) {
    return texelFetch(Sampler0, clamp(t, ivec2(0), ivec2(127)), 0).rgb;
}

bool sameCol(vec3 a, vec3 b) {
    return dot(abs(a - b), vec3(1.0)) < 0.004;
}

vec3 smartSample(vec2 uv) {
    ivec2 c = ivec2(clamp(uv, vec2(0.0), vec2(127.999)));
    vec2 f = fract(uv);
    vec3 E = mapTexel(c);
    ivec2 sx = ivec2(f.x < 0.5 ? -1 : 1, 0);            // vicino orizzontale dal lato del quadrante
    ivec2 sy = ivec2(0, f.y < 0.5 ? -1 : 1);            // vicino verticale dal lato del quadrante
    vec3 H  = mapTexel(c + sx);
    vec3 V  = mapTexel(c + sy);
    vec3 Ho = mapTexel(c - sx);                          // opposti: guardie anti-distruzione linee sottili
    vec3 Vo = mapTexel(c - sy);
    vec2 g = vec2(f.x < 0.5 ? f.x : 1.0 - f.x, f.y < 0.5 ? f.y : 1.0 - f.y); // distanza dall'angolo
    if (sameCol(H, V) && !sameCol(H, E) && !sameCol(V, Ho) && !sameCol(H, Vo) && g.x + g.y < 0.5) {
        return H;                                        // taglio a 45°: il gradino diventa diagonale liscia
    }
    return E;
}
#endif

// Campiona lo sprite del cursore centrato sul pixel-mappa `center`, ruotato di `angle`, corpo `col`.
vec3 drawArrow(vec3 base, vec2 uv, vec2 center, float angle, vec3 col) {
    vec2 p = uv - center;
    vec2 dir = vec2(-sin(angle), cos(angle));       // direzione di sguardo sulla mappa
    vec2 perp = vec2(dir.y, -dir.x);
    float sx = dot(p, perp) + 4.0;                   // colonna sprite (0..8), centro sprite = posizione
    float sy = dot(p, -dir) + 4.0;                   // riga sprite (0 = punta, verso la direzione di sguardo)
    if (sx < 0.0 || sx >= 8.0 || sy < 0.0 || sy >= 8.0) return base;
    int v = (ARROW_SPRITE[int(sy)] >> (int(sx) * 3)) & 7;
    if (v == 0) return base;                         // trasparente
    if (v == 1) return vec3(0.0);                    // contorno nero
    float lum = v == 2 ? 1.0 : (v == 3 ? 0.8784 : 0.7373); // 255 / 224 / 188 della texture ufficiale
    return col * lum;
}

#ifdef IS_GUI
// --- MagixFactions minimap on the interface (see MINI_MARK_BLUE in text.vsh): the pieces drawn ----------------------
LOC(7) flat in vec4 miniData;
// the home marker (HOME_GLYPH of MapContentBuilder) and the compass letters N S W E (GLYPH_N.. there), 5 rows each,
// the left column in the top bit
const int MINI_GLYPHS[25] = int[25](5, 7, 7, 7, 5,  7, 4, 7, 1, 7,  5, 5, 5, 7, 5,  7, 4, 7, 4, 7,  4, 14, 31, 21, 31);
const vec2 MINI_COMPASS_AT[4] = vec2[4](vec2(63.0, 13.0), vec2(63.0, 110.0), vec2(13.0, 62.0), vec2(112.0, 62.0));
const vec3 MINI_HOME_FILL = vec3(1.0000, 0.6667, 0.0000);
const vec3 MINI_RAID_HOME_FILL = vec3(1.0000, 0.3333, 0.3333);   // the home of the faction being besieged (raids)
const vec4 MINI_PANEL_SHADOW = vec4(0.0745, 0.0431, 0.0314, 1.0);   // alpha 0 = no shadow under the panel's letters

// 2 = ink of the 1-bit picture (its rows from MINI_GLYPHS[first], width columns, 5 rows), 1 = the black edge round
// it, 0 = nothing; l = the pixel from the picture's top left.
int miniGlyph(ivec2 l, int first, int width) {
    if (l.x < -1 || l.x > width || l.y < -1 || l.y > 5) return 0;
    int found = 0;
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            int x = l.x + dx, y = l.y + dy;
            if (x < 0 || x >= width || y < 0 || y >= 5) continue;
            if (((MINI_GLYPHS[first + y] >> (width - 1 - x)) & 1) == 1) found = max(found, dx == 0 && dy == 0 ? 2 : 1);
        }
    }
    return found;
}

// The fragment of a minimap piece (hudMode 9): the colour, or discard. p = the fragment in map pixels. On the round
// minimap everything beyond the circle goes; the frame is drawn last by the compass piece on the square one, and the
// arrows keep off it.
vec4 miniPiece() {
    int sub = int(miniData.w + 0.5);
    vec2 p = hudPos;
    vec3 c = vertexColor.rgb;
    if (sub == 5) return vec4(c, 1.0);
    if (sub == 6) {
        vec2 ts = vec2(textureSize(Sampler0, 0));
#ifdef IS_GRAYSCALE
        float ink = texture(Sampler0, texCoord0).r;
        float under = texture(Sampler0, texCoord0 - 1.0 / ts).r;
#else
        float ink = texture(Sampler0, texCoord0).a;
        float under = texture(Sampler0, texCoord0 - 1.0 / ts).a;
#endif
        // only texels of the letter's own ink area count (8 rows, its width): the frame round it carries marks, and
        // past it lies whatever the client packed next to the glyph in its atlas (on some clients opaque: black
        // bars and blocks over the panel's words, 25/10)
        vec2 l = p - hudData.xy;
        bool inkHere = l.x >= 0.0 && l.x < hudData.z && l.y >= 0.0 && l.y < 8.0;
        bool inkUnder = l.x >= 1.0 && l.x < hudData.z + 1.0 && l.y >= 1.0 && l.y < 9.0;
        if (inkHere && ink > 0.5) return vec4(c, 1.0);
        if (MINI_PANEL_SHADOW.a > 0.0 && inkUnder && under > 0.5) return vec4(MINI_PANEL_SHADOW.rgb, 1.0);
        discard;
    }
    float dist = length(p - 64.0);
    float edge = min(min(p.x, 128.0 - p.x), min(p.y, 128.0 - p.y));
    if (sub == 4) {
#if SQUARE
        if (edge < BORDER_WIDTH) {
            float t = BORDER_WIDTH > 0.001 ? clamp(edge / BORDER_WIDTH, 0.0, 1.0) : 1.0;
            return mix(BORDER_OUTER, BORDER_INNER, t);
        }
#else
        if (dist > RADIUS + BORDER_WIDTH) discard;
        if (dist > RADIUS) return mix(BORDER_INNER, BORDER_OUTER, (dist - RADIUS) / BORDER_WIDTH);
#endif
        for (int i = 0; i < 4; i++) {
            int g = miniGlyph(ivec2(floor(p - MINI_COMPASS_AT[i])), i * 5, 3);
            if (g == 2) return vec4(1.0);
            if (g == 1) return vec4(0.0, 0.0, 0.0, 1.0);
        }
        discard;
    }
#if SQUARE
    if (p.x < 0.0 || p.x > 128.0 || p.y < 0.0 || p.y > 128.0) discard;
    if (sub == 2 && edge < BORDER_WIDTH) discard;
#else
    if (dist > RADIUS) discard;
#endif
    if (sub == 0) {
        // a hair past the run's rect on every side: two rows or runs meeting on a screen pixel's centre both dropped
        // it and a seam of the world showed between them
        vec4 r = hudData + vec4(-0.02, -0.02, 0.02, 0.02);
        if (p.x < r.x || p.x > r.z || p.y < r.y || p.y > r.w) {
            // outside the run: only its ears (the triangle at a corner of the cell beyond an end, half a cell wide)
            int ears = int(miniData.x + 0.5);
            float h = miniData.y * 0.5;
            bool ok = false;
            if (p.x > r.z) {
                ok = ((ears & 4) != 0 && p.y >= r.y && (p.x - r.z) + (p.y - r.y) < h)
                        || ((ears & 8) != 0 && p.y <= r.w && (p.x - r.z) + (r.w - p.y) < h);
            } else if (p.x < r.x) {
                ok = ((ears & 1) != 0 && p.y >= r.y && (r.x - p.x) + (p.y - r.y) < h)
                        || ((ears & 2) != 0 && p.y <= r.w && (r.x - p.x) + (r.w - p.y) < h);
            }
            if (!ok) discard;
        }
        return vec4(c, 1.0);
    }
    if (sub == 1) {
        vec4 r = hudData;
        int sides = int(miniData.x + 0.5);
        bool line = ((sides & 1) != 0 && p.x < r.x + 1.0) || ((sides & 2) != 0 && p.x > r.z - 1.0)
                || ((sides & 4) != 0 && p.y < r.y + 1.0) || ((sides & 8) != 0 && p.y > r.w - 1.0);
        if (!line) discard;
        return vec4(c, 1.0);
    }
    if (sub == 2) {
        // the player's arrow: the map cursor's sprite (ARROW_SPRITE), as drawArrow does on the map minimap
        vec2 dir = vec2(-sin(hudData.z), cos(hudData.z));
        vec2 perp = vec2(dir.y, -dir.x);
        vec2 d = p - hudData.xy;
        float sx = dot(d, perp) + 4.0, sy = dot(d, -dir) + 4.0;
        if (sx < 0.0 || sx >= 8.0 || sy < 0.0 || sy >= 8.0) discard;
        int v = (ARROW_SPRITE[int(sy)] >> (int(sx) * 3)) & 7;
        if (v == 0) discard;
        if (v == 1) return vec4(0.0, 0.0, 0.0, 1.0);
        float lum = v == 2 ? 1.0 : (v == 3 ? 0.8784 : 0.7373);
        return vec4(arrowColor(int(hudData.w + 0.5)) * lum, 1.0);
    }
    // sub 3: the home (hudData.z = the home of the faction being besieged)
    int g = miniGlyph(ivec2(floor(p - hudData.xy)) - 1, 20, 5);
    if (g == 2) return vec4(hudData.z > 0.5 ? MINI_RAID_HOME_FILL : MINI_HOME_FILL, 1.0);
    if (g == 1) return vec4(0.0, 0.0, 0.0, 1.0);
    discard;
}
#endif


#ifdef IS_GUI
// --- MagixPack CINEMA: the newcomers' film (cinematic/CinematicTour, CINE_BARS_BLUE of text.vsh) -----------------
// hudMode 10: the black bars at the top and the bottom coming in with hudData.z (0..255, eased), their full height
// hudData.w, a thin warm line on their inner edge and a soft vignette over the picture; hudMode 11: the whole screen
// black by hudData.z (the cuts between the scenes). hudPos: GUI pixels from the screen centre, hudData.xy its half.
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.fsh: if it changes, change both.
const vec3 CINE_EDGE_LINE = vec3(0.80, 0.64, 0.34);

vec4 cinemaScreen(bool black) {
    float k = clamp(hudData.z / 255.0, 0.0, 1.0);
    if (black) return vec4(0.0, 0.0, 0.0, k);
    float eased = k * k * (3.0 - 2.0 * k);
    vec2 h = max(hudData.xy, vec2(1.0));
    float bar = hudData.w * eased;
    float edge = h.y - abs(hudPos.y);                 // GUI pixels to the nearest top or bottom edge
    float aa = max(fwidth(hudPos.y), 0.0001);
    float inBar = bar > 0.0 ? 1.0 - smoothstep(bar - aa, bar + aa, edge) : 0.0;
    float vignette = smoothstep(0.6, 1.5, length(hudPos / h * vec2(1.0, 0.8))) * 0.42 * eased;
    float a = max(inBar, vignette);
    float line = (1.0 - smoothstep(0.0, aa + 0.5, abs(edge - bar))) * 0.4 * eased;
    float outA = line + a * (1.0 - line);
    return vec4(CINE_EDGE_LINE * line / max(outA, 0.0001), outA);
}

// hudMode 12: the film's pointer (CINE_RECT_BLUE / CINE_ANCHOR_BLUE of text.vsh). hudPos: GUI pixels from the framed
// tile's centre (hudData.w 0, hudData.xy its half size) or from the arrow's tip (hudData.w 1, hudData.xy the way it
// points); hudData.z seconds. A gold arrow with a dark rim and a soft light, bobbing towards its target; a framed tile
// gets a pulsing gold border with its glow.
const vec3 CINE_POINT_GOLD = vec3(1.0, 0.80, 0.30);
const vec3 CINE_POINT_LIGHT = vec3(1.0, 0.97, 0.84);
const vec3 CINE_POINT_RIM = vec3(0.16, 0.08, 0.0);

// Signed distance (about, GUI pixels) to an arrow whose tip is at the origin, pointing along +x.
float cinemaArrow(vec2 p) {
    float head = max(max(p.x, -p.x - 11.0), (abs(p.y) + p.x * 0.75) * 0.8);
    float shaft = max(max(-p.x - 22.0, p.x + 10.0), abs(p.y) - 2.6);
    return min(head, shaft);
}

vec4 cinemaPointerColor(vec2 p, vec2 dir, float t) {
    float bob = 2.5 + 2.5 * sin(t * 6.2831853 * 0.9);
    vec2 q = p + dir * bob;
    vec2 a = vec2(dot(q, dir), dot(q, vec2(-dir.y, dir.x)));
    float d = cinemaArrow(a / 1.4) * 1.4;
    float aa = max(fwidth(d), 0.001);
    float fill = 1.0 - smoothstep(-aa, aa, d);
    float rim = 1.0 - smoothstep(-aa, aa, d - 1.0);
    vec3 rgb = mix(CINE_POINT_LIGHT, CINE_POINT_GOLD, clamp(-a.x / 22.0, 0.0, 1.0));
    float glow = exp(-max(d, 0.0) / 3.0) * 0.45 * (0.75 + 0.25 * sin(t * 6.2831853));
    vec4 c = vec4(CINE_POINT_GOLD, glow * (1.0 - rim));
    c = vec4(mix(c.rgb, CINE_POINT_RIM, rim), max(c.a, rim));
    return vec4(mix(c.rgb, rgb, fill), max(c.a, fill));
}

vec4 cinemaPointer() {
    float t = hudData.z;
    if (hudData.w > 0.5) return cinemaPointerColor(hudPos, normalize(hudData.xy), t);
    vec2 half_ = hudData.xy;
    vec2 q = abs(hudPos) - half_ + 2.0;
    float box = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - 2.0;   // < 0 inside the rounded frame
    float aa = max(fwidth(box), 0.001);
    float pulse = 0.65 + 0.35 * sin(t * 6.2831853 * 0.8);
    float line = 1.0 - smoothstep(0.6 - aa, 0.6 + aa, abs(box));
    float glow = box > 0.0 ? exp(-box / 4.0) * 0.55 * pulse : 0.0;
    float inside = box < 0.0 ? 0.10 * pulse : 0.0;
    vec4 c = vec4(CINE_POINT_GOLD, max(max(glow, inside), line));
    c.rgb = mix(c.rgb, CINE_POINT_LIGHT, line * pulse);
    // the arrow beside the window, pointing at the tile's row (its tip hudData.w * 1000 from the tile's centre)
    float tip = hudData.w * 1000.0;
    vec4 arrow = cinemaPointerColor(hudPos - vec2(tip, 0.0), vec2(tip > 0.0 ? -1.0 : 1.0, 0.0), t);
    return vec4(mix(c.rgb, arrow.rgb, arrow.a), arrow.a + c.a * (1.0 - arrow.a));
}
#endif

void main() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    // IMPORTANTE (bug "mappa cartacea beige"): gl_FragDepth va scritto in OGNI percorso di esecuzione di
    // QUESTA variante, non solo nel ramo della minimap. In GLSL, se un fragment shader scrive gl_FragDepth
    // in un ramo ma non in un altro, la profondita' dei fragment che NON lo scrivono e' INDEFINITA ->
    // falliscono il depth test in modo imprevedibile. La mappa cartacea in mano (custom==0) veniva percio'
    // resa beige appena il resource pack era attivo. Impostando qui il depth di default (quello
    // dell'hardware) per TUTTI i fragment di questa variante, il ramo minimap puo' poi sovrascriverlo
    // senza rompere il resto.
    gl_FragDepth = gl_FragCoord.z;

    // MagixFactions minimap: se questo e' il quad della minimap (custom==1), ritaglia in CERCHIO o
    // QUADRATO. Il centro (64,64) e' sempre il giocatore (la mappa e' ricentrata su di lui ad ogni
    // refresh). L'header (prime 2 righe) resta fuori dall'area visibile e non si vede.
    if (custom == 1) {
        // Forza il depth al valore piu' VICINO alla camera, cosi' la minimap sta SEMPRE davanti ai blocchi.
        // FIX 26.2 (2026-07-23, causa CONFERMATA del "la minimap si nasconde dietro i blocchi"): da MC 26.2
        // il depth e' REVERSED-Z (verificato nel client jar: DepthStencilState/RenderPipelines usano il test
        // GREATER_THAN_OR_EQUAL, e clip-space ZERO_TO_ONE) -> "vicino" = 1.0, "lontano" = 0.0, e passa il
        // fragment con depth MAGGIORE. Il vecchio gl_FragDepth = 0.0 (vicino sotto la convenzione classica)
        // ora e' il valore piu' LONTANO -> perde contro qualunque blocco -> la minimap ci finiva dietro.
        // 1.0 = il piu' vicino sotto reversed-Z -> vince sempre (>= di tutto) -> HUD sopra ogni cosa.
        gl_FragDepth = HUD_DEPTH;
#if SQUARE
        // Minimap QUADRATA: mostra tutto il quadrato 128x128, con la cornice sui pixel esterni. Le prime
        // HEADER_ROWS righe (dati frecce) sono sempre nascoste come cornice, anche se border-size e' piccolo.
        // NB: uvCoord va da 0 a 128 (non 127!) attraverso il quad: la distanza dal bordo destro/basso e'
        // 128-uv, non 127-uv — col 127 la cornice usciva 1px PIU' SPESSA a destra e in basso (bug segnalato).
        float edge = min(min(uvCoord.x, 128.0 - uvCoord.x), min(uvCoord.y, 128.0 - uvCoord.y));
        if (uvCoord.y < HEADER_ROWS || edge < BORDER_WIDTH) {
            float t = BORDER_WIDTH > 0.001 ? clamp(edge / BORDER_WIDTH, 0.0, 1.0) : 1.0;
            magixEmit(mix(BORDER_OUTER, BORDER_INNER, t));
            return;
        }
#else
        // Minimap ROTONDA: ritaglio circolare + anello-cornice. L'header (angoli/righe alte) resta fuori
        // dal cerchio e viene scartato con discard.
        float dist = length(uvCoord - vec2(64.0));
        if (dist > RADIUS + BORDER_WIDTH) {
            discard;
        }
        if (dist > RADIUS) {
            magixEmit(mix(BORDER_INNER, BORDER_OUTER, (dist - RADIUS) / BORDER_WIDTH));
            return;
        }
#endif
        // Campionamento del contenuto minimap: base nearest (niente sfocatura bilineare, gia' bocciata
        // come "annebbiata"); con SMOOTH (stile "magix") si aggiunge la ricostruzione dei bordi stile
        // Scale2x (vedi smartSample): scalette diagonali levigate, colori netti. Con stile "vanilla"
        // i pixel restano nudi. FULLBRIGHT: niente vertexColor (lightmap) ne' fog -> il colore e' gia'
        // quello finale (di notte non si scurisce). Poi le FRECCE dei giocatori (a risoluzione schermo).
#if SMOOTH
        vec3 rgb = smartSample(uvCoord) * ColorModulator.rgb;
#else
        ivec2 tx = clamp(ivec2(uvCoord), ivec2(0), ivec2(127));
        vec3 rgb = texelFetch(Sampler0, tx, 0).rgb * ColorModulator.rgb;
#endif
        // Ordine: gli slot pieni in ordine di array; il PROPRIO marcatore e' l'ULTIMO slot (disegnato per
        // ultimo -> sopra gli altri). Vedi MapContentBuilder.computePlayerArrows.
        for (int i = 0; i < ARROW_MAX; i++) {
            if (arrows[i].w < -0.5) continue;        // slot vuoto
            rgb = drawArrow(rgb, uvCoord, arrows[i].xy, arrows[i].z, arrowColor(int(arrows[i].w)));
        }
        magixEmit(vec4(rgb, 1.0));
        return;
    }

    // MAPPA-ITEM Fazioni (custom==2, firma inversa nei pixel): resta dov'e' nel mondo ma viene resa
    // FULLBRIGHT (niente lightmap/fog: leggibile anche a mezzanotte, come se fosse "luminosa") e con lo
    // stesso upscaling smart della minimap -> le due mappe hanno la stessa identica resa. La riga 0
    // (firma) viene nascosta duplicando la riga 1.
    if (custom == 2) {
        vec2 uv = vec2(uvCoord.x, max(uvCoord.y, 1.0));
#if SMOOTH
        vec3 rgb = smartSample(uv) * ColorModulator.rgb;
#else
        ivec2 tx = clamp(ivec2(uv), ivec2(0), ivec2(127));
        vec3 rgb = texelFetch(Sampler0, tx, 0).rgb * ColorModulator.rgb;
#endif
        magixEmit(vec4(rgb, 1.0));
        return;
    }

    // PANNELLO INFO (custom==3): striscia sotto la minimap con orologio/coordinate/info. Come la minimap
    // sta SEMPRE davanti a tutto (gl_FragDepth = 1.0, reversed-Z). Testo campionato NEAREST (niente
    // upscaling smart: sul testo distorcerebbe i glifi). Le prime HEADER_ROWS righe portano la firma
    // magica e vanno nascoste: si campiona da riga >= HEADER_ROWS.
    if (custom == 3) {
        gl_FragDepth = HUD_DEPTH;
        // Le prime HEADER_ROWS righe portano la firma magica: si SCARTANO (discard), non si clampano. Col
        // clamp (max(y,HEADER_ROWS)) le righe-schermo 0..HEADER_ROWS leggevano tutte la stessa riga di
        // texture -> il bordo alto della prima riga di testo veniva duplicato e appariva "stirato".
        if (uvCoord.y < HEADER_ROWS) discard;
        ivec2 tx = clamp(ivec2(uvCoord), ivec2(0), ivec2(127));
        vec3 rgb = texelFetch(Sampler0, tx, 0).rgb;
        // Sfondo trasparente (scelta LIVE del renderer): i pixel del colore-CHIAVE non si disegnano ->
        // resta solo il testo con la sua ombra. Con un riquadro pieno il fondo non e' il colore-chiave e
        // nessun pixel viene scartato.
        if (dot(abs(rgb - PANEL_KEY), vec3(1.0)) < 0.02) discard;
        magixEmit(vec4(rgb * ColorModulator.rgb, 1.0));
        return;
    }
#endif

#ifdef IS_GUI
    // texels per screen pixel, for smoothMark (here, before any branch: derivatives want every pixel to get here)
    vec2 smoothFoot = fwidth(texCoord0 * vec2(textureSize(Sampler0, 0)));
    // MagixFactions theft HUD, MagixPack transition, shield bar, spawn portal arrow and AFK screen: drawn here, the glyph
    // texture is not used.
    if (hudMode == 8) {
        // MagixQuests' level up shield (LEVEL_SPIN_BLUE of text.vsh): its own texture, whiter by hudData.y; a piece of
        // the burst (hudData.x = 0..7) keeps only its wedge of the shield, with jagged edges.
        vec4 lvTex = smoothMark(texture(Sampler0, texCoord0), texCoord0, smoothFoot);
        if (hudData.x >= 0.0) {
            vec2 p = hudPos * vec2(34.0, 40.0); // LEVEL_SHOW_HALF of text.vsh
            // the same jagged cut for every piece (it depends only on the place), so the eight fit together exactly
            float a = atan(p.y, p.x);
            a += 0.14 * sin(length(p) * 0.23 + a * 3.0);
            float wedge = floor(mod(a / 6.28318530718 * 8.0 + 8.0, 8.0));
            if (abs(wedge - hudData.x) > 0.5) discard;
        }
        vec4 lvColor = vec4(mix(lvTex.rgb, vec3(1.0), hudData.y), lvTex.a) * vertexColor;
        if (lvColor.a < 0.1) discard;
        magixEmit(lvColor * ColorModulator);
        return;
    }
    if (hudMode == 9) {
        magixEmit(miniPiece() * ColorModulator);
        return;
    }
    if (hudMode != 0) {
        vec4 hud = hudMode == 1 ? hudFrame() : hudMode == 2 ? hudArrow() : hudMode == 4 ? shieldBar()
                : hudMode == 5 ? guideArrow() : hudMode == 6 ? afkScreen() : hudMode == 7 ? comboBar()
                : hudMode == 12 ? cinemaPointer() : hudMode >= 10 ? cinemaScreen(hudMode == 11) : hudTransition();
        hud.a *= vertexColor.a;
        if (hud.a < 0.004) discard;
        magixEmit(hud * ColorModulator);
        return;
    }
#endif

#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif
#if defined(IS_GUI) && !defined(IS_GRAYSCALE)
    texColor = smoothMark(texColor, texCoord0, smoothFoot);
#endif
#if defined(IS_GUI) && MAGIX_TARGET >= 262 && !defined(IS_GRAYSCALE)
    texColor = storeGlow(texColor);
#endif

#if MAGIX_TARGET >= 263
    // Vanilla 26.3: the same colour for the three variants, fog only in the world one (scaled by alpha
    // while accumulating OIT).
    vec4 color = texColor * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
#ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
#endif
#if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)
#ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
    vec4 fogColor = FogColor;
#endif
    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
#endif
    fragColor = color;
#endif
#else
#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
#endif
}
