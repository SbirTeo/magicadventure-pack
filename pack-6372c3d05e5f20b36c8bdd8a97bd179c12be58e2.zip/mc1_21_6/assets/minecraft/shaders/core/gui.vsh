#version 330
#define MAGIX_TARGET 261
#define MAGIX_MC 216
#define LOC(n)

// One source for 26.1, 26.2 and 26.3 (pack/ShaderVariants writes MAGIX_TARGET and LOC for each).
// MagixPack's FALLBACK gui shader (PackService.FALLBACK_FILES): it goes in the pack only when no plugin registers its
// own gui.vsh/gui.fsh. On the faction MagixScoreboard registers one (sidebar background and size) that drops the same
// chat mark; on magicrealms and wherever MagixScoreboard is missing, this one does it (owner 31/10). It is vanilla's
// "gui" shader (26.2) plus the CHAT_TAG block, COPIED UNCHANGED from MagixScoreboard's gui.vsh: change both together.

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
#if MAGIX_TARGET >= 263
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
#else
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
float LineWidth;
};
#endif
layout(std140) uniform Projection {
    mat4 ProjMat;
};

LOC(0) in vec3 Position;
LOC(1) in vec4 Color;

LOC(0) out vec4 vertexColor;
// 1 on the corners of the chat's "System" mark (see CHAT_TAG below), 0 elsewhere: gui.fsh drops the pixels where
// it is 1, which only a quad with ALL four corners marked has everywhere.
LOC(1) out float chatTag;

// The mark the client draws at the left of every system message of the chat (GuiMessageTag.SYSTEM, also
// CHAT_NOT_SECURE: indicator colour 0xD0D0D0, read from the 26.2 client): ChatComponent fills x -4..-2 of a line,
// under a pose scaled by the chat scale and moved 4 to the right, so on the GUI it is a quad between x 0 and
// 2 x chat scale (at most 2), in that grey with the chat's opacity as alpha. The server cannot colour it and a glyph
// cannot cover it (it is drawn over the text): it is dropped, and MagixEssentials' chat bar (MagixPack glyph
// chat_bar, in the writer's name colour) drawn there shows instead. Any other fill is untouched: one with a corner
// right of x 2.5 or of another colour is never dropped.
const vec3 CHAT_TAG = vec3(208.0 / 255.0);

// THE CANVAS SCREENS' FOCUS FRAME (owner 20/11: «se clicco fuori esce un riquadro enorme bordato di bianco»): a click
// on the Prison's canvas board (a plain message of a dialog, MagixMenus canvas-body) focuses its text widget, which
// the client then outlines in opaque white (FocusableTextWidget, graphics.outline: four 1-pixel fills). Those fills
// are dropped: opaque white, lying on the widget's own frame for one of the canvas sizes (the sizes and the layout
// are those of MagixPack text.vsh's CANVAS block: change them together). Any other white fill is untouched.
float canvasBoardWOf(int s) { return s == 3 ? 1014.0 : s == 2 ? 692.0 : s == 1 ? 524.0 : 346.0; }
// how far (GUI pixels) p is from the nearest column of a canvas board's frame, inside the dialog's body (else 999)
float canvasFrameGap(vec2 p) {
    vec2 gui = vec2(round(abs(2.0 / ProjMat[0][0])), ceil(abs(2.0 / ProjMat[1][1]) - 0.01));
    float best = 999.0;
    if (p.y < 30.5 || p.y > gui.y - 2.5) return best;
    // s 4..7: Piccolo and Grande (352, 528) with the carousel's sides (text.vsh canvasSides): 16 / 31 a side until
    // 23/11, 17 / 35 since (both kept: a pack a step behind the server still drops its frame)
    for (int s = 0; s < 8; s++) {
        float w = s == 4 ? 352.0 + 10.0 + 32.0 : s == 5 ? 528.0 + 10.0 + 62.0 : s == 6 ? 352.0 + 10.0 + 34.0
                : s == 7 ? 528.0 + 10.0 + 70.0 : canvasBoardWOf(s) + 10.0;
        if (gui.x < w + 20.0) continue;
        float x0 = floor((gui.x - w - 20.0) * 0.5) + 10.0;
        best = min(best, min(min(abs(p.x - x0), abs(p.x - x0 - 1.0)), min(abs(p.x - x0 - w), abs(p.x - x0 - w + 1.0))));
    }
    return best;
}
bool canvasFocusFrame(vec2 p) { return canvasFrameGap(p) < 2.6; }

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    if (all(greaterThan(Color, vec4(0.998))) && canvasFocusFrame((ModelViewMat * vec4(Position, 1.0)).xy)) {
        vertexColor.a = 0.0;
    }
    chatTag = 0.0;
    if (all(lessThan(abs(Color.rgb - CHAT_TAG), vec3(0.6 / 255.0)))) {
        vec4 at = ModelViewMat * vec4(Position, 1.0);
        if (at.x < 2.5) chatTag = 1.0;
    }
}
