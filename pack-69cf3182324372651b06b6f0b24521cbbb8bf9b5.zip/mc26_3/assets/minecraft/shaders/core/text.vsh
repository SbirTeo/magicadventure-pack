#version 330
#extension GL_ARB_separate_shader_objects : require
#define MAGIX_TARGET 263
#define LOC(n) layout(location = n)

// MagixPack's own text shader: vanilla, plus the screen transition (transition/ScreenTransition.java). It goes in
// the pack only when no plugin registers a text shader of its own (PackService.FALLBACK_FILES): on the faction
// MagixFactions does (minimap, sidebar, theft HUD and this same transition), on the hub nobody does and this one
// is used. Like MagixFactions' shader it is one source for 26.1, 26.2 and 26.3: ShaderVariants writes it three
// times (MAGIX_TARGET, LOC(n), //#263 lines: see README, "Più versioni di Minecraft"). 26.1 has no GUI variant
// (IS_GUI is never defined there): the transition is not drawn on 26.1, its glyph is almost transparent.
// Locations: vanilla 26.3 ones (Position 0, Color 1, UV0 2, UV2 3; out 0..3), ours from 4. They must match text.fsh.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#ifdef IS_GUI
// GameTime, for the menu marquee (the GUI text pipeline has the "Globals" block, as MagixFactions' shader uses)
#include <minecraft:globals.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

LOC(0) in vec3 Position;
LOC(1) in vec4 Color;
LOC(2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
LOC(3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
LOC(0) out float sphericalVertexDistance;
LOC(1) out float cylindricalVertexDistance;
#endif

LOC(2) out vec4 vertexColor;
LOC(3) out vec2 texCoord0;

#ifdef IS_GUI
// The transition is a title made of the glyph of the font magixpack:transition, coloured red 254, blue 5
// (closing) or 6 (opening), green = progress 0..255: a mark no vanilla text uses. The title is centred on the
// screen, so every vertex of the glyph is on its own side of the centre, and that side picks the corner of the
// screen the vertex is moved to. Same mark and same geometry as the theft HUD in MagixFactions' text.vsh,
// which handles blue 5 and 6 the same way: if the mark changes, change both.
// The SHIELD BAR (the few seconds of protection after a teleport): blue 7, green = what is left 0..255, becomes a
// thin timer bar just under the crosshair (shieldBar() in text.fsh); its words are the subtitle, blue 8 (their
// shadow blue 9), brought back to scale 1 and centred just over the bar. SHIELD_* and the two branches are COPIED
// IDENTICAL in MagixFactions' text.vsh.
// The AFK SCREEN of MagixPack (afk/AfkScreen: a player MagixGuard marks as idle, «magix_afk»). Its title starts with
// the glyph of the font magixpack:portal_guide and the space that takes its advance back, marked blue 11: it is
// stretched over the whole screen (the corner read from its texture, guideCorner(): the words after it leave the
// glyph off the screen centre) and drawn by afkScreen() in text.fsh, a frozen, frosted veil with a light blue
// border. The words are three lines. The first is the rest of the title (blue 12, its shadow blue 13): vanilla
// draws it at scale 4 from y -10, here it goes to AFK_LINE1_SCALE from AFK_LINE1_TOP. The subtitle holds the second
// and the third line one after the other (blue 14/15, then 16/17): green = how far that line moves sideways (the
// OTHER line's half width, GUI pixels at scale 1), so each one is centred on its own; vanilla draws the subtitle at
// scale 2 from y 5, here the second goes to AFK_LINE2_SCALE from AFK_LINE2_TOP and the third to scale 1 from
// AFK_LINE3_TOP. All tops are GUI pixels from the screen centre. AFK_* and the branch are COPIED IDENTICAL in
// MagixFactions' and MagixPack's text.vsh: if they change, change both (and AfkScreen.java, which writes the marks).
const float AFK_LINE1_SCALE = 2.0;
const float AFK_LINE1_TOP = -34.0;
const float AFK_LINE2_SCALE = 1.5;
const float AFK_LINE2_TOP = -8.0;
const float AFK_LINE3_TOP = 10.0;
const vec4 AFK_LINE1_FILL = vec4(0.92, 0.98, 1.0, 1.0);
const vec4 AFK_LINE2_FILL = vec4(0.74, 0.92, 1.0, 1.0);
const vec4 AFK_LINE3_FILL = vec4(0.62, 0.82, 0.94, 1.0);
const vec4 AFK_SHADOW = vec4(0.03, 0.14, 0.24, 1.0);
LOC(4) out vec2 hudPos;          // transition: GUI pixels from the screen centre; shield bar: -1..1 across it
LOC(5) flat out int hudMode;     // 0 = vanilla text, 3 = transition, 4 = shield bar, 6 = AFK screen, 10/11 = film (the numbers MagixFactions' shader uses too), 14 = skill ring, 15 = forest screen, 16 = rope gauge
LOC(6) flat out vec4 hudData;    // transition: half screen size in GUI pixels (xy), progress 0..255 (z), 1 = opening (w);
                                 // shield bar: half size in GUI pixels (xy), what is left 0..255 (z);
                                 // AFK screen: half screen size (xy), seconds (z, GameTime)
const vec2 SHIELD_BAR_HALF = vec2(46.0, 2.5);   // half size of the shield bar, GUI pixels
const float SHIELD_BAR_Y = 24.0;                // its centre under the screen centre, GUI pixels
const vec4 SHIELD_LABEL_FILL = vec4(0.82, 1.0, 0.9, 1.0);
const vec4 SHIELD_LABEL_SHADOW = vec4(0.03, 0.2, 0.11, 1.0);
uniform sampler2D Sampler0;

// The corner (-1 or 1 on each axis, GUI y down) of a vertex of the glyph of magixpack:portal_guide. Its texture
// (magixpack:font/portal_guide.png, tools/make_portal_guide.py) says in every texel which quarter it is in: red 0 =
// left half, 255 = right; green 0 = top half, 255 = bottom; blue 77 and alpha 16 mark it. The vertex sits on a corner
// of the glyph in the font atlas: of the four texels round it, the one inside the glyph is the one whose quarter is
// that corner, and the corner is the opposite of the way to it. None found: (0, 0), the quad shrinks to nothing.
// COPIED IDENTICAL from MagixFactions' text.vsh (where the spawn portal arrow uses it too).
vec2 guideCorner() {
    vec2 at = UV0 * vec2(textureSize(Sampler0, 0));
    for (int i = 0; i < 4; i++) {
        vec2 d = vec2((i & 1) == 0 ? -1.0 : 1.0, i < 2 ? -1.0 : 1.0);   // the way to the texel looked at
        ivec4 t = ivec4(round(texelFetch(Sampler0, ivec2(floor(at + 0.5 * d)), 0) * 255.0));
        if (t.b == 77 && t.a == 16 && t.r == (d.x > 0.0 ? 0 : 255) && t.g == (d.y > 0.0 ? 0 : 255)) return -d;
    }
    return vec2(0.0);
}
#endif

#ifdef IS_GUI
// --- MagixPack CINEMA: the newcomers' film (cinematic/CinematicTour) ---------------------------------------------
// The ACTION BAR carries the picture: the glyph of magixpack:portal_guide and its back-space marked red 254 + blue
// CINE_BARS_BLUE (green = how far the black bars are in, 0..255), the same glyph marked CINE_BLACK_BLUE (green = how
// black the whole screen is, 0..255), both stretched over the screen (corner read by guideCorner()) and drawn by
// cinemaScreen() of text.fsh; then the replay hint (blue CINE_REPLAY_BLUE, shadow +1), the scene's heading (blue
// CINE_HEAD_BLUE, shadow +1, in the middle of the top bar, or CINE_CARD_BLUE big over the middle of the picture: the
// opening card) and the skip hint (blue CINE_HINT_BLUE, shadow +1). The two hints go to the ends of the top bar (replay
// on the left, skip on the right: green = half the line's width); the heading's green = 128 + half (skip hint width -
// replay hint width), the way back to the middle. The SUBTITLE holds the two
// lines of the caption one after the other, blue CINE_LINE1_BLUE / CINE_LINE2_BLUE (shadows +1), green = how far that
// line moves sideways (the OTHER line's half width), both in the bottom bar. The titles fade by their own times; the
// action bar is sent again every few ticks. Text scales are whole numbers (sharp letters) that grow with the bars.
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both (and CinematicTour.java).
const int CINE_BARS_BLUE = 40;
const int CINE_BLACK_BLUE = 41;
const int CINE_HEAD_BLUE = 42;
const int CINE_CARD_BLUE = 44;
const int CINE_LINE1_BLUE = 46;
const int CINE_LINE2_BLUE = 48;
const int CINE_HINT_BLUE = 50;
const int CINE_REPLAY_BLUE = 52;
// the opening card in the TITLE, big in the middle of the screen with the MOTD's gradient (magenta to green): blue
// CINE_TITLE_BLUE (shadow +1), green = half its width in title pixels
const int CINE_TITLE_BLUE = 54;
const vec3 CINE_TITLE_FROM = vec3(0.753, 0.275, 0.910);   // #C046E8
const vec3 CINE_TITLE_TO = vec3(0.659, 0.863, 0.173);     // #A8DC2C
const int CINE_RAISED_BLUE = 56;   // the caption's two lines raised over the hotbar (+0/+1 line 1, +2/+3 line 2)
const float CINE_BAR_PART = 0.115;   // each bar, a part of the screen's height
const float CINE_BAR_MIN = 40.0;     // GUI pixels: the hints row + a heading at scale 2
const float CINE_EDGE = 10.0;        // the hints' distance from the left and right edges, GUI pixels
const float CINE_HINT_ROW = 14.0;    // the row of the two hints at the top of the top bar, GUI pixels
const vec4 CINE_HEAD_FILL = vec4(0.93, 0.80, 0.50, 1.0);
const vec4 CINE_CARD_FILL = vec4(1.0, 0.95, 0.84, 1.0);
const vec4 CINE_LINE_FILL = vec4(0.96, 0.96, 0.95, 1.0);
const vec4 CINE_HINT_FILL = vec4(0.58, 0.58, 0.62, 1.0);
const vec4 CINE_SHADOW = vec4(0.0, 0.0, 0.0, 1.0);

// The height of each black bar on a screen of half size h (GUI pixels), whole pixels.
float cinemaBar(vec2 h) {
    return floor(max(CINE_BAR_MIN, CINE_BAR_PART * 2.0 * h.y));
}

// The film's POINTER (a gold arrow bobbing towards what the narrator talks about):
//  - over a tile of a 6-row drawn menu: a glyph of magixpack:portal_guide in the MENU'S TITLE marked red 254 + blue
//    CINE_RECT_BLUE + (w - 1) * 3 + (h - 1) (w 1..9 columns, h 1..3 rows), green = its top left slot (0..89: 0-53 the
//    chest, 54-80 the player's inventory, 81-89 the hotbar), framed with a pulsing gold border, the arrow outside the window beside it;
//  - over a place of the HUD: the same glyph in the ACTION BAR marked CINE_ANCHOR_BLUE + 0 (the stats panel right of
//    the hotbar), 1 (the sidebar), 2 (the minimap), the arrow pointing at it.
// The film's CAPTION inside a drawn menu (the HUD under a menu is dimmed by the screen's backdrop): the two lines are
// written in the menu's title from the title's own start, in the default font, marked CINE_MENU_LINE_BLUE + line * 2
// (+1 the shadow), green = half the line's width; they go to the bottom bar like the subtitle's lines.
const int CINE_ANCHOR_BLUE = 90;
const int CINE_RECT_BLUE = 100;
const int CINE_MENU_LINE_BLUE = 160;
const float CINE_POINT_MARGIN = 12.0;   // room round a framed tile for its glow, GUI pixels
const float CINE_POINT_GAP = 3.0;      // the side arrow's tip from the window's edge, GUI pixels
const float CINE_POINT_ARROW = 42.0;   // room for the side arrow, GUI pixels

// The left and top of a 6-row chest window with the player's inventory (176 x 222), GUI pixels.
vec2 cinemaWindow(vec2 h) {
    return vec2(floor((ceil(2.0 * h.x - 0.01) - 176.0) * 0.5), floor((ceil(2.0 * h.y - 0.01) - 222.0) * 0.5));
}

// The top of a slot row of that window: 0-5 the chest, 6-8 the inventory, 9 the hotbar.
float cinemaSlotY(int row) {
    return row < 6 ? 18.0 + 18.0 * float(row) : row < 9 ? 139.0 + 18.0 * float(row - 6) : 197.0;
}

bool cinemaPointerVertex(ivec3 rgb, vec4 v, vec2 h, float bar, inout vec4 labelColor) {
    if (rgb.b >= CINE_RECT_BLUE && rgb.b < CINE_RECT_BLUE + 27 && rgb.g < 90) {
        int wh = rgb.b - CINE_RECT_BLUE;
        int col = rgb.g - (rgb.g / 9) * 9, row = rgb.g / 9;
        int w = wh / 3 + 1, hh = wh - (wh / 3) * 3 + 1;
        vec2 win = cinemaWindow(h);
        vec2 lo = win + vec2(7.0 + 18.0 * float(col), cinemaSlotY(row) - 1.0);
        vec2 hi = win + vec2(7.0 + 18.0 * float(min(col + w, 9)), cinemaSlotY(min(row + hh - 1, 9)) + 17.0);
        vec2 centre = (lo + hi) * 0.5, half_ = (hi - lo) * 0.5;
        // the arrow OUTSIDE the window, beside the tile's row, pointing at it from the nearer side: over the window it
        // went under the items the client draws after the title (the band, the title light)
        bool right = float(col) + float(w) * 0.5 > 4.5;
        float tip = right ? win.x + 176.0 + CINE_POINT_GAP - centre.x : win.x - CINE_POINT_GAP - centre.x;
        float bmin = min(-half_.x - CINE_POINT_MARGIN, tip - CINE_POINT_ARROW);
        float bmax = max(half_.x + CINE_POINT_MARGIN, tip + CINE_POINT_ARROW);
        vec2 qc = vec2((bmin + bmax) * 0.5, 0.0), qh = vec2((bmax - bmin) * 0.5, half_.y + CINE_POINT_MARGIN);
        vec2 corner = guideCorner();
        hudMode = 12;
        hudPos = qc + corner * qh;
        hudData = vec4(half_, GameTime * 1200.0, tip / 1000.0);   // |w| < 0.5: a framed tile, w * 1000 = the tip's x
        gl_Position = ProjMat * vec4(centre + hudPos, v.z, v.w);
        return true;
    }
    if (rgb.b >= CINE_ANCHOR_BLUE && rgb.b <= CINE_ANCHOR_BLUE + 2) {
        int kind = rgb.b - CINE_ANCHOR_BLUE;
        vec2 at, dir;
        if (kind == 0) {
            at = vec2(floor(h.x) + 91.0 + 6.0 + 34.0, 2.0 * h.y - 24.0);
            dir = vec2(0.0, 1.0);
        } else if (kind == 1) {
            at = vec2(2.0 * h.x - 132.0, h.y);
            dir = vec2(1.0, 0.0);
        } else {
            float unit = 16.0 / 9.0 * h.y;
            float side = 0.27 * unit, margin = 0.03 * unit;
            at = vec2(2.0 * h.x - margin - side - 4.0, margin + side + 4.0);
            dir = normalize(vec2(1.0, -1.0));
        }
        vec2 corner = guideCorner();
        hudMode = 12;
        hudPos = corner * 36.0 - dir * 20.0;    // the tip at hudPos 0, the arrow's body behind it
        hudData = vec4(dir, GameTime * 1200.0, 1.0);
        gl_Position = ProjMat * vec4(at - dir * 20.0 + corner * 36.0, v.z, v.w);
        return true;
    }
    if (rgb.b >= CINE_MENU_LINE_BLUE && rgb.b <= CINE_MENU_LINE_BLUE + 3) {
        int line = (rgb.b - CINE_MENU_LINE_BLUE) / 2;
        bool shadow = (rgb.b - CINE_MENU_LINE_BLUE) % 2 == 1;
        vec2 win = cinemaWindow(h);
        float s = max(1.0, floor(bar / 30.0));
        vec2 local = v.xy - (win + vec2(8.0, 6.0)) - vec2(float(rgb.g), 4.5);
        float gap = 5.5 * s + 1.0;
        vec2 at = local * s + vec2(0.0, h.y - bar * 0.5 + (line == 0 ? -gap : gap));
        gl_Position = ProjMat * vec4(h + at, v.z, v.w);
        labelColor = vec4((shadow ? CINE_SHADOW : CINE_LINE_FILL).rgb, Color.a);
        return true;
    }
    return false;
}

// A vertex of the film's picture or words: moved where it goes (gl_Position, hudMode, hudPos, hudData, labelColor);
// false for any other vertex.
bool cinemaVertex(ivec3 rgb, inout vec4 labelColor) {
    if (rgb.r != 254 || rgb.b < CINE_BARS_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    float bar = cinemaBar(h);
    if (rgb.b > CINE_TITLE_BLUE + 1 && (rgb.b < CINE_RAISED_BLUE || rgb.b > CINE_RAISED_BLUE + 3)) {
        return cinemaPointerVertex(rgb, v, h, bar, labelColor);
    }
    float s = max(1.0, floor(bar / 30.0));
    if (rgb.b == CINE_BARS_BLUE || rgb.b == CINE_BLACK_BLUE) {
        vec2 corner = guideCorner();
        hudMode = rgb.b == CINE_BARS_BLUE ? 10 : 11;
        hudPos = corner * h;
        hudData = vec4(h, float(rgb.g), bar);
        gl_Position = ProjMat * vec4(h + corner * h, v.z, v.w);
        return true;
    }
    int kind = (rgb.b - CINE_HEAD_BLUE) / 2;   // 0 heading, 1 card, 2 caption line 1, 3 caption line 2, 4 hint, 5 replay
    bool shadow = (rgb.b - CINE_HEAD_BLUE) % 2 == 1;
    // the caption RAISED over the hotbar (the scene that points at the HUD, without bars): CINE_RAISED_BLUE..+3
    bool raised = rgb.b >= CINE_RAISED_BLUE && rgb.b <= CINE_RAISED_BLUE + 3;
    if (raised) {
        kind = rgb.b < CINE_RAISED_BLUE + 2 ? 2 : 3;
        shadow = (rgb.b - CINE_RAISED_BLUE) % 2 == 1;
    } else if (rgb.b == CINE_TITLE_BLUE || rgb.b == CINE_TITLE_BLUE + 1) {
        // the title: vanilla draws it at scale 4 from y -10 round the middle; centred on the middle here
        vec2 local = (v.xy - h) / 4.0 + vec2(0.0, 5.5);
        float u = clamp(local.x / max(1.0, float(rgb.g)) * 0.5 + 0.5, 0.0, 1.0);
        vec3 grad = mix(CINE_TITLE_FROM, CINE_TITLE_TO, u);
        bool titleShadow = rgb.b == CINE_TITLE_BLUE + 1;
        gl_Position = ProjMat * vec4(h + local * max(2.0, floor(h.y / 40.0)), v.z, v.w);
        labelColor = vec4(titleShadow ? grad * 0.22 : grad, Color.a);
        return true;
    } else if (rgb.b > CINE_REPLAY_BLUE + 1) {
        return false;
    }
    vec2 at;
    vec4 fill;
    // the action bar: scale 1 from (width / 2, height - 68), the text from y -4
    vec2 bar1 = v.xy - vec2(h.x, 2.0 * h.y - 68.0) - vec2(0.0, 0.5);
    if (kind <= 1) {
        // the heading, in the action bar between the hints: back to the middle, then scaled
        vec2 local = bar1 + vec2(float(rgb.g) - 128.0, 0.0);
        if (kind == 0) {
            // big in the middle of the top bar, under the row of the two hints
            at = local * max(2.0, s) + vec2(0.0, -h.y + (bar + CINE_HINT_ROW) * 0.5);
            fill = CINE_HEAD_FILL;
        } else {
            at = local * max(2.0, floor(h.y / 40.0)) + vec2(0.0, -h.y * 0.12);
            fill = CINE_CARD_FILL;
        }
    } else if (kind <= 3) {
        // the subtitle: vanilla draws it at scale 2 from y 5
        vec2 local = (v.xy - h) / 2.0 - vec2(0.0, 9.5);
        local.x += kind == 2 ? float(rgb.g) : -float(rgb.g);
        float gap = 5.5 * s + 1.0;
        at = local * s + vec2(0.0, h.y - bar * 0.5 + (kind == 2 ? -gap : gap) - (raised ? bar * 0.5 + 30.0 : 0.0));
        fill = CINE_LINE_FILL;
    } else if (kind == 4) {
        at = vec2(h.x - CINE_EDGE - float(rgb.g) + bar1.x, -h.y + CINE_HINT_ROW * 0.5 + 2.0 + bar1.y);
        fill = CINE_HINT_FILL;
    } else {
        at = vec2(-h.x + CINE_EDGE + float(rgb.g) + bar1.x, -h.y + CINE_HINT_ROW * 0.5 + 2.0 + bar1.y);
        fill = CINE_HINT_FILL;
    }
    gl_Position = ProjMat * vec4(h + at, v.z, v.w);
    labelColor = vec4((shadow ? CINE_SHADOW : fill).rgb, Color.a);
    return true;
}

// --- MagixPack MANA FLIGHT (owner 4/11, MagixPrison's fx/ManaFlight): the Mana of a dig flies into the scoreboard ------
// After the orb rose out of the dug block and bounced in the world, MagixPrison sends one TITLE a tick made of ONE glyph
// of the font magixprison:mana_flight (16 pixels tall, ascent 8, no shadow) coloured red 254 + blue MANA_FLIGHT_BLUE +
// green = progress 0..255. Here the glyph pops out of the crosshair, grows, then flies along a curve up to the Mana bar
// of the scoreboard, shrinking and fading into it. MANA_FLIGHT_TARGET is the bar's place: GUI pixels left of the
// screen's right edge (x) and from the screen's middle (y), on the prison's board (14 lines, the bar on the third: the
// game puts line t of n at H/2 + 3n - 9(n - t)); tune it there if the orb lands beside the bar. MagixPack only (the
// faction runs MagixFactions' text shader and has no Mana).
const int MANA_FLIGHT_BLUE = 200;
const vec2 MANA_FLIGHT_TARGET = vec2(48.0, -62.0);
bool manaFlightVertex(ivec3 rgb, inout vec4 labelColor) {
    if (rgb.r != 254 || rgb.b != MANA_FLIGHT_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    // the title at scale 4 from y -10 round the middle; the glyph's own middle is (-0.5, 7) there
    vec2 local = (v.xy - h) / 4.0 + vec2(0.0, 10.0) - vec2(-0.5, 7.0);
    vec2 corner = vec2(local.x > 0.0 ? 1.0 : -1.0, local.y > 0.0 ? 1.0 : -1.0);
    float p = clamp(float(rgb.g) / 255.0, 0.0, 1.0);
    vec2 start = vec2(0.0, -10.0);
    vec2 target = vec2(h.x - MANA_FLIGHT_TARGET.x, MANA_FLIGHT_TARGET.y);
    vec2 pos;
    float size;
    float alpha = 1.0;
    if (p < 0.18) {
        // the pop: out of the crosshair, growing with a small overshoot
        float t = p / 0.18;
        pos = mix(vec2(0.0, 0.0), start, t);
        size = mix(2.0, 6.0, sin(t * 1.9));
    } else {
        // the flight: a curve rising above the line between the two places, faster and faster, smaller and smaller
        float t = (p - 0.18) / 0.82;
        float e = t * t * (3.0 - 2.0 * t);
        e = mix(e, t * t, 0.5);
        vec2 control = vec2(mix(start.x, target.x, 0.35), min(start.y, target.y) - 70.0);
        pos = mix(mix(start, control, e), mix(control, target, e), e);
        size = mix(5.5, 2.0, e);
        alpha = 1.0 - smoothstep(0.86, 1.0, t);
    }
    gl_Position = ProjMat * vec4(h + pos + corner * size, v.z, v.w);
    labelColor = vec4(1.0, 1.0, 1.0, Color.a * alpha);
    return true;
}

// --- MagixPack MINERAL FLIGHT (owner 8/11, MagixPrison's fx/ManaFlight): a piece of the dug ore flies into its slot ----
// «così come il mana è animato e va verso la scoreboard, i minerali devono andare verso il pannello minerali (verso la
// loro slot)». An ore dug: MagixPrison sends, as the SUBTITLE (scale 2, from y 5; the Mana's orb keeps the title), one
// glyph of the font magixprison:mineral_flight (the ore block's own texture, 16 tall, ascent 8, no shadow) coloured
// red 254 + blue MINERAL_FLIGHT_BLUE + the mineral's slot (0..8) + green = progress. It pops out of the crosshair,
// spins and flies along an arc into that slot of the HOTBAR HUD's panel (the same anchor and shrink as the HOTBAR_HUD
// block below: slots of 21 from x 0, the item's middle 11 in and 22 rows under the panel's top), shrinking into it;
// there the slot's item swallows it (the gulp of the HOTBAR HUD block, blue 96 + phase).
const float MINERAL_HUD_GAP = 6.0;      // = HOTBAR_HUD_GAP
const float MINERAL_HUD_UP = 33.0;      // = HOTBAR_HUD_UP
const float MINERAL_HUD_FIT_W = 190.0;  // = HOTBAR_HUD_FIT_W
const float MINERAL_HUD_MARGIN = 3.0;   // = HOTBAR_HUD_MARGIN
const int MINERAL_FLIGHT_BLUE = 210;
// THE HOTBAR PANELS KEEP THEIR SIZE WHATEVER THE GUI SCALE (owner 13/11: «bloccare le dimensioni dei vari pannelli
// hotbar e fare in modo che con la gui scale non crescano», then «la grandezza deve essere come quella della hotbar a
// GUI SCALE 3, e non cambiare mai»): every Prison panel of the HOTBAR HUD (minerals, runes, wood, tokens) and the
// flights into their slots are drawn HUD_LOCK_PIXELS screen pixels per panel pixel, on every screen and at every GUI
// scale: the GUI scale is the window's height in pixels (ScreenSize of the Globals block) over the GUI's height, so a
// panel pixel is HUD_LOCK_PIXELS / that GUI pixels. They still shrink where there is no room (hudFit), never under
// HUD_LOCK_MIN.
const float HUD_LOCK_PIXELS = 3.0;
const float HUD_LOCK_MIN = 0.3;
float hudLock(float guiH) {
#ifdef IS_GUI
    float guiScale = ScreenSize.y / max(guiH, 1.0);
    return guiScale > 0.0 ? HUD_LOCK_PIXELS / guiScale : 1.0;
#else
    return 1.0;
#endif
}
float hudFit(float guiH, float fit) {
    return max(min(hudLock(guiH), fit), HUD_LOCK_MIN);
}

bool mineralFlightVertex(ivec3 rgb, inout vec4 labelColor) {
    if (rgb.r != 254 || rgb.b < MINERAL_FLIGHT_BLUE || rgb.b > MINERAL_FLIGHT_BLUE + 8) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 local = (v.xy - h) / 2.0 - vec2(0.0, 5.0) - vec2(-0.5, 7.0);
    vec2 corner = vec2(local.x > 0.0 ? 1.0 : -1.0, local.y > 0.0 ? 1.0 : -1.0);
    float p = clamp(float(rgb.g) / 255.0, 0.0, 1.0);
    float slot = float(rgb.b - MINERAL_FLIGHT_BLUE);
    float screenW = round(2.0 * h.x);
    float left = floor(screenW * 0.5) + 91.0 + MINERAL_HUD_GAP;
    float scale = hudFit(2.0 * h.y, (screenW - left - MINERAL_HUD_MARGIN) / MINERAL_HUD_FIT_W);
    vec2 target = vec2(left + (slot * 21.0 + 11.0) * scale, 2.0 * h.y - MINERAL_HUD_UP * scale + 22.0 * scale) - h;
    vec2 pos;
    float size;
    float alpha = 1.0;
    float angle;
    if (p < 0.2) {
        // the pop out of the crosshair, growing with a small overshoot
        float t = p / 0.2;
        pos = vec2(0.0, -6.0 * t);
        size = mix(1.5, 5.5, sin(t * 1.9));
        angle = t * 1.2;
    } else {
        // an arc over the line to the slot, faster and faster, spinning, smaller and smaller
        float t = (p - 0.2) / 0.8;
        float e = mix(t * t * (3.0 - 2.0 * t), t * t, 0.5);
        vec2 start = vec2(0.0, -6.0);
        vec2 control = vec2(mix(start.x, target.x, 0.6), min(start.y, target.y) - 50.0);
        pos = mix(mix(start, control, e), mix(control, target, e), e);
        size = mix(5.0, 2.5 * scale, e);
        angle = 1.2 + e * 9.0;
        alpha = 1.0 - smoothstep(0.92, 1.0, t);
    }
    vec2 c = corner * size;
    float cs = cos(angle), sn = sin(angle);
    gl_Position = ProjMat * vec4(h + pos + vec2(c.x * cs - c.y * sn, c.x * sn + c.y * cs), v.z, v.w);
    labelColor = vec4(1.0, 1.0, 1.0, Color.a * alpha);
    return true;
}

#endif

#ifdef IS_GUI
// --- MagixPack menu MARQUEE: a menu label too wide for its box scrolls from right to left -------------------
// MagixPack (menu/MenuPanel.marquee, a label wider than its max) writes every character of the label in a colour
// of its own: red 253 (the mark), green = the character's distance from the label's start, blue = the label's whole
// width rounded up to 8 (GUI pixels) + the index of its box in MARQUEE_BOXES (= MenuPanel.MARQUEE_BOXES). Here every
// character moves left with time and comes back on the right after the end (one copy of the text, then
// MARQUEE_GAP), fading in and out at the edges of the box, from the label's start. After each turn the text rests
// MARQUEE_HOLD seconds at its start. The words are drawn white (the mark is not a colour).
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both.
const float MARQUEE_BOXES[8] = float[8](36.0, 48.0, 64.0, 80.0, 96.0, 112.0, 144.0, 192.0); // GUI pixels (the fades reach MARQUEE_FADE past each edge: a tile's 36 + 8 inside its 3 slots)
const float MARQUEE_GAP = 18.0;     // between the end of the text and its start coming back
const float MARQUEE_SPEED = 16.0;   // GUI pixels per second
const float MARQUEE_HOLD = 1.5;     // seconds at the start of each turn
const float MARQUEE_FADE = 4.0;     // GUI pixels of fading at each edge
const float MARQUEE_CHAR = 5.0;     // the width of a character, for the right edge

// --- MagixPack panel CREDITS: a side panel of a drawn menu with more lines than fit scrolls up like end credits ------
// MagixPack (menu/MenuPanel.panel, a panel with more lines than menu-panel.lines) writes every character of the panel
// on the panel's FIRST text row, in a colour of its own: red 250 (the mark), green = the line's number (0-31) + 32 * its
// colour (an index of CREDITS_PALETTE), blue = how many lines the panel has. Here every character goes down to its line
// minus the distance scrolled with time: the lines leave at the top of the window (CREDITS_LINES lines of CREDITS_LINE
// GUI pixels) and come back from its bottom, fading at both edges; each turn starts with CREDITS_HOLD seconds still.
// Never 251: 251 % 8 == 3, the mark of MagixFactions' sidebar lines (every channel % 8 == 3), whose reddest colours have
// red 251: on 17/10 the scoreboard scrolled up like the panel. Only blue 2..32 with the line under it counts.
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both (and MenuPanel.CREDITS_*).
const float CREDITS_LINE = 10.0;    // = menu-panel.line-height
const float CREDITS_LINES = 15.0;   // = menu-panel.lines: the window's height in lines
const float CREDITS_GAP = 3.0;      // empty lines between the last line and the first coming back
const float CREDITS_SPEED = 9.0;    // GUI pixels per second
const float CREDITS_HOLD = 3.0;     // seconds still at the start of each turn
const float CREDITS_FADE = 8.0;     // GUI pixels of fading at the top and the bottom
const float CREDITS_TOP_FADE = 3.0; // GUI pixels over the window's top in which a line leaving fades out: never more,
                                    // the panel's glyph (the avatar) sits right over it (owner 4/11: lines crossed it)
const vec3 CREDITS_PALETTE[8] = vec3[](vec3(1.0), vec3(0.6667), vec3(1.0, 0.761, 0.239), vec3(1.0, 0.541, 0.541),
        vec3(0.498, 0.839, 1.0), vec3(0.333, 0.902, 0.510), vec3(0.788, 0.733, 0.847), vec3(0.604, 0.549, 0.659));
#endif

#ifdef IS_GUI
// --- MagixPack COMPACT MENUS: a drawn menu fits a screen too short or too narrow for it --------------------------
// The client centres a chest's window and never moves its slots (clicks land where the client thinks the slots are),
// but everything MagixPack draws AROUND the window is ours to move. With a big GUI scale on a small screen (scale 4 on
// 1920x1080: 480 x 270 GUI pixels, 253 in a window) the page under a drawn menu (518 wide, up to 328 tall with the
// boss banner) went off the screen. Three marks, all written by MagixPack (menu/MenuPanel):
//  - a PIECE OF THE PAGE (menu-page/<id>.png): red FIT_PAGE_RED, green 128 + zone + 4 * (rows - 1), blue = how far the
//    page reaches above its window (GUI pixels). The page is cut on the window's top and bottom lines and on the edges
//    of its side margins, so every piece is in one zone: 0 beside or behind the window (never moved), 1 above it
//    (squeezed towards the window's top until it fits between it and the screen's top), 2 under it (its bottom
//    stops at the screen's bottom). Every piece is also kept inside the screen's width (only the side margins,
//    pure landscape, reach past the banner's width). rows = the chest's rows: the window's top is where the client
//    puts it, (screen height - (114 + 18 * rows)) / 2 rounded down.
//  - a piece of the BANNER above the window (its picture or board): red FIT_BANNER_RED, green 160 + rows, blue = how
//    far the banner's top is above the window. When the window's top is nearer to the screen's top than that, the
//    banner cannot fit: it goes away (with its labels, and the sharp copy drawn by items: MagixPack's
//    position_tex_color.vsh, same rule).
//  - a LETTER above the window (the fonts of the label rows above the title's line, any colour): a see-through texel
//    in each corner of its texture, red = the banner's height above the window as above, green = 64 + 1 (right
//    column) + 2 (bottom row), blue = 128 + the window's top minus that corner's y. Found like guideCorner().
// Everything keeps FIT_MARGIN GUI pixels from the screen's edges (owner, 17/10: the menu must never touch them).
// Marked pieces are drawn white (the marks are not colours). Nothing changes while the menu fits. A vertex sent out
// of the screen with its three companions is not drawn. A LETTER is never moved: its vertex only turns see-through
// (alpha 0, fitLetterHidden), and only when its mark agrees with where a window's top is (fitLetterOnWindow); a real
// letter has its four vertices marked, so all of it goes, while a vertex misread on another glyph only fades a piece of
// it (23/10, Lunar Client: the tablist's names still drew red streaks to the bottom left with FIT_GONE).
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.vsh: if it changes, change both (and MenuPanel.FIT_*,
// and menu-panel/position_tex_color.vsh of MagixPack).
const int FIT_PAGE_RED = 249;
const int FIT_BANNER_RED = 248;
const float FIT_MARGIN = 6.0;   // GUI pixels kept free between the menu and the screen's edges (= position_tex_color.vsh)
const vec4 FIT_GONE = vec4(-4.0, -4.0, 0.0, 1.0);

// The window's top (GUI y) of a chest of that many rows on a screen guiH GUI pixels tall. The projection may say a
// height that is not whole (the window's pixels divided by the GUI scale, e.g. 344.25), while the client lays the screen
// out on that height rounded UP (Window.guiScaledHeight): rounding it any other way put the window's top one pixel off,
// and a line of the world showed between the squeezed page and the window (17/10).
float fitWindowTop(float guiH, int rows) {
    return floor((ceil(guiH - 0.01) - float(114 + 18 * rows)) * 0.5);
}

// The mark of a letter above the window (see FIT_PAGE_RED): x = the window's top minus this vertex's y, y = the
// banner's height above the window; y < 0: no mark (any other letter).
vec2 fitLetterMark() {
    vec2 at = UV0 * vec2(textureSize(Sampler0, 0));
    for (int i = 0; i < 4; i++) {
        vec2 d = vec2((i & 1) == 0 ? -1.0 : 1.0, i < 2 ? -1.0 : 1.0);   // the way to the texel looked at
        ivec4 t = ivec4(round(texelFetch(Sampler0, ivec2(floor(at + 0.5 * d)), 0) * 255.0));
        int corner = (d.x < 0.0 ? 1 : 0) + (d.y < 0.0 ? 2 : 0);          // the texel is inside, the vertex on this corner
        if (t.a == 0 && t.g == 64 + corner && t.r > 0) return vec2(float(t.b - 128), float(t.r));
    }
    return vec2(0.0, -1.0);
}

// A letter's mark says where the window's top is (its y + the mark). A mark read from ANOTHER glyph next to this one in
// the font atlas (Lunar Client packs its glyphs with no gap between them: the corner texel of a marked letter is then
// also round a corner of its neighbour) says a window's top that is nowhere: such a vertex is left alone. Before this
// (19/10) single vertices of the boss bar and of Lunar's HUD text went out of the screen and drew long streaks of
// light from the bottom left corner, and letters lost a piece («Boss» read «Loss»). Since 23/10 a hidden letter is not
// moved at all (fitLetterHidden): a misread vertex can no longer draw a streak, whatever coincidence lets it through.
bool fitLetterOnWindow(float windowTop, float guiH) {
    for (int rows = 1; rows <= 6; rows++) {
        if (abs(windowTop - fitWindowTop(guiH, rows)) <= 1.5) return true;
    }
    return false;
}
#endif

#ifdef IS_GUI
// --- HOTBAR HUD: a boss bar title drawn RIGHT OF THE HOTBAR (MagixPrison economy/MineralHud, owner 7/11) -------------
// The same mark as MagixFactions' text.vsh (MagixQuests' stats panel on the faction, see HOTBAR_HUD_WIDTH there): a
// title exactly HOTBAR_HUD_WIDTH GUI pixels wide sent as a see-through WHITE boss bar; every character marked red
// HOTBAR_HUD_RED + green = GUI pixels from the panel's top to its row + 1 + blue = 32 + its colour index in
// HOTBAR_PALETTE (+ 16 for its shadow, which the plugin sets itself) is moved so that the panel's left edge is
// HOTBAR_HUD_GAP right of the hotbar and its top HOTBAR_HUD_UP over the screen's bottom (the Prison's panel is 33 tall:
// its hint line over the slots, 11 over the hotbar's top, owner 7/11), at the GUI's own scale. Pictures are glyphs of a bitmap font marked like text
// (white = the picture as it is), each inside its boss bar line (at most 11 tall, ascent 10: a taller one is split
// between two lines and stretched across the screen, 7/11). Only characters in the band where such a title can be are
// moved. The palette here is the Prison's (Soldi and the minerals): MagixFactions' shader, used on the faction, has its
// own.
const int HOTBAR_HUD_RED = 247;
const float HOTBAR_HUD_WIDTH = 256.0;
const float HOTBAR_HUD_GAP = 6.0;
const float HOTBAR_HUD_UP = 33.0;
const float HOTBAR_HUD_BAND = 200.0;
// how wide the panel is drawn (MagixPrison's MineralHud: nine slots of 22 touching = 190) and the room kept at the
// screen's right edge: on a GUI narrower than the hotbar + gap + this the panel shrinks to fit (see the HOTBAR HUD block)
const float HOTBAR_HUD_FIT_W = 190.0;
const float HOTBAR_HUD_MARGIN = 3.0;
// THE LEFT PANEL (MagixPrison rune/RuneHud, owner 8/11: runes and neutral gems «a sinistra»): the same title and marks with
// blue 64 + colour (+ 16 for its shadow): drawn so that its RIGHT edge is HOTBAR_HUD_GAP left of the off hand's slot
// (HOTBAR_HUD_OFFHAND left of the hotbar), the panel HOTBAR_HUD_LEFT_W wide (owner 8/11: the six runes, slots of 22
// touching = 127, plus a pixel each side for the bigger frame of the rune on the pickaxe = 130).
const float HOTBAR_HUD_LEFT_W = 130.0;
const float HOTBAR_HUD_OFFHAND = 29.0;
// THE WOOD PANEL (MagixPrison economy/Woods, owner 9-11/11): the same title, marks blue 128 + colour (+ 16 its shadow),
// one slot every WOOD_PITCH pixels of the title (glyphs of a slot never reach the next: the slot is 22 wide), drawn in a
// column on the screen's LEFT EDGE, WOOD_MARGIN in, centred on WOOD_MAX slots half way up; WOOD_TOP = the slot's top
// row in the title (MineralHud.TOP), WOOD_ROW = a slot under the other (22, touching like the hotbar's = 21).
const float WOOD_PITCH = 40.0;
const float WOOD_INSET = 9.0;
const float WOOD_PER_GROUP = 6.0;
const float WOOD_GROUP_G = 64.0;
const float WOOD_ROW = 21.0;
const float WOOD_TOP = 11.0;
const float WOOD_MARGIN = 4.0;
const float WOOD_MAX = 11.0;
// THE TOKENS' PANEL (MagixPrison MineralHud tokenPanel, owner 13/11: «portalo sotto la scoreboard a destra»): the same
// title, marks blue 160 + colour (+ 16 its shadow), written like the wood's (a slot every WOOD_PITCH pixels, WOOD_INSET
// in), drawn as ONE COLUMN of slots touching like the hotbar's (21 apart, owner 13/11: «in verticale»), TOKEN_RIGHT from
// the screen's right edge (the sidebar's own right edge), TOKEN_GAP under the sidebar, shrunk (down to 0.5) when it would
// reach the screen's bottom or the minerals' panel. The game draws the sidebar's bottom at guiHeight / 2
// + (lines * 9) / 3 (Hud#displayScoreboardSidebar, 26.2): the Prison's board always has TOKEN_SB_LINES lines (the
// game's most, 15).
const float TOKEN_MAX = 6.0;
const float TOKEN_GAP = 8.0;   // owner 13/11: «staccalo dalla scoreboard, è appiccicato» (2 until 0.42.21)
const float TOKEN_RIGHT = 4.0;   // = WOOD_MARGIN: as far from the right edge as the wood from the left (owner 13/11; 1 until 0.42.22)
const float TOKEN_SB_LINES = 15.0;
// «Apri con /tokens» (owner 14/11): the token panel's hint, marked green + TOKEN_HINT_G (96..127) in the title along
// the column's TOKEN_MAX * WOOD_ROW pixels, turned a quarter LEFT (reading upwards) and drawn TOKEN_HINT_W left of the
// column, the glyphs' top towards the screen's middle.
const float TOKEN_HINT_G = 96.0;
const float TOKEN_HINT_W = 10.0;
// THE ENCHANTMENTS' PANEL (MagixPrison MineralHud enchantTitle, owner 14/11: «in alto a tutto come bossbar, le altre
// bossbar SOTTO di esso»): its OWN boss bar title, the player's first, marks blue 192 + colour (+ 16 its shadow), a row of
// five medallions with their words in the title's middle ENCH_W pixels, drawn centred at ENCH_TOP GUI pixels from the
// screen's top at the GUI's own scale, like a boss bar (33 rows tall: medallions, then their words). MagixPrison sends an empty boss bar right after
// it, so the other boss bars start from the third line (y 50), under the panel.
const float ENCH_W = 250.0;
const float ENCH_TOP = 2.0;
const vec3 HOTBAR_PALETTE[16] = vec3[16](
    vec3(1.0, 1.0, 1.0),          // 0 white
    vec3(0.604, 0.549, 0.659),    // 1 grey violet #9A8CA8
    vec3(0.635, 0.863, 0.173),    // 2 Soldi green #A2DC2C
    vec3(0.722, 0.722, 0.769),    // 3 coal #B8B8C4
    vec3(0.906, 0.518, 0.353),    // 4 copper #E7845A
    vec3(0.902, 0.839, 0.784),    // 5 iron #E6D6C8
    vec3(0.369, 0.553, 1.0),      // 6 lapis #5E8DFF
    vec3(1.0, 0.267, 0.267),      // 7 redstone #FF4444
    vec3(1.0, 0.847, 0.290),      // 8 gold #FFD84A
    vec3(0.239, 0.863, 0.518),    // 9 emerald #3DDC84
    vec3(0.373, 0.941, 0.941),    // 10 diamond #5FF0F0
    vec3(0.769, 0.580, 0.533),    // 11 netherite #C49488
    vec3(0.941, 0.486, 1.0),      // 12 magenta #F07CFF
    vec3(1.0, 0.761, 0.239),      // 13 amber #FFC23D
    vec3(0.420, 0.380, 0.460),    // 14 dark grey violet
    vec3(0.0, 0.0, 0.0));         // 15 black
#endif

#ifdef IS_GUI
// --- MagixPack RUNE UNLOCKED (owner 9/11, MagixPrison's fx/RuneUnlock): a rune's card, then into its slot -------------
// «Nuova runa sbloccata»: MagixPrison sends one TITLE a tick made of TWO glyphs of the font magixprison:rune_unlock
// (tools/make_rune_unlock.py: 16 tall, ascent 8, advance 17, no shadow): the LIGHT (blue RUNE_UNLOCK_BLUE + 6 + slot)
// then the CARD (blue RUNE_UNLOCK_BLUE + slot), both red 254 + green = progress 0..255; slot = the rune's place in the
// rune panel left of the hotbar (MagixPrison MineralHud.RUNE_ORDER). (The explosion is in the WORLD, at the dug block,
// before this: owner 9/11.) The light flashes open, the card pops out of it big, spinning round its upright axis,
// holds there turning slowly with the light breathing and turning behind it, then flies along an arc into its slot of
// the left panel (the HOTBAR HUD block's left anchor), spinning and shrinking to the slot's item. The words come as the
// subtitle, plain. RUNE_UNLOCK_FLASH / _POP / _HOLD are the phases' ends (MagixPrison's fx/RuneUnlock has the same;
// fx.rune-unlock.ticks sets the whole length). One more card of a rune (no new rune, no new level: owner 9/11) is the
// QUICK flight: ONE glyph, the card marked blue RUNE_UNLOCK_BLUE + 12 + slot, popping small out of the crosshair and
// flying straight down into its slot (fx.rune-unlock.quick-ticks).
const int RUNE_UNLOCK_BLUE = 220;
const float RUNE_UNLOCK_FLASH = 0.06;
const float RUNE_UNLOCK_POP = 0.18;
const float RUNE_UNLOCK_HOLD = 0.64;
const float RUNE_UNLOCK_Y = -44.0;      // the card's middle, GUI pixels from the screen's middle (over the subtitle)
const float RUNE_UNLOCK_CARD = 30.0;    // half the card's side while it is shown
const float RUNE_UNLOCK_LIGHT = 2.6;    // the light's side over the card's
bool runeUnlockVertex(ivec3 rgb, inout vec4 labelColor) {
    if (rgb.r != 254 || rgb.b < RUNE_UNLOCK_BLUE || rgb.b > RUNE_UNLOCK_BLUE + 17) return false;
    bool quick = rgb.b >= RUNE_UNLOCK_BLUE + 12;
    bool isLight = !quick && rgb.b >= RUNE_UNLOCK_BLUE + 6;
    float slot = float(rgb.b - RUNE_UNLOCK_BLUE - (quick ? 12 : isLight ? 6 : 0));
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    // the title at scale 4 from y -10 round the middle, 34 wide from -17: the light spans x -17..-1, the card 0..16,
    // both y -1..15
    // (the quick flight's single glyph spans x -8.5..7.5)
    vec2 local = (v.xy - h) / 4.0 + vec2(0.0, 10.0) - vec2(quick ? -0.5 : isLight ? -9.0 : 8.0, 7.0);
    vec2 corner = vec2(local.x > 0.0 ? 1.0 : -1.0, local.y > 0.0 ? 1.0 : -1.0);
    float p = clamp(float(rgb.g) / 255.0, 0.0, 1.0);
    // the slot's item in the left panel (= the HOTBAR HUD block: right edge left of the off hand, 130 wide, slots of
    // 21 from x 1, the item 3 in, its middle 22 rows under the panel's top)
    float screenW = round(2.0 * h.x);
    float rightEdge = floor(screenW * 0.5) - 91.0 - HOTBAR_HUD_OFFHAND - HOTBAR_HUD_GAP;
    float scale = hudFit(2.0 * h.y, (rightEdge - HOTBAR_HUD_MARGIN) / HOTBAR_HUD_LEFT_W);
    float leftEdge = rightEdge - HOTBAR_HUD_LEFT_W * scale;
    vec2 target = vec2(leftEdge + (12.0 + slot * 21.0) * scale, 2.0 * h.y - HOTBAR_HUD_UP * scale + 21.0 * scale) - h;
    vec2 centre = vec2(0.0, RUNE_UNLOCK_Y);
    vec2 pos = centre;
    float size = 0.0, spin = 0.0, alpha = 1.0, lightSize = 0.0, lightAlpha = 0.0;
    float turn = GameTime * 1200.0;
    if (quick) {
        // out of the crosshair with a hop, then straight down into the slot, spinning, shrinking to the slot's item
        vec2 start = vec2(0.0, -8.0);
        if (p < 0.2) {
            float t = p / 0.2;
            pos = mix(vec2(0.0), start, t);
            size = mix(4.0, 14.0, sin(t * 1.9));
            spin = t * 3.0;
        } else {
            float t = (p - 0.2) / 0.8;
            float e = mix(t * t * (3.0 - 2.0 * t), t * t, 0.5);
            vec2 control = vec2(mix(start.x, target.x, 0.5), start.y - 24.0);
            pos = mix(mix(start, control, e), mix(control, target, e), e);
            size = mix(13.0, 8.0 * scale, e);
            spin = 3.0 + e * 12.566;
            alpha = 1.0 - smoothstep(0.92, 1.0, t);
        }
        gl_Position = ProjMat * vec4(h + pos + vec2(corner.x * size * cos(spin), corner.y * size), v.z, v.w);
        labelColor = vec4(1.0, 1.0, 1.0, Color.a * alpha);
        return true;
    }
    if (p < RUNE_UNLOCK_FLASH) {
        // the light flashes open, bigger than it will stay
        float t = p / RUNE_UNLOCK_FLASH;
        lightSize = RUNE_UNLOCK_CARD * RUNE_UNLOCK_LIGHT * 1.5 * (1.0 - (1.0 - t) * (1.0 - t) * (1.0 - t));
        lightAlpha = smoothstep(0.0, 0.4, t);
    } else if (p < RUNE_UNLOCK_POP) {
        // out of the light, with an overshoot, spinning fast and slowing down
        float t = (p - RUNE_UNLOCK_FLASH) / (RUNE_UNLOCK_POP - RUNE_UNLOCK_FLASH);
        float u = t - 1.0;
        float back = 1.0 + 2.2 * u * u * u + 1.2 * u * u;
        size = RUNE_UNLOCK_CARD * back;
        spin = (1.0 - t) * (1.0 - t) * 18.85;
        lightSize = RUNE_UNLOCK_CARD * RUNE_UNLOCK_LIGHT * mix(1.5, 1.0, smoothstep(0.0, 1.0, t));
        lightAlpha = 1.0;
    } else if (p < RUNE_UNLOCK_HOLD) {
        // still in the middle: it turns slowly round its upright axis, breathing; the light pulses behind it
        float t = (p - RUNE_UNLOCK_POP) / (RUNE_UNLOCK_HOLD - RUNE_UNLOCK_POP);
        pos = centre + vec2(0.0, 1.5 * sin(t * 12.566));
        size = RUNE_UNLOCK_CARD * (1.0 + 0.04 * sin(t * 18.85));
        spin = t * 6.2832;
        lightSize = RUNE_UNLOCK_CARD * RUNE_UNLOCK_LIGHT * (1.0 + 0.08 * sin(t * 25.13));
        lightAlpha = 1.0;
    } else {
        // the flight: an arc down to its slot, faster and faster, turning, shrinking to the slot's item
        float t = (p - RUNE_UNLOCK_HOLD) / (1.0 - RUNE_UNLOCK_HOLD);
        float e = mix(t * t * (3.0 - 2.0 * t), t * t, 0.4);
        vec2 control = vec2(mix(centre.x, target.x, 0.15) - 40.0, centre.y - 30.0);
        pos = mix(mix(centre, control, e), mix(control, target, e), e);
        size = mix(RUNE_UNLOCK_CARD, 8.0 * scale, e);
        spin = e * 12.566;
        alpha = 1.0 - smoothstep(0.93, 1.0, t);
        lightSize = size * RUNE_UNLOCK_LIGHT;
        lightAlpha = 1.0 - smoothstep(0.0, 0.7, t);
    }
    vec2 c;
    if (isLight) {
        // the light turns in the screen's plane, slowly
        float a = turn * 0.6;
        vec2 k = corner * lightSize;
        c = vec2(k.x * cos(a) - k.y * sin(a), k.x * sin(a) + k.y * cos(a));
        alpha *= lightAlpha;
    } else {
        // the card turns round its upright axis: its width follows the cosine (its back is the mirrored front)
        c = vec2(corner.x * size * cos(spin), corner.y * size);
    }
    gl_Position = ProjMat * vec4(h + pos + c, v.z, v.w);
    labelColor = vec4(1.0, 1.0, 1.0, Color.a * alpha);
    return true;
}
#endif

#ifdef IS_GUI
// --- MagixPack SKILL RING (owner 10/11, MagixPrison's fx/MiningCombo): the SKILL charge as a ring round the crosshair ----
// «il cerchio nei pressi del crosshair fallo a percentuale che si colora in senso orario». MagixPrison's SKILL boss bar
// has as its title ONE glyph of magixpack:portal_guide coloured red 254 + blue SKILL_RING_BLUE + the rune (0 = the base
// skill, 1..6 = fire water earth storm sun abyss) + green = the charge (0..250, 255 = ready). Here that glyph leaves the
// boss bar's line: its quad (corner read from its texture, guideCorner()) becomes a square SKILL_RING_HALF GUI pixels
// round the crosshair, and skillRing() of text.fsh draws the ring filling clockwise from the top (hudMode 14).
const int SKILL_RING_BLUE = 240;
const float SKILL_RING_HALF = 20.0;
bool skillRingVertex(ivec3 rgb) {
    if (rgb.r != 254 || rgb.b < SKILL_RING_BLUE || rgb.b > SKILL_RING_BLUE + 6) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 corner = guideCorner();
    hudMode = 14;
    hudPos = corner * SKILL_RING_HALF;
    hudData = vec4(float(rgb.b - SKILL_RING_BLUE), float(rgb.g), GameTime * 1200.0, 0.0);
    gl_Position = ProjMat * vec4(h + corner * SKILL_RING_HALF, v.z, v.w);
    return true;
}
#endif

#ifdef IS_GUI
// --- MagixPack ROPE GAUGE (owner 14/11, MagixPrison's mine/MineGuide): while a player climbs the grappling hook's rope
// «un indicatore di livello con una freccia per far capire a che altezza sei, al centro schermo, con shaders». A
// see-through boss bar's title is ONE glyph of magixpack:portal_guide coloured red 254 + blue ROPE_GAUGE_BLUE + green =
// how far up he is (0 = where he threw the hook, 255 = the surface). The glyph leaves the boss bar's line: its quad
// becomes an upright box ROPE_GAUGE_HALF GUI pixels round a point ROPE_GAUGE_X right of the crosshair, and ropeGauge()
// of text.fsh draws the column from rock to surface, its filling and the arrow at his height (hudMode 16).
const int ROPE_GAUGE_BLUE = 250;
const vec2 ROPE_GAUGE_HALF = vec2(18.0, 58.0);
const float ROPE_GAUGE_X = 30.0;
bool ropeGaugeVertex(ivec3 rgb) {
    if (rgb.r != 254 || rgb.b != ROPE_GAUGE_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 corner = guideCorner();
    hudMode = 16;
    hudPos = corner * ROPE_GAUGE_HALF;
    hudData = vec4(float(rgb.g) / 255.0, GameTime * 1200.0, 0.0, 0.0);
    gl_Position = ProjMat * vec4(h + vec2(ROPE_GAUGE_X, 0.0) + corner * ROPE_GAUGE_HALF, v.z, v.w);
    return true;
}
#endif

#ifdef IS_GUI
// --- MagixPack FOREST SCREEN (owner 11/11, MagixPrison's forest/ForestLife: «effetti con shaders, non solo particelle»).
// While a player is inside the Bosco Magico a see-through boss bar's title is ONE glyph of magixpack:portal_guide coloured
// red 254 + blue FOREST_SCREEN_BLUE + green = the strength (0..255, it fades in and out): the glyph is stretched over the
// whole screen and forestScreen() of text.fsh draws a violet vignette, an aurora waving across the top and motes of light
// drifting up (hudMode 15). Nothing at the screen's middle: the player sees through it.
const int FOREST_SCREEN_BLUE = 248;
bool forestScreenVertex(ivec3 rgb) {
    if (rgb.r != 254 || rgb.b != FOREST_SCREEN_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 corner = guideCorner();
    hudMode = 15;
    hudPos = corner * h;
    hudData = vec4(h, GameTime * 1200.0, float(rgb.g) / 255.0);
    gl_Position = ProjMat * vec4(h + corner * h, v.z, v.w);
    return true;
}
#endif

#ifdef IS_GUI
// --- MagixPack MINE TREMOR (owner 14/11, MagixPrison's island/MineLife: the mountain settling must never look like a
// blow taken; until then it was the game's hurt tilt). A see-through boss bar's title is ONE glyph of
// magixpack:portal_guide coloured red 254 + blue TREMOR_SCREEN_BLUE + green = the strength (0..255, it swells and dies
// away): stretched over the whole screen, tremorScreen() of text.fsh draws a veil of dust shaking, grit falling from the
// top and the edges darkening at every jolt (hudMode 17). The middle stays clear.
const int TREMOR_SCREEN_BLUE = 249;
bool tremorScreenVertex(ivec3 rgb) {
    if (rgb.r != 254 || rgb.b != TREMOR_SCREEN_BLUE) return false;
    vec4 v = ModelViewMat * vec4(Position, 1.0);
    vec2 h = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
    vec2 corner = guideCorner();
    hudMode = 17;
    hudPos = corner * h;
    hudData = vec4(h, GameTime * 1200.0, float(rgb.g) / 255.0);
    gl_Position = ProjMat * vec4(h + corner * h, v.z, v.w);
    return true;
}
#endif

#ifdef IS_GUI
// MagixPrison's CARRY BAR (mine/CarryHud, owner 9/11): an action bar whose every piece (the plate and card glyphs of
// magixprison:placed_carry_hud, the words) is coloured red CARRY_RED + green 16 x palette index + blue 255; its words'
// shadows come as red 61, green 4 x index, blue 63. Only round the action bar's place (CARRY_BAND over the screen's
// bottom, CARRY_HALF_W from its middle): lifted CARRY_LIFT GUI pixels and coloured from CARRY_PALETTE.
const int CARRY_RED = 245;
const float CARRY_LIFT = 14.0;
const vec2 CARRY_BAND = vec2(96.0, 40.0);
const float CARRY_HALF_W = 220.0;
// Since 10/11 (owner: the Mana's «+N» in the action bar replaced the carry bar) the bar is the title of its own
// see-through boss bar: a piece within CARRY_BOSS_BAND of the screen's top leaves its boss bar line (text row at
// 3 + 19 x line; the whole bar spans -5..+13 of it, tools/make_prison_carry_hud.py) and its text row goes
// CARRY_BOSS_TOP GUI pixels over the screen's bottom: above the action bar, its second line too, always there.
const float CARRY_BOSS_BAND = 200.0;
const float CARRY_BOSS_TOP = 103.0;
// index + 8 = the same colour on the SECOND line, CARRY_SECOND_DROP pixels under the first (owner 9/11: «se muori le
// perdi» on a line of its own, under the plate)
const float CARRY_SECOND_DROP = 17.0;
const vec3 CARRY_PALETTE[6] = vec3[6](vec3(1.0), vec3(1.0), vec3(0.851, 0.659, 1.0), vec3(1.0, 0.55, 0.30),
        vec3(0.86, 0.85, 0.90), vec3(1.0, 0.45, 0.45));
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#ifdef IS_GUI
    hudMode = 0;
    hudPos = vec2(0.0);
    hudData = vec4(0.0);
    vec4 hudLabelColor = vec4(-1.0);
    ivec3 hudRgb = ivec3(round(Color.rgb * 255.0));
    if (hudRgb.r == 254 && hudRgb.b >= 5 && hudRgb.b <= 17 && hudRgb.b != 10) {
        vec4 hudVert = ModelViewMat * vec4(Position, 1.0);
        vec2 hudHalf = vec2(abs(1.0 / ProjMat[0][0]), abs(1.0 / ProjMat[1][1]));
        vec2 hudCorner = vec2(hudVert.x > hudHalf.x ? 1.0 : -1.0, hudVert.y > hudHalf.y ? 1.0 : -1.0);
        if (hudRgb.b >= 11) {
            // MagixPack AFK screen (see AFK_LINE1_SCALE).
            if (hudRgb.b == 11) {
                vec2 afkCorner = guideCorner();
                hudMode = 6;
                hudPos = afkCorner * hudHalf;
                hudData = vec4(hudHalf, GameTime * 1200.0, 0.0);
                gl_Position = ProjMat * vec4(hudHalf + afkCorner * hudHalf, hudVert.z, hudVert.w);
            } else {
                int afkLine = (hudRgb.b - 12) / 2;
                bool afkShadow = (hudRgb.b - 12) % 2 == 1;
                vec2 afkLocal = hudVert.xy - hudHalf;
                vec2 afkAt;
                if (afkLine == 0) {
                    afkAt = (afkLocal / 4.0 + vec2(0.0, 10.0)) * AFK_LINE1_SCALE + vec2(0.0, AFK_LINE1_TOP);
                } else {
                    vec2 afkU = afkLocal / 2.0 - vec2(0.0, 5.0);
                    afkU.x += afkLine == 1 ? float(hudRgb.g) : -float(hudRgb.g);
                    afkAt = afkLine == 1 ? afkU * AFK_LINE2_SCALE + vec2(0.0, AFK_LINE2_TOP)
                            : afkU + vec2(0.0, AFK_LINE3_TOP);
                }
                gl_Position = ProjMat * vec4(hudHalf + afkAt, hudVert.z, hudVert.w);
                vec4 afkFill = afkLine == 0 ? AFK_LINE1_FILL : afkLine == 1 ? AFK_LINE2_FILL : AFK_LINE3_FILL;
                hudLabelColor = vec4((afkShadow ? AFK_SHADOW : afkFill).rgb, Color.a);
            }
        } else if (hudRgb.b == 7) {
            // the shield bar: a thin bar under the crosshair, hudPos -1..1 across it
            hudMode = 4;
            hudPos = hudCorner;
            hudData = vec4(SHIELD_BAR_HALF, float(hudRgb.g), 0.0);
            gl_Position = ProjMat * vec4(hudHalf + vec2(0.0, SHIELD_BAR_Y) + hudCorner * SHIELD_BAR_HALF, hudVert.z, hudVert.w);
        } else if (hudRgb.b >= 8) {
            // its words (the subtitle, drawn at scale 2 from y 5 to 13): scale 1, centred just over the bar
            vec2 hudLocal = (hudVert.xy - hudHalf) * 0.5 - vec2(0.0, 9.0);
            vec2 hudAt = hudHalf + hudLocal + vec2(0.0, SHIELD_BAR_Y - SHIELD_BAR_HALF.y - 6.5);
            gl_Position = ProjMat * vec4(hudAt, hudVert.z, hudVert.w);
            hudLabelColor = vec4((hudRgb.b == 8 ? SHIELD_LABEL_FILL : SHIELD_LABEL_SHADOW).rgb, Color.a);
        } else {
            hudMode = 3;
            hudPos = hudCorner * hudHalf;
            hudData = vec4(hudHalf, float(hudRgb.g), hudRgb.b == 6 ? 1.0 : 0.0);
            gl_Position = ProjMat * vec4(hudHalf + hudCorner * hudHalf, hudVert.z, hudVert.w);
        }
    }
    // MagixPack mana flight (see MANA_FLIGHT_BLUE), else the newcomers' film (see CINE_BARS_BLUE).
    if (!manaFlightVertex(hudRgb, hudLabelColor) && !mineralFlightVertex(hudRgb, hudLabelColor)
            && !runeUnlockVertex(hudRgb, hudLabelColor) && !skillRingVertex(hudRgb) && !forestScreenVertex(hudRgb)
            && !ropeGaugeVertex(hudRgb) && !tremorScreenVertex(hudRgb))
            cinemaVertex(hudRgb, hudLabelColor);
#endif

#ifdef IS_GUI
    // MagixPack hotbar HUD (see HOTBAR_HUD_RED).
    vec4 hotbarColor = vec4(-1.0);
    {
        ivec3 hotbarRgb = ivec3(round(Color.rgb * 255.0));
        if (hotbarRgb.r == HOTBAR_HUD_RED && hotbarRgb.b >= 32 && hotbarRgb.b < 224) {
            vec4 hotbarVert = ModelViewMat * vec4(Position, 1.0);
            float hotbarScreenW = round(abs(2.0 / ProjMat[0][0]));
            float hotbarScreenH = abs(2.0 / ProjMat[1][1]);
            float hotbarLeft = floor(hotbarScreenW * 0.5) - HOTBAR_HUD_WIDTH * 0.5;
            if (hotbarVert.x >= hotbarLeft - 2.0 && hotbarVert.x <= hotbarLeft + HOTBAR_HUD_WIDTH + 2.0
                    && hotbarVert.y < HOTBAR_HUD_BAND) {
                float hotbarLine = floor((hotbarVert.y + 0.5) / 19.0) * 19.0;   // 3 over the line's text (+0.5: a top on the line, 7/11)
                // green 0..159 = rows from the panel's top; 160..191 = rows OVER it (green - 192: -32..-1, owner 9/11: the
                // rune panel's hint on two lines when the engraved rune can be raised)
                float hotbarG = float(hotbarRgb.g >= 160 && hotbarRgb.g < 192 ? hotbarRgb.g - 192 : hotbarRgb.g);
                vec2 hotbarRel = vec2(hotbarVert.x - hotbarLeft, hotbarVert.y - hotbarLine - 3.0 + hotbarG);
                bool hotbarGulp = hotbarRgb.b >= 96 && hotbarRgb.b < 112;
                vec3 hotbarFill = HOTBAR_PALETTE[hotbarGulp ? 0 : hotbarRgb.b % 16];
                hotbarColor = vec4(!hotbarGulp && hotbarRgb.b % 32 >= 16 ? hotbarFill * 0.25 : hotbarFill, Color.a);
                if (hotbarGulp) {
                    // THE SLOT SWALLOWS THE ORE'S PIECE (owner 8/11, «come se ingoiasse il detrito»): a mineral's item
                    // marked blue 96 + phase (0..15) by MagixPrison's MineralHud is squashed and stretched round its
                    // own middle: the mouth opens wide, the gulp stretches it up, a little bounce, back still. The
                    // middle: slots of 21 from x 0, the 16 x 16 item 3 in; its top at row 15 here, so the middle at
                    // 11 / 23 and each corner 8 from it.
                    float gulpT = float(hotbarRgb.b - 96) / 15.0;
                    float gulpSlot = floor(hotbarRel.x / 21.0);
                    vec2 gulpMid = vec2(gulpSlot * 21.0 + 11.0, 23.0);
                    vec2 gulpDir = vec2(hotbarRel.x < gulpMid.x ? -8.0 : 8.0, hotbarRel.y < gulpMid.y ? -8.0 : 8.0);
                    vec2 gulpK;
                    if (gulpT < 0.25) gulpK = mix(vec2(1.0), vec2(1.3, 0.78), gulpT / 0.25);
                    else if (gulpT < 0.5) gulpK = mix(vec2(1.3, 0.78), vec2(0.82, 1.3), (gulpT - 0.25) / 0.25);
                    else if (gulpT < 0.75) gulpK = mix(vec2(0.82, 1.3), vec2(1.1, 0.92), (gulpT - 0.5) / 0.25);
                    else gulpK = mix(vec2(1.1, 0.92), vec2(1.0), (gulpT - 0.75) / 0.25);
                    // it stands on the slot's floor while it stretches, and hops a little at the gulp
                    vec2 gulpAt = gulpMid + vec2(0.0, 8.0 - 8.0 * gulpK.y - 2.0 * sin(3.14159 * gulpT));
                    hotbarRel = gulpAt + gulpDir * gulpK;
                }
                // a narrow GUI (1920x1080 at GUI scale 4 is 480 wide, 1366x768 at 3 is 455) has no room for the whole
                // panel right of the hotbar: it shrinks to fit, its bottom kept where it was (owner 7/11, «con tutti
                // gli schermi si vede bene»); the pictures are 4 texels a GUI pixel, so down to 0.5 they stay sharp
                float hotbarLeftEdge = floor(hotbarScreenW * 0.5) + 91.0 + HOTBAR_HUD_GAP;
                float hotbarScale = hudFit(hotbarScreenH, (hotbarScreenW - hotbarLeftEdge - HOTBAR_HUD_MARGIN) / HOTBAR_HUD_FIT_W);
                if (hotbarRgb.b >= 64 && hotbarRgb.b < 96) {
                    // the left panel: its right edge left of the off hand's slot, shrunk the same way on a narrow GUI
                    float hotbarRightEdge = floor(hotbarScreenW * 0.5) - 91.0 - HOTBAR_HUD_OFFHAND - HOTBAR_HUD_GAP;
                    hotbarScale = hudFit(hotbarScreenH, (hotbarRightEdge - HOTBAR_HUD_MARGIN) / HOTBAR_HUD_LEFT_W);
                    hotbarLeftEdge = hotbarRightEdge - HOTBAR_HUD_LEFT_W * hotbarScale;
                }
                if (hotbarRgb.b >= 192) {
                    // THE ENCHANTMENTS (blue 192 + colour): at the top, centred, at the GUI's own scale (see ENCH_*)
                    hotbarVert.xy = vec2(floor(hotbarScreenW * 0.5) - ENCH_W * 0.5 + hotbarRel.x,
                            ENCH_TOP + hotbarRel.y - 1.0);
                } else if (hotbarRgb.b >= 128) {
                    // THE WOOD PANEL (blue 128 + colour, + 16 its shadow): slot i is written at x = WOOD_PITCH * i of the
                    // title and drawn in a COLUMN on the screen's left edge, half way up, slot i WOOD_ROW under slot 0
                    // (they touch like the hotbar's); shrunk on a short GUI so WOOD_MAX slots always fit
                    // A SLOT IS FOUND WITH ROOM TO SPARE (owner 11/11: «non si vede il pannello ma solo il legno»): a
                    // slot's glyphs are written WOOD_INSET in from the start of its own WOOD_PITCH pixels of the title,
                    // 22 wide, so every vertex of a slot falls in its own stretch even when the title sits a few
                    // pixels off (its width is not exactly the panel's: the box's edges fell into the next slot and
                    // its quad was torn between two rows). Six slots fit a title line, so the slots from the seventh
                    // on are written on a second one: green + WOOD_GROUP_G.
                    float woodGroup = hotbarRgb.b < 160 && hotbarG >= WOOD_GROUP_G ? 1.0 : 0.0;
                    hotbarRel.y -= woodGroup * WOOD_GROUP_G;
                    float woodColumn = floor(hotbarRel.x / WOOD_PITCH);
                    float woodSlot = woodColumn + woodGroup * WOOD_PER_GROUP;
                    if (hotbarRgb.b >= 160) {
                        // THE TOKENS (blue 160 + colour): one COLUMN at the right edge under the sidebar (see
                        // TOKEN_*), shrunk when it would reach the screen's bottom or, where the minerals' panel
                        // right of the hotbar comes as far right as the column, that panel's top
                        float tokenY = floor(hotbarScreenH * 0.5) + floor(TOKEN_SB_LINES * 9.0 / 3.0) + TOKEN_GAP;
                        float mineralScale = hudFit(hotbarScreenH, (hotbarScreenW - floor(hotbarScreenW * 0.5) - 91.0 - HOTBAR_HUD_GAP
                                - HOTBAR_HUD_MARGIN) / HOTBAR_HUD_FIT_W);
                        float mineralRight = floor(hotbarScreenW * 0.5) + 91.0 + HOTBAR_HUD_GAP + HOTBAR_HUD_FIT_W * mineralScale;
                        float tokenBottom = mineralRight > hotbarScreenW - TOKEN_RIGHT - 23.0 * hudLock(hotbarScreenH)
                                ? hotbarScreenH - HOTBAR_HUD_UP * mineralScale - 2.0 : hotbarScreenH - 2.0;
                        hotbarScale = hudFit(hotbarScreenH, (tokenBottom - tokenY) / (TOKEN_MAX * WOOD_ROW + 1.0));
                        vec2 tokenTop = vec2(hotbarScreenW - TOKEN_RIGHT - 22.0 * hotbarScale, tokenY);
                        if (hotbarG >= TOKEN_HINT_G && hotbarG < TOKEN_HINT_G + 32.0) {
                            // the vertical hint: title x = along the column from its bottom, title y = towards it
                            float hintV = hotbarRel.y - TOKEN_HINT_G;
                            hotbarVert.xy = vec2(tokenTop.x - (TOKEN_HINT_W - hintV) * hotbarScale,
                                    tokenY + (TOKEN_MAX * WOOD_ROW - hotbarRel.x) * hotbarScale);
                        } else {
                        vec2 tokenRel = vec2(hotbarRel.x - woodColumn * WOOD_PITCH - WOOD_INSET,
                                hotbarRel.y - WOOD_TOP + woodColumn * WOOD_ROW);
                        hotbarVert.xy = tokenTop + (tokenRel - vec2(0.0, 1.0)) * hotbarScale;
                        }
                    } else {
                    hotbarScale = hudFit(hotbarScreenH, (hotbarScreenH - 2.0 * WOOD_MARGIN) / (WOOD_MAX * WOOD_ROW + 2.0));
                    vec2 woodTop = vec2(WOOD_MARGIN, floor(hotbarScreenH * 0.5 - WOOD_MAX * WOOD_ROW * 0.5 * hotbarScale));
                    vec2 woodRel = vec2(hotbarRel.x - woodColumn * WOOD_PITCH - WOOD_INSET, hotbarRel.y - WOOD_TOP + woodSlot * WOOD_ROW);
                    hotbarVert.xy = woodTop + (woodRel - vec2(0.0, 1.0)) * hotbarScale;
                    }
                } else {
                    hotbarVert.xy = vec2(hotbarLeftEdge, hotbarScreenH - HOTBAR_HUD_UP * hotbarScale)
                            + (hotbarRel - vec2(0.0, 1.0)) * hotbarScale;
                }
                gl_Position = ProjMat * hotbarVert;
            }
        }
    }
#endif

#ifdef IS_GUI
    // MagixPrison's carry bar (see CARRY_RED).
    vec4 carryColor = vec4(-1.0);
    {
        ivec3 carryRgb = ivec3(round(Color.rgb * 255.0));
        bool carryFill = carryRgb.r == CARRY_RED && carryRgb.b == 255 && carryRgb.g % 16 == 0 && carryRgb.g < 224;
        bool carryShadow = carryRgb.r == CARRY_RED / 4 && carryRgb.b == 63 && carryRgb.g % 4 == 0 && carryRgb.g < 56;
        if (carryFill || carryShadow) {
            vec4 carryVert = ModelViewMat * vec4(Position, 1.0);
            float carryScreenW = abs(2.0 / ProjMat[0][0]);
            float carryScreenH = abs(2.0 / ProjMat[1][1]);
            bool carryNearMiddle = abs(carryVert.x - carryScreenW * 0.5) < CARRY_HALF_W;
            bool carryBoss = carryNearMiddle && carryVert.y < CARRY_BOSS_BAND;
            if (carryBoss || (carryNearMiddle && carryVert.y > carryScreenH - CARRY_BAND.x
                    && carryVert.y < carryScreenH - CARRY_BAND.y)) {
                int carryIndex = carryFill ? carryRgb.g / 16 : carryRgb.g / 4;
                vec3 carryFillRgb = CARRY_PALETTE[min(carryIndex % 8, 5)];
                carryColor = vec4(carryShadow ? carryFillRgb * 0.25 : carryFillRgb, Color.a);
                float carryDrop = carryIndex >= 8 ? CARRY_SECOND_DROP : 0.0;
                if (carryBoss) {
                    float carryRow = floor((carryVert.y + 2.5) / 19.0) * 19.0 + 3.0;
                    carryVert.y = carryScreenH - CARRY_BOSS_TOP + (carryVert.y - carryRow) + carryDrop;
                } else {
                    carryVert.y -= CARRY_LIFT - carryDrop;
                }
                gl_Position = ProjMat * carryVert;
            }
        }
    }
#endif

#ifdef IS_GUI
    // MagixPack menu marquee (see MARQUEE_BOXES).
    float marqueeAlpha = -1.0;
    ivec3 marqueeRgb = ivec3(round(Color.rgb * 255.0));
    if (marqueeRgb.r == 253) {
        float marqueeOffset = float(marqueeRgb.g);
        int marqueeBoxIndex = marqueeRgb.b - (marqueeRgb.b / 8) * 8;
        float marqueeBox = MARQUEE_BOXES[marqueeBoxIndex];
        float marqueePeriod = float(marqueeRgb.b - marqueeBoxIndex) + MARQUEE_GAP;
        float marqueeTurn = marqueePeriod / MARQUEE_SPEED + MARQUEE_HOLD;
        float marqueeShift = max(0.0, mod(GameTime * 1200.0, marqueeTurn) - MARQUEE_HOLD) * MARQUEE_SPEED;
        // where the character is now, from the label's start: -FADE .. period - FADE (out on the left = back on the right)
        float marqueeAt = mod(marqueeOffset - marqueeShift + MARQUEE_FADE, marqueePeriod) - MARQUEE_FADE;
        vec4 marqueeVert = ModelViewMat * vec4(Position, 1.0);
        gl_Position = ProjMat * vec4(marqueeVert.x + marqueeAt - marqueeOffset, marqueeVert.yzw);
        marqueeAlpha = clamp((marqueeAt + MARQUEE_FADE) / MARQUEE_FADE, 0.0, 1.0)
                * clamp((marqueeBox - MARQUEE_CHAR - marqueeAt) / MARQUEE_FADE + 1.0, 0.0, 1.0);
    }
    // MagixPack panel credits (see CREDITS_LINE).
    float creditsAlpha = -1.0;
    vec3 creditsColour = vec3(1.0);
    if (marqueeRgb.r == 250 && marqueeRgb.b >= 2 && marqueeRgb.b <= 32 && marqueeRgb.g % 32 < marqueeRgb.b) {
        float creditsLine = float(marqueeRgb.g % 32);
        creditsColour = CREDITS_PALETTE[marqueeRgb.g / 32];
        float creditsPeriod = (float(marqueeRgb.b) + CREDITS_GAP) * CREDITS_LINE;
        float creditsTurn = creditsPeriod / CREDITS_SPEED + CREDITS_HOLD;
        float creditsShift = max(0.0, mod(GameTime * 1200.0, creditsTurn) - CREDITS_HOLD) * CREDITS_SPEED;
        // where the line is now, from the window's top: -FADE .. period - FADE (out at the top = back at the bottom)
        float creditsAt = mod(creditsLine * CREDITS_LINE - creditsShift + CREDITS_FADE, creditsPeriod) - CREDITS_FADE;
        vec4 creditsVert = ModelViewMat * vec4(Position, 1.0);
        gl_Position = ProjMat * vec4(creditsVert.x, creditsVert.y + creditsAt, creditsVert.zw);
        creditsAlpha = clamp((creditsAt + CREDITS_TOP_FADE) / CREDITS_TOP_FADE, 0.0, 1.0)
                * clamp((CREDITS_LINES * CREDITS_LINE - CREDITS_LINE - creditsAt) / CREDITS_FADE + 1.0, 0.0, 1.0);
    }
#endif

#ifdef IS_GUI
    // MagixPack compact menus (see FIT_PAGE_RED).
    bool fitWhite = false;
    bool fitLetterHidden = false;
    {
        ivec3 fitRgb = ivec3(round(Color.rgb * 255.0));
        vec2 fitScreen = vec2(abs(2.0 / ProjMat[0][0]), abs(2.0 / ProjMat[1][1]));
        vec4 fitVert = ModelViewMat * vec4(Position, 1.0);
        if (fitRgb.r == FIT_PAGE_RED && fitRgb.g >= 128 && fitRgb.g < 152 && (fitRgb.g - 128) % 4 < 3) {
            int fitZone = (fitRgb.g - 128) % 4;
            int fitRows = (fitRgb.g - 128) / 4 + 1;
            float fitTop = fitWindowTop(fitScreen.y, fitRows);
            if (fitZone == 1 && fitRgb.b > 0) {
                fitVert.y = fitTop + (fitVert.y - fitTop) * clamp((fitTop - FIT_MARGIN) / float(fitRgb.b), 0.0, 1.0);
            }
            if (fitZone == 2) fitVert.y = max(min(fitVert.y, fitScreen.y - FIT_MARGIN), fitTop + float(114 + 18 * fitRows));
            fitVert.x = clamp(fitVert.x, FIT_MARGIN, fitScreen.x - FIT_MARGIN);
            gl_Position = ProjMat * fitVert;
            fitWhite = true;
        } else if (fitRgb.r == FIT_BANNER_RED && fitRgb.g > 160 && fitRgb.g <= 166) {
            if (fitWindowTop(fitScreen.y, fitRgb.g - 160) < float(fitRgb.b) + FIT_MARGIN) gl_Position = FIT_GONE;
            fitWhite = true;
        } else {
            vec2 fitMark = fitLetterMark();
            if (fitMark.y > 0.0 && fitLetterOnWindow(fitVert.y + fitMark.x, fitScreen.y)
                    && fitVert.y + fitMark.x < fitMark.y + FIT_MARGIN) fitLetterHidden = true;
        }
    }
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
#ifdef IS_GUI
    if (hudLabelColor.r >= 0.0) vertexColor = hudLabelColor;
    if (hotbarColor.r >= 0.0) vertexColor = hotbarColor;
    if (carryColor.r >= 0.0) vertexColor = carryColor;
#endif
#ifdef IS_GUI
    if (marqueeAlpha >= 0.0) vertexColor = vec4(1.0, 1.0, 1.0, Color.a * marqueeAlpha);
    if (creditsAlpha >= 0.0) vertexColor = vec4(creditsColour, Color.a * creditsAlpha);
#endif
#ifdef IS_GUI
    if (fitWhite) vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    if (fitLetterHidden) vertexColor.a = 0.0;
#endif
    texCoord0 = UV0;
}
