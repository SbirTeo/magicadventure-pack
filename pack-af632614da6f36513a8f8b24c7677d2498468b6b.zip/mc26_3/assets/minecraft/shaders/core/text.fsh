#version 330
#extension GL_ARB_separate_shader_objects : require
#define MAGIX_TARGET 263
#define LOC(n) layout(location = n)

// MagixPack's own text shader, fragment half: see the note at the top of text.vsh (used only when no plugin
// registers a text shader: the hub). Vanilla for every variant and version (the 26.3 tail, with its
// order-independent transparency, is the one of vanilla 26.3), plus the screen transition in the GUI.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
// 26.3 only: ShaderVariants turns this comment into the include in the mc26_3 overlay (oit.glsl does not exist before).
#include <minecraft:oit.glsl>
// The Store box's running light (storeGlow) needs GameTime: 26.2 and 26.3 only (26.1 has no GUI text variant).

#include <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
LOC(0) in float sphericalVertexDistance;
LOC(1) in float cylindricalVertexDistance;
#endif

LOC(2) in vec4 vertexColor;
LOC(3) in vec2 texCoord0;

#if MAGIX_TARGET < 263 || !defined(OIT_ALPHA_ONLY)
LOC(0) out vec4 fragColor;
#endif

#ifdef IS_GUI
LOC(4) in vec2 hudPos;
LOC(5) flat in int hudMode;
LOC(6) flat in vec4 hudData;

// --- MagixPack screen transition (teleports and server switches) ---------------------------------------
// A diamond wipe. The diamonds sit on two square grids, the second shifted by half a cell, TRANSITION_ROWS of
// them per screen height whatever the resolution or GUI scale. Closing, each grows from nothing to a size that
// covers its cell, the ones on the vertical centre line first, the ones at the sides TRANSITION_SPREAD later;
// opening, they shrink back in the same order. hudData: half screen size in GUI pixels (xy), progress 0..255
// (z), 1 = opening (w). THIS BLOCK IS COPIED IDENTICAL in MagixFactions' text.fsh (the theft HUD's shader,
// used on the faction instead of this one): if it changes, change both.
const float TRANSITION_ROWS = 12.0;
const float TRANSITION_SPREAD = 1.2;

// Radius (in cells, 0.5 = the cell covered) of the diamond centred at `cell` (in cells from the screen centre).
float transitionRadius(vec2 cell, float cellSize, float t, bool opening) {
    float side = clamp(abs(cell.x) * cellSize / max(hudData.x, 1.0), 0.0, 1.0);
    float grown = clamp(t * (1.0 + TRANSITION_SPREAD) - TRANSITION_SPREAD * side, 0.0, 1.0);
    return (opening ? 1.0 - grown : grown) * 0.52;
}

float transitionCover(float dist, float radius, float aa) {
    return radius > 0.0 ? 1.0 - smoothstep(-aa, aa, dist - radius) : 0.0;
}

vec4 hudTransition() {
    float t = hudData.z / 255.0;
    bool opening = hudData.w > 0.5;
    if (!opening && t >= 1.0) return vec4(0.0, 0.0, 0.0, 1.0);
    float cellSize = max(hudData.y * 2.0 / TRANSITION_ROWS, 4.0);
    vec2 q = hudPos / cellSize;
    vec2 a = round(q);                 // grid through the screen centre
    vec2 b = floor(q) + 0.5;           // grid shifted by half a cell
    float aa = fwidth(q.x) + 0.0001;
    float cover = max(
            transitionCover(abs(q.x - a.x) + abs(q.y - a.y), transitionRadius(a, cellSize, t, opening), aa),
            transitionCover(abs(q.x - b.x) + abs(q.y - b.y), transitionRadius(b, cellSize, t, opening), aa));
    return vec4(0.0, 0.0, 0.0, cover);
}

// --- MagixPack shield bar (the few seconds of protection after a teleport) -------------------------------------
// A thin timer bar under the crosshair: a dark track with a soft edge and, from the left, a green fill as long as
// what is left (hudData.z 0..255), lighter at its head. hudPos: -1..1 across the bar; hudData.xy: its half size in
// GUI pixels. THIS BLOCK IS COPIED IDENTICAL in the other text.fsh (MagixFactions' on the faction, MagixPack's on
// the hub): if it changes, change both.
const vec3 SHIELD_FILL_FROM = vec3(0.12, 0.72, 0.4);
const vec3 SHIELD_FILL_TO = vec3(0.55, 1.0, 0.74);

vec4 shieldBar() {
    vec2 bh = hudData.xy;
    vec2 p = hudPos * bh;
    float r = bh.y;
    vec2 q = abs(p) - (bh - vec2(r));
    float dist = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;   // < 0 inside the rounded bar
    float aa = fwidth(p.x) + 0.0001;
    float body = 1.0 - smoothstep(-aa, aa, dist);
    if (body <= 0.0) return vec4(0.0);
    float left = clamp(hudData.z / 255.0, 0.0, 1.0);
    float head = -bh.x + 2.0 * bh.x * left;                        // where the fill ends
    float fill = (1.0 - smoothstep(-aa, aa, p.x - head)) * (1.0 - smoothstep(-aa, aa, dist + 1.0));
    float along = clamp((p.x + bh.x) / max(2.0 * bh.x, 1.0), 0.0, 1.0);
    vec3 rgb = mix(SHIELD_FILL_FROM, SHIELD_FILL_TO, along);
    rgb += vec3(0.35) * exp(-abs(p.x - head) * 0.6) * step(0.001, left);   // a light at the head
    rgb += vec3(0.12) * (1.0 - smoothstep(-r, 0.0, p.y + r * 0.2));       // a highlight on the upper half
    vec4 track = vec4(0.02, 0.07, 0.05, 0.55);
    return vec4(mix(track.rgb, rgb, fill), mix(track.a, 0.95, fill) * body);
}

// --- MagixPack AFK screen (afk/AfkScreen: a player MagixGuard marks as idle) -------------------------------------
// The screen looks frozen: a cold veil over everything, thicker towards the edges, frost growing in from the four
// sides with a few glints that come and go, a light blue border just inside the edge that breathes slowly, and a
// darker band where the three lines of words are (text.vsh puts them there, AFK_LINE*_TOP). hudPos: GUI pixels from
// the screen centre; hudData: half screen size in GUI pixels (xy), seconds (z). THIS BLOCK IS COPIED IDENTICAL in
// MagixFactions' and MagixPack's text.fsh: if it changes, change both.
const vec3 AFK_VEIL = vec3(0.60, 0.82, 0.95);
const vec3 AFK_FROST = vec3(0.88, 0.96, 1.0);
const vec3 AFK_BORDER = vec3(0.40, 0.86, 1.0);
const vec3 AFK_BAND = vec3(0.02, 0.08, 0.15);
const float AFK_BORDER_INSET = 5.0;    // GUI pixels from the screen's edge to the border's middle
const float AFK_FROST_DEPTH = 30.0;    // how far the frost reaches in from the edges, GUI pixels

float afkHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float afkNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(afkHash(i), afkHash(i + vec2(1.0, 0.0)), f.x),
            mix(afkHash(i + vec2(0.0, 1.0)), afkHash(i + vec2(1.0, 1.0)), f.x), f.y);
}

float afkFbm(vec2 p) {
    float n = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        n += a * afkNoise(p);
        p = p * 2.07 + vec2(17.3, 9.1);
        a *= 0.5;
    }
    return n;
}

// `rgb` with alpha `a` laid over `under` (straight alpha).
vec4 afkOver(vec4 under, vec3 rgb, float a) {
    float out_a = a + under.a * (1.0 - a);
    vec3 out_rgb = (rgb * a + under.rgb * under.a * (1.0 - a)) / max(out_a, 0.0001);
    return vec4(out_rgb, out_a);
}

vec4 afkScreen() {
    vec2 half_ = max(hudData.xy, vec2(1.0));
    vec2 p = hudPos;
    float t = hudData.z;
    float edge = min(half_.x - abs(p.x), half_.y - abs(p.y));   // GUI pixels to the nearest edge
    float aa = max(fwidth(p.x), 0.0001);
    // the cold veil, thicker towards the corners
    float vignette = smoothstep(0.3, 1.3, length(p / half_));
    vec4 c = vec4(AFK_VEIL, 0.16 + 0.30 * vignette);
    // the darker band under the words
    float band = 1.0 - smoothstep(34.0, 58.0, abs(p.y + 6.0));
    c = afkOver(c, AFK_BAND, band * 0.42);
    // frost growing in from the edges: ragged, in streaks
    float grain = afkFbm(p / 9.0) * 0.65 + afkFbm(vec2(p.x + p.y, p.x - p.y) / 3.5) * 0.35;
    float reach = AFK_FROST_DEPTH * (0.45 + 0.9 * grain);
    float frost = 1.0 - smoothstep(reach * 0.55, reach, edge);
    c = afkOver(c, AFK_FROST, frost * (0.35 + 0.4 * grain));
    // glints in the frost, each one on and off on its own
    vec2 cell = floor(p / 3.0);
    float seed = afkHash(cell);
    float twinkle = pow(max(0.0, sin(t * (0.6 + seed * 1.4) + seed * 40.0)), 24.0);
    float dot_ = 1.0 - smoothstep(0.15, 0.9, length(fract(p / 3.0) - 0.5) * 2.0);   // a soft round point
    c = afkOver(c, vec3(1.0), frost * step(0.95, seed) * twinkle * dot_);
    // the light blue border, with its glow on both sides, breathing every 4 seconds
    float d = abs(edge - AFK_BORDER_INSET);
    float breath = 0.75 + 0.25 * sin(t * 1.5707963);
    float line = 1.0 - smoothstep(0.9 - aa, 0.9 + aa, d);
    float glow = exp(-d * 0.28) * 0.55 * breath;
    c = afkOver(c, AFK_BORDER, max(line, glow));
    c = afkOver(c, vec3(1.0), line * 0.35 * breath);
    return c;
}
#endif

#if defined(IS_GUI) && MAGIX_TARGET >= 262 && !defined(IS_GRAYSCALE)
// --- MagixPack Store box of the pause screen: a light running clockwise round its border --------------------
// A glyph's texture cannot be animated, so the light is drawn here. menu/PauseScreen marks the box's border:
// alpha 253 = the violet ring, 252 = the pixels just outside and inside it, and the 3 low bits of red, green and
// blue hold the pixel's place along the border (0..511 = one lap, clockwise from the top-left corner). Soft edges
// of other pictures (menu frame, logos, glyphs) are full of 252 next to 253, so a pixel counts only when it is
// really the box's: a ring pixel (253) has the ring's own violet in its 5 high bits (STORE_GLOW_RING, BORDER of
// PauseScreen) and a 252 neighbour whose place is at most STORE_GLOW_NEAR steps away; a 252 pixel has such a ring
// pixel next to it. Until MagixPack 0.32.5 a 252 next to any 253 was enough: whole pictures shimmered.
// GameTime (globals.glsl) is 1/24000 a tick, partial tick included: 1200 seconds a cycle, a whole number of laps
// in it, so no jump when it wraps.
// THIS BLOCK IS COPIED IDENTICAL in MagixPack's and MagixFactions' text.fsh: if it changes, change both.
const float STORE_GLOW_LAPS = 400.0;     // laps a GameTime cycle: one lap every 3 seconds
const float STORE_GLOW_TAIL = 0.24;      // the trail behind the light, a part of the lap
const float STORE_GLOW_FRONT = 0.012;    // the soft front of the light
const vec3 STORE_GLOW_HEAD = vec3(1.0, 0.96, 0.82);
const vec3 STORE_GLOW_TRAIL = vec3(1.0, 0.45, 0.92);

const ivec3 STORE_GLOW_RING = ivec3(0x98, 0x58, 0xD0);  // the ring's violet, 5 high bits (PauseScreen BORDER)
const int STORE_GLOW_NEAR = 4;           // most steps between a marked pixel and its neighbour on the other side

bool storeGlowRing(ivec4 c) {
    return c.a == 253 && (c.rgb & ivec3(0xF8)) == STORE_GLOW_RING;
}

int storeGlowPlace(ivec4 c) {
    return (c.r & 7) | ((c.g & 7) << 3) | ((c.b & 7) << 6);
}

vec4 storeGlow(vec4 tex) {
    ivec4 c = ivec4(round(tex * 255.0));
    if (c.a != 253 && c.a != 252) return tex;
    if (c.a == 253 && !storeGlowRing(c)) return tex;
    int other = c.a == 253 ? 252 : 253;
    int place = storeGlowPlace(c);
    ivec2 texel = ivec2(texCoord0 * vec2(textureSize(Sampler0, 0)));
    bool marked = false;
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            ivec4 n = ivec4(round(texelFetch(Sampler0, texel + ivec2(dx, dy), 0) * 255.0));
            if (n.a != other || (other == 253 && !storeGlowRing(n))) continue;
            int apart = abs(storeGlowPlace(n) - place);
            if (min(apart, 512 - apart) <= STORE_GLOW_NEAR) marked = true;
        }
    }
    if (!marked) return tex;
    float at = (float(place) + 0.5) / 512.0;
    float head = fract(GameTime * STORE_GLOW_LAPS);
    float behind = fract(head - at);
    float ahead = fract(at - head);
    float trail = behind < STORE_GLOW_TAIL ? pow(1.0 - behind / STORE_GLOW_TAIL, 2.0) : 0.0;
    float front = ahead < STORE_GLOW_FRONT ? 1.0 - ahead / STORE_GLOW_FRONT : 0.0;
    float k = max(trail, front * front);
    vec3 light = mix(STORE_GLOW_TRAIL, STORE_GLOW_HEAD, max(trail * trail * trail, front));
    return vec4(mix(tex.rgb, light, k * (c.a == 253 ? 1.0 : 0.6)), 1.0);
}
#endif


#ifdef IS_GUI
// --- MagixPack CINEMA: the newcomers' film (cinematic/CinematicTour, CINE_BARS_BLUE of text.vsh) -----------------
// hudMode 10: the black bars at the top and the bottom coming in with hudData.z (0..255, eased), their full height
// hudData.w, a thin warm line on their inner edge and a soft vignette over the picture; hudMode 11: the whole screen
// black by hudData.z (the cuts between the scenes). hudPos: GUI pixels from the screen centre, hudData.xy its half.
// COPIED IDENTICAL in MagixFactions' and MagixPack's text.fsh: if it changes, change both.
const vec3 CINE_EDGE_LINE = vec3(0.80, 0.64, 0.34);

vec4 cinemaScreen(bool black) {
    float k = clamp(hudData.z / 255.0, 0.0, 1.0);
    if (black) return vec4(0.0, 0.0, 0.0, k);
    float eased = k * k * (3.0 - 2.0 * k);
    vec2 h = max(hudData.xy, vec2(1.0));
    float bar = hudData.w * eased;
    float edge = h.y - abs(hudPos.y);                 // GUI pixels to the nearest top or bottom edge
    float aa = max(fwidth(hudPos.y), 0.0001);
    float inBar = bar > 0.0 ? 1.0 - smoothstep(bar - aa, bar + aa, edge) : 0.0;
    float vignette = smoothstep(0.6, 1.5, length(hudPos / h * vec2(1.0, 0.8))) * 0.42 * eased;
    float a = max(inBar, vignette);
    float line = (1.0 - smoothstep(0.0, aa + 0.5, abs(edge - bar))) * 0.4 * eased;
    float outA = line + a * (1.0 - line);
    return vec4(CINE_EDGE_LINE * line / max(outA, 0.0001), outA);
}

// hudMode 12: the film's pointer (CINE_RECT_BLUE / CINE_ANCHOR_BLUE of text.vsh). hudPos: GUI pixels from the framed
// tile's centre (hudData.w 0, hudData.xy its half size) or from the arrow's tip (hudData.w 1, hudData.xy the way it
// points); hudData.z seconds. A gold arrow with a dark rim and a soft light, bobbing towards its target; a framed tile
// gets a pulsing gold border with its glow.
const vec3 CINE_POINT_GOLD = vec3(1.0, 0.80, 0.30);
const vec3 CINE_POINT_LIGHT = vec3(1.0, 0.97, 0.84);
const vec3 CINE_POINT_RIM = vec3(0.16, 0.08, 0.0);

// Signed distance (about, GUI pixels) to an arrow whose tip is at the origin, pointing along +x.
float cinemaArrow(vec2 p) {
    float head = max(max(p.x, -p.x - 11.0), (abs(p.y) + p.x * 0.75) * 0.8);
    float shaft = max(max(-p.x - 22.0, p.x + 10.0), abs(p.y) - 2.6);
    return min(head, shaft);
}

vec4 cinemaPointerColor(vec2 p, vec2 dir, float t) {
    float bob = 2.5 + 2.5 * sin(t * 6.2831853 * 0.9);
    vec2 q = p + dir * bob;
    vec2 a = vec2(dot(q, dir), dot(q, vec2(-dir.y, dir.x)));
    float d = cinemaArrow(a / 1.4) * 1.4;
    float aa = max(fwidth(d), 0.001);
    float fill = 1.0 - smoothstep(-aa, aa, d);
    float rim = 1.0 - smoothstep(-aa, aa, d - 1.0);
    vec3 rgb = mix(CINE_POINT_LIGHT, CINE_POINT_GOLD, clamp(-a.x / 22.0, 0.0, 1.0));
    float glow = exp(-max(d, 0.0) / 3.0) * 0.45 * (0.75 + 0.25 * sin(t * 6.2831853));
    vec4 c = vec4(CINE_POINT_GOLD, glow * (1.0 - rim));
    c = vec4(mix(c.rgb, CINE_POINT_RIM, rim), max(c.a, rim));
    return vec4(mix(c.rgb, rgb, fill), max(c.a, fill));
}

vec4 cinemaPointer() {
    float t = hudData.z;
    if (hudData.w > 0.5) return cinemaPointerColor(hudPos, normalize(hudData.xy), t);
    vec2 half_ = hudData.xy;
    vec2 q = abs(hudPos) - half_ + 2.0;
    float box = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - 2.0;   // < 0 inside the rounded frame
    float aa = max(fwidth(box), 0.001);
    float pulse = 0.65 + 0.35 * sin(t * 6.2831853 * 0.8);
    float line = 1.0 - smoothstep(0.6 - aa, 0.6 + aa, abs(box));
    float glow = box > 0.0 ? exp(-box / 4.0) * 0.55 * pulse : 0.0;
    float inside = box < 0.0 ? 0.10 * pulse : 0.0;
    vec4 c = vec4(CINE_POINT_GOLD, max(max(glow, inside), line));
    c.rgb = mix(c.rgb, CINE_POINT_LIGHT, line * pulse);
    // the arrow beside the window, pointing at the tile's row (its tip hudData.w * 1000 from the tile's centre)
    float tip = hudData.w * 1000.0;
    vec4 arrow = cinemaPointerColor(hudPos - vec2(tip, 0.0), vec2(tip > 0.0 ? -1.0 : 1.0, 0.0), t);
    return vec4(mix(c.rgb, arrow.rgb, arrow.a), arrow.a + c.a * (1.0 - arrow.a));
}
#endif

void main() {
#ifdef IS_GUI
    // The transition, the shield bar, the AFK screen and the film's picture are drawn here: the glyph texture is not used.
    if (hudMode == 3 || hudMode == 4 || hudMode == 6 || hudMode >= 10) {
        vec4 hud = hudMode == 4 ? shieldBar() : hudMode == 6 ? afkScreen() : hudMode == 12 ? cinemaPointer()
                : hudMode >= 10 ? cinemaScreen(hudMode == 11) : hudTransition();
        hud.a *= vertexColor.a;
        if (hud.a < 0.004) discard;
        fragColor = hud * ColorModulator;
        return;
    }
#endif

#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif
#if defined(IS_GUI) && MAGIX_TARGET >= 262 && !defined(IS_GRAYSCALE)
    texColor = storeGlow(texColor);
#endif

#if MAGIX_TARGET >= 263
    // Vanilla 26.3: the same colour for the three variants, fog only in the world one (scaled by alpha
    // while accumulating OIT).
    vec4 color = texColor * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
#ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
#endif
#if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)
#ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
    vec4 fogColor = FogColor;
#endif
    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
#endif
    fragColor = color;
#endif
#else
#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
#endif
}
