#version 330
#define MAGIX_TARGET 261
#define LOC(n)

// One source for 26.1, 26.2 and 26.3: see gui.vsh (MagixPack's fallback gui shader, MAGIX_TARGET, LOC).

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
#if MAGIX_TARGET >= 263
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
#else
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
#endif

LOC(0) in vec4 vertexColor;
LOC(1) in float chatTag;

LOC(0) out vec4 fragColor;

void main() {
    // The chat's "System" mark (gui.vsh, CHAT_TAG): all four corners marked, so 1 everywhere inside it; a bigger
    // fill with one marked corner is near 1 only right at that corner. Copied from MagixScoreboard's gui.fsh.
    if (chatTag > 0.999) {
        discard;
    }
    vec4 color = vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
